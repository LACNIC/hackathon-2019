# IRRd4

## Archivos para provisionar el IRRd

* Provisionamiento del entorno: 'install.yaml'

## Roles

* 'roles/irrd4' para provisionar el IRRd

## Ejecutar playbooks

* Provisionamiento del entorno Local:
ansible-playbook install.yaml -i hosts -l local -u ´usuario´

