# springboot-swagger

Proyecto ejemplo que enseña como documentar nuestra API realizada con Spring Boot usando Swagger. 
Vea la explicación completa en: https://codigo200.wordpress.com/2017/11/20/swagger-con-java-spring-boot/

Si te fue útil, regalame una estrella.
