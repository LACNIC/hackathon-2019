package net.lacnic.registro.api.response;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("extension")
public class Extension implements Serializable {

	@XStreamAlias("brorg:creData")
	OrgCreData orgCreData;

	@XStreamAlias("brorg:infData")
	OrgInfData orgInfData;

	@XStreamAlias("lacnicorg:infData")
	OrgInfDataAdmin orgInfDataAdmin;

	@XStreamAlias("lacniccontact:infData")
	LACNICContactInfData contacInfData;

	@Override
	public String toString() {
		return "Extension [orgCreData=" + orgCreData + "]";
	}

	public Extension() {

	}

	public OrgCreData getOrgCreData() {
		return orgCreData;
	}

	public void setOrgCreData(OrgCreData orgCreData) {
		this.orgCreData = orgCreData;
	}

	public OrgInfData getOrgInfData() {
		return orgInfData;
	}

	public void setOrgInfData(OrgInfData orgInfData) {
		this.orgInfData = orgInfData;
	}

	public LACNICContactInfData getContacInfData() {
		return contacInfData;
	}

	public void setContacInfData(LACNICContactInfData contacInfData) {
		this.contacInfData = contacInfData;
	}
}
