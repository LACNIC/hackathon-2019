package net.lacnic.model;

import java.util.Objects;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;
import net.lacnic.registro.api.request.Phone;

/**
 * PhoneDTO
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2019-01-10T12:54:03.514Z[GMT]")

public class PhoneDTO {
	@JsonProperty("country_code")
	private String countryCode;

	@JsonProperty("phone_number")
	private String phoneNumber;

	@JsonProperty("phone_extension")
	private String phoneExtension;

	public PhoneDTO countryCode(String countryCode) {
		this.countryCode = countryCode;
		return this;
	}

	/**
	 * Get countryCode
	 * 
	 * @return countryCode
	 **/
	@ApiModelProperty(value = "")

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public PhoneDTO phoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
		return this;
	}

	/**
	 * Get phoneNumber
	 * 
	 * @return phoneNumber
	 **/
	@ApiModelProperty(value = "")

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public PhoneDTO phoneExtension(String phoneExtension) {
		this.phoneExtension = phoneExtension;
		return this;
	}

	/**
	 * Get phoneExtension
	 * 
	 * @return phoneExtension
	 **/

	public String getPhoneExtension() {
		return phoneExtension;
	}

	public void setPhoneExtension(String phoneExtension) {
		this.phoneExtension = phoneExtension;
	}

	@Override
	public boolean equals(java.lang.Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		PhoneDTO phone = (PhoneDTO) o;
		return Objects.equals(this.countryCode, phone.countryCode) && Objects.equals(this.phoneNumber, phone.phoneNumber) && Objects.equals(this.phoneExtension, phone.phoneExtension);
	}

	@Override
	public int hashCode() {
		return Objects.hash(countryCode, phoneNumber, phoneExtension);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class PhoneDTO {\n");
		sb.append("    countryCode: ").append(toIndentedString(countryCode)).append("\n");
		sb.append("    phoneNumber: ").append(toIndentedString(phoneNumber)).append("\n");
		sb.append("    phoneExtension: ").append(toIndentedString(phoneExtension)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

	// **Este si se utiliza
	public Phone converterToModel(PhoneDTO phoneDTO) {
		Phone phone = new Phone();
		phone.setCountry_code(phoneDTO.getCountryCode());
		phone.setPhone_number(phoneDTO.getPhoneNumber());
		phone.setPhone_extension(phoneDTO.getPhoneExtension());
		return phone;
	}

}
