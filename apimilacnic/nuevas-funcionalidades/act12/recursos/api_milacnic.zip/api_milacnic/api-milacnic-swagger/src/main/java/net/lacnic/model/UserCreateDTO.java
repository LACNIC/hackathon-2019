package net.lacnic.model;

import java.util.Objects;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * UserCreateDTO
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2019-01-10T12:54:03.514Z[GMT]")

public class UserCreateDTO {

	@JsonProperty("name")
	private String name = null;

	@JsonProperty("email")
	private String email = null;

	@JsonProperty("password")
	private String password = null;

	@JsonProperty("reminder_password")
	private String reminderPassword = null;

	@JsonProperty("language")
	private String language = null;

	@JsonProperty("address")
	private AddressDTO address = null;

	@JsonProperty("phone")
	private PhoneDTO phone = null;

	public UserCreateDTO name(String name) {
		this.name = name;
		return this;
	}

	/**
	 * Get name
	 * 
	 * @return name
	 **/
	@ApiModelProperty(value = "")

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public UserCreateDTO email(String email) {
		this.email = email;
		return this;
	}

	/**
	 * Get email
	 * 
	 * @return email
	 **/
	@ApiModelProperty(value = "")

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public UserCreateDTO password(String password) {
		this.password = password;
		return this;
	}

	/**
	 * Get password
	 * 
	 * @return password
	 **/
	@ApiModelProperty(value = "")

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public UserCreateDTO reminderPassword(String reminderPassword) {
		this.reminderPassword = reminderPassword;
		return this;
	}

	/**
	 * Get reminderPassword
	 * 
	 * @return reminderPassword
	 **/
	@ApiModelProperty(value = "")

	public String getReminderPassword() {
		return reminderPassword;
	}

	public void setReminderPassword(String reminderPassword) {
		this.reminderPassword = reminderPassword;
	}

	public UserCreateDTO language(String language) {
		this.language = language;
		return this;
	}

	/**
	 * Get language
	 * 
	 * @return language
	 **/
	@ApiModelProperty(value = "")

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public UserCreateDTO address(AddressDTO address) {
		this.address = address;
		return this;
	}

	/**
	 * Get address
	 * 
	 * @return address
	 **/
	@ApiModelProperty(value = "")

	@Valid

	public AddressDTO getAddress() {
		return address;
	}

	public void setAddress(AddressDTO address) {
		this.address = address;
	}

	public UserCreateDTO phone(PhoneDTO phone) {
		this.phone = phone;
		return this;
	}

	/**
	 * Get phone
	 * 
	 * @return phone
	 **/
	@ApiModelProperty(value = "")

	@Valid

	public PhoneDTO getPhone() {
		return phone;
	}

	public void setPhone(PhoneDTO phone) {
		this.phone = phone;
	}

	@Override
	public boolean equals(java.lang.Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		UserCreateDTO usuarioDTO = (UserCreateDTO) o;
		return Objects.equals(this.name, usuarioDTO.name) && Objects.equals(this.email, usuarioDTO.email) && Objects.equals(this.password, usuarioDTO.password) && Objects.equals(this.reminderPassword, usuarioDTO.reminderPassword) && Objects.equals(this.language, usuarioDTO.language) && Objects.equals(this.address, usuarioDTO.address) && Objects.equals(this.phone, usuarioDTO.phone);
	}

	@Override
	public int hashCode() {
		return Objects.hash(name, email, password, reminderPassword, language, address, phone);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class UserCreateDTO {\n");
		sb.append("    name: ").append(toIndentedString(name)).append("\n");
		sb.append("    email: ").append(toIndentedString(email)).append("\n");
		sb.append("    password: ").append(toIndentedString(password)).append("\n");
		sb.append("    reminderPassword: ").append(toIndentedString(reminderPassword)).append("\n");
		sb.append("    language: ").append(toIndentedString(language)).append("\n");
		sb.append("    address: ").append(toIndentedString(address)).append("\n");
		sb.append("    phone: ").append(toIndentedString(phone)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

}
