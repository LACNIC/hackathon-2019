
package net.lacnic.api.response;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;

/**
 *
 * @author usuario
 */
public class AddressResponse {

	@JacksonXmlElementWrapper(useWrapping = false)
	private List<String> street = new ArrayList<>();
	private String city = "";
	private String pc = "";
	private String cc = "";
	private String sp = "";

	public AddressResponse() {
	}

	public List<String> getStreet() {
		return street;
	}

	public void setStreet(List<String> street) {
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPc() {
		return pc;
	}

	public void setPc(String pc) {
		this.pc = pc;
	}

	public String getCc() {
		return cc;
	}

	public void setCc(String cc) {
		this.cc = cc;
	}

	public String getSp() {
		return sp;
	}

	public void setSp(String sp) {
		this.sp = sp;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class Address {\n");
		sb.append("    street: ").append(toIndentedString(street)).append("\n");
		sb.append("    city: ").append(toIndentedString(city)).append("\n");
		sb.append("    pc: ").append(toIndentedString(pc)).append("\n");
		sb.append("    cc: ").append(toIndentedString(cc)).append("\n");
		sb.append("    sp: ").append(toIndentedString(sp)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

}
