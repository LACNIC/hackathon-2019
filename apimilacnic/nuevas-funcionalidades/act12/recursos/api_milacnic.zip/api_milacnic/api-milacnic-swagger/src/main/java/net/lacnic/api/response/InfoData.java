package net.lacnic.api.response;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;

public class InfoData {

	private String schemaLocation = "";

	// Para el <brorg:infData
	private String organization = "";
	@JacksonXmlElementWrapper(useWrapping = false)
	private List<ContactResponse> contact = new ArrayList<>();
	private String responsible = "";
	@JacksonXmlElementWrapper(useWrapping = false)
	private List<String> asNumber = new ArrayList<>();
	@JacksonXmlElementWrapper(useWrapping = false)
	private List<IPNetworkIPRange> ipRange = new ArrayList<>();

	// Para el <lacniccontact:infData
	private String reminder = "";
	private String language = "";
	private String legacy = "";
	private String property = "";

	public InfoData() {
	}

	public String getSchemaLocation() {
		return schemaLocation;
	}

	public void setSchemaLocation(String schemaLocation) {
		this.schemaLocation = schemaLocation;
	}

	public String getOrganization() {
		return organization;
	}

	public void setOrganization(String organization) {
		this.organization = organization;
	}

	public List<ContactResponse> getContact() {
		return contact;
	}

	public void setContact(List<ContactResponse> contact) {
		this.contact = contact;
	}

	public String getResponsible() {
		return responsible;
	}

	public void setResponsible(String responsible) {
		this.responsible = responsible;
	}

	public List<String> getAsNumber() {
		return asNumber;
	}

	public void setAsNumber(List<String> asNumber) {
		this.asNumber = asNumber;
	}

	public List<IPNetworkIPRange> getIpRange() {
		return ipRange;
	}

	public void setIpRange(List<IPNetworkIPRange> ipRange) {
		this.ipRange = ipRange;
	}

	public String getReminder() {
		return reminder;
	}

	public void setReminder(String reminder) {
		this.reminder = reminder;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getLegacy() {
		return legacy;
	}

	public void setLegacy(String legacy) {
		this.legacy = legacy;
	}

	public String getProperty() {
		return property;
	}

	public void setProperty(String property) {
		this.property = property;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class InfoData {\n");
		sb.append("    organization: ").append(toIndentedString(organization)).append("\n");
		sb.append("    contact: ").append(toIndentedString(contact)).append("\n");
		sb.append("    responsible: ").append(toIndentedString(responsible)).append("\n");
		sb.append("    asNumber: ").append(toIndentedString(asNumber)).append("\n");
		sb.append("    ipRange: ").append(toIndentedString(ipRange)).append("\n");
		sb.append("    reminder: ").append(toIndentedString(reminder)).append("\n");
		sb.append("    language: ").append(toIndentedString(language)).append("\n");
		sb.append("    legacy: ").append(toIndentedString(legacy)).append("\n");
		sb.append("    property: ").append(toIndentedString(property)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

}
