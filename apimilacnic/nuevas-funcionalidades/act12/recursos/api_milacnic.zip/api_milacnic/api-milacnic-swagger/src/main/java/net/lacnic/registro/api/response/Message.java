package net.lacnic.registro.api.response;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("msg")
//@XStreamConverter(value = ToAttributedValueConverter.class, strings = { "content" })
public class Message implements Serializable{

	@XStreamAlias("lang")
	String lang;

	String content;

	public Message() {
	}
}
