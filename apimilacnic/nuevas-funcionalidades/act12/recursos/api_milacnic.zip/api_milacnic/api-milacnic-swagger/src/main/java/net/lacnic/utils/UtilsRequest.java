package net.lacnic.utils;

import javax.servlet.http.HttpServletRequest;

public class UtilsRequest {

	public static String getRemoteAddr(final HttpServletRequest request) {

		String ipAddress = request.getHeader("X-FORWARDED-FOR");
		if (ipAddress == null) {
			ipAddress = request.getRemoteAddr();
		}
		return ipAddress;
	}

}
