package net.lacnic.api.response;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;

public class IPNetworkReverseDNS {

	private IPNetworkIPRange ipRange = new IPNetworkIPRange();
	@JacksonXmlElementWrapper(useWrapping = false)
	private List<String> hostName = new ArrayList<>();

	public IPNetworkReverseDNS() {
	}

	public IPNetworkIPRange getIpRange() {
		return ipRange;
	}

	public void setIpRange(IPNetworkIPRange ipRange) {
		this.ipRange = ipRange;
	}

	public List<String> getHostName() {
		return hostName;
	}

	public void setHostName(List<String> hostName) {
		this.hostName = hostName;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class IPNetworkReverseDNS {\n");
		sb.append("    ipRange: ").append(toIndentedString(ipRange)).append("\n");
		sb.append("    hostName: ").append(toIndentedString(hostName)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

	// public IPNetworkRangeDTO convertToDto(IPNetworkIPRange ipNetworkIPRange) {
	// IPNetworkRangeDTO reverseDNSDTO = new IPNetworkRangeDTO();
	// reverseDNSDTO.setStartAddress(ipNetworkIPRange.getStartAddress());
	// reverseDNSDTO.setEndAddress(ipNetworkIPRange.getEndAddress());
	// reverseDNSDTO.setVersion(ipNetworkIPRange.getEndAddress());
	// return reverseDNSDTO;
	// }

}
