package net.lacnic.epp;

import java.io.IOException;
import java.net.UnknownHostException;
import java.util.Properties;

import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

import net.lacnic.epp.util.Constantes;

public class SSLFactory {

	public static SSLSocket createSSLSocket() {
		try {

			// String keyStore = Constantes.CERTS_FOLDER + "epp-nic-br.jks";
			// String trustStore = Constantes.CERTS_FOLDER + "jssecacerts";
			// System.out.println(keyStore);
			// System.out.println(trustStore);
			// System.setProperty("javax.net.ssl.keyStore", keyStore);
			// System.setProperty("javax.net.ssl.keyStorePassword", "lacnic");
			// System.setProperty("javax.net.ssl.trustStoreType", "JKS");
			// System.setProperty("javax.net.ssl.trustStore", trustStore);
			// System.setProperty("javax.net.ssl.trustStorePassword",
			// "changeit");
			// // System.setProperty("javax.net.ssl.keyStoreType", "PKCS12");
			Properties properties = Constantes.getEppProperties();
//			properties.putAll(System.getProperties());
//			System.setProperties(properties);
			
			SSLSocketFactory sf = (SSLSocketFactory) SSLSocketFactory.getDefault();
			String host = properties.getProperty(Constantes.url);
			Integer port = Integer.valueOf(properties.getProperty(Constantes.port));
			SSLSocket sslSocket = (SSLSocket) sf.createSocket(host, port);
			return sslSocket;

		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
}
