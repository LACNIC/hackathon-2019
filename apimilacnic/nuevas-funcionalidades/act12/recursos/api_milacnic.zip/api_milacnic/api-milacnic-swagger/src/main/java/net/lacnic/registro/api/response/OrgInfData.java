package net.lacnic.registro.api.response;

import java.io.Serializable;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

@XStreamAlias("brorg:infData")
public class OrgInfData implements Serializable {

	private static final long serialVersionUID = -8603085385230437016L;

	@XStreamAlias("brorg:organization")
	String organization;

	@XStreamImplicit(itemFieldName = "brorg:contact")
	List<IPNetworkContact> contact;

	@XStreamAlias("brorg:responsible")
	String responsible;

	@XStreamImplicit(itemFieldName = "brorg:asNumber")
	List<String> asNumber;

	@XStreamImplicit(itemFieldName = "brorg:ipRange")
	List<OrgIPRange> ipRange;

}
