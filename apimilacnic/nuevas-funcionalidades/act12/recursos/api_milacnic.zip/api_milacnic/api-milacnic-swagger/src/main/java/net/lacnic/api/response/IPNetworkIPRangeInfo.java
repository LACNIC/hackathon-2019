package net.lacnic.api.response;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;

public class IPNetworkIPRangeInfo {

	private String roid = "";
	private String allocType = "";
	private String organization = "";
	private int asn = 0;
	@JacksonXmlElementWrapper(useWrapping = false)
	private List<ContactResponse> contact = new ArrayList<>();
	@JacksonXmlElementWrapper(useWrapping = false)
	private List<IPNetworkReverseDNS> reverseDNS = new ArrayList<>();
	@JacksonXmlElementWrapper(useWrapping = false)
	private List<IPNetworkChildNetwork> childNetwork = new ArrayList<>();
	@JacksonXmlElementWrapper(useWrapping = false)
	private List<IPNetworkParentNetwork> parentNetwork = new ArrayList<>();
	private String clID = "";
	private String crID = "";
	private String crDate = "";
	private String upDate = "";

	public IPNetworkIPRangeInfo() {
	}

	public String getRoid() {
		return roid;
	}

	public void setRoid(String roid) {
		this.roid = roid;
	}

	public String getAllocType() {
		return allocType;
	}

	public void setAllocType(String allocType) {
		this.allocType = allocType;
	}

	public String getOrganization() {
		return organization;
	}

	public void setOrganization(String organization) {
		this.organization = organization;
	}

	public int getAsn() {
		return asn;
	}

	public void setAsn(int asn) {
		this.asn = asn;
	}

	public List<ContactResponse> getContact() {
		return contact;
	}

	public void setContact(List<ContactResponse> contact) {
		this.contact = contact;
	}

	public List<IPNetworkReverseDNS> getReverseDNS() {
		return reverseDNS;
	}

	public void setReverseDNS(List<IPNetworkReverseDNS> reverseDNS) {
		this.reverseDNS = reverseDNS;
	}

	public List<IPNetworkChildNetwork> getChildNetwork() {
		return childNetwork;
	}

	public void setChildNetwork(List<IPNetworkChildNetwork> childNetwork) {
		this.childNetwork = childNetwork;
	}

	public List<IPNetworkParentNetwork> getParentNetwork() {
		return parentNetwork;
	}

	public void setParentNetwork(List<IPNetworkParentNetwork> parentNetwork) {
		this.parentNetwork = parentNetwork;
	}

	public String getClID() {
		return clID;
	}

	public void setClID(String clID) {
		this.clID = clID;
	}

	public String getCrID() {
		return crID;
	}

	public void setCrID(String crID) {
		this.crID = crID;
	}

	public String getCrDate() {
		return crDate;
	}

	public void setCrDate(String crDate) {
		this.crDate = crDate;
	}

	public String getUpDate() {
		return upDate;
	}

	public void setUpDate(String upDate) {
		this.upDate = upDate;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class IPNetworkIPRangeInfo {\n");
		sb.append("    roid: ").append(toIndentedString(roid)).append("\n");
		sb.append("    allocType: ").append(toIndentedString(allocType)).append("\n");
		sb.append("    organization: ").append(toIndentedString(organization)).append("\n");
		sb.append("    asn: ").append(toIndentedString(asn)).append("\n");
		sb.append("    contact: ").append(toIndentedString(contact)).append("\n");
		sb.append("    reverseDNS: ").append(toIndentedString(reverseDNS)).append("\n");
		sb.append("    childNetwork: ").append(toIndentedString(childNetwork)).append("\n");
		sb.append("    parentNetwork: ").append(toIndentedString(parentNetwork)).append("\n");
		sb.append("    clID: ").append(toIndentedString(clID)).append("\n");
		sb.append("    crID: ").append(toIndentedString(crID)).append("\n");
		sb.append("    crDate: ").append(toIndentedString(crDate)).append("\n");
		sb.append("    upDate: ").append(toIndentedString(upDate)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

}
