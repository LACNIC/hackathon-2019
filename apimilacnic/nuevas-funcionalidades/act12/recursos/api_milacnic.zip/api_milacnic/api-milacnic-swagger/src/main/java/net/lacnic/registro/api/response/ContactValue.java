package net.lacnic.registro.api.response;

import java.io.Serializable;

public class ContactValue extends Value implements Serializable {

}
