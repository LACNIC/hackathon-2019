package net.lacnic.registro.api.response;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("resData")
public class ContactResData extends ResData implements Serializable {
	@XStreamAlias("contact:creData")
	ContactCreData contactCreData;

	public ContactResData() {

	}
}
