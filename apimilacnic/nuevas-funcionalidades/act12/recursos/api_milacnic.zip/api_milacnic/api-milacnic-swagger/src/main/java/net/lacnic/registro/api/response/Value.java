package net.lacnic.registro.api.response;

import java.io.Serializable;

public class Value  implements Serializable{

}
