package net.lacnic.api;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import net.lacnic.model.IpDelegarDTO;
import net.lacnic.model.IpDelegarUpdateDTO;

@RunWith(SpringRunner.class)
@SpringBootTest
public class DomainsApiControllerIntegrationTest {

	@Autowired
	private DomainsApi api;

	@Test
	public void domainsPrefixDeleteTest() throws Exception {
		String prefix = "prefix_example";
		String prefixLength = "prefixLength_example";
		ResponseEntity<Object> responseEntity = api.domainsPrefixDelete(prefix, prefixLength);
		assertEquals(HttpStatus.NOT_IMPLEMENTED, responseEntity.getStatusCode());
	}

	@Test
	public void domainsHostnameGetTest() throws Exception {
		String hostname = "hostname_example";
		ResponseEntity<Object> responseEntity = api.domainsHostnameGet(hostname);
		assertEquals(HttpStatus.NOT_IMPLEMENTED, responseEntity.getStatusCode());
	}

	@Test
	public void domainsPrefixPutTest() throws Exception {
		IpDelegarUpdateDTO body = new IpDelegarUpdateDTO();
		String prefix = "prefix_example";
		String prefixLength = "prefixLength_example";
		ResponseEntity<Object> responseEntity = api.domainsPrefixPut(body, prefix, prefixLength);
		assertEquals(HttpStatus.NOT_IMPLEMENTED, responseEntity.getStatusCode());
	}

	@Test
	public void domainsPostTest() throws Exception {
		IpDelegarDTO body = new IpDelegarDTO();
		ResponseEntity<Object> responseEntity = api.domainsPost(body);
		assertEquals(HttpStatus.NOT_IMPLEMENTED, responseEntity.getStatusCode());
	}

}
