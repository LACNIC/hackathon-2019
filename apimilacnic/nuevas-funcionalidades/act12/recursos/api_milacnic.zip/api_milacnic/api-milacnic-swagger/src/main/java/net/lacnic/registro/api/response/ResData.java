package net.lacnic.registro.api.response;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

public class ResData implements Serializable {

	@XStreamAlias("contact:creData")
	ContactCreData contactCreData;

	@XStreamAlias("contact:infData")
	ContactInfData contactInfData;

	@XStreamAlias("ipnetwork:creData")
	IPNetworkCreData ipnetworkCreData;

	@XStreamAlias("ipnetwork:infData")
	IPNetworkInfData ipnetworkInfData;

	// @XStreamAlias("ipnetwork:roid")
	// String roid;

	@Override
	public String toString() {
		return "ResData [contactCreData=" + contactCreData + "]";
	}

	public ResData() {
	}

	public ContactCreData getContactCreData() {
		return contactCreData;
	}

	public IPNetworkCreData getIpnetworkCreData() {
		return ipnetworkCreData;
	}

	public IPNetworkInfData getIpnetworkInfData() {
		return ipnetworkInfData;
	}

	// public String getRoid() {
	// return roid;
	// }

}
