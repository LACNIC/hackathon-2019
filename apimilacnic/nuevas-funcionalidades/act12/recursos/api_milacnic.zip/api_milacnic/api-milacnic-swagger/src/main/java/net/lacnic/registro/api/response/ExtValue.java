package net.lacnic.registro.api.response;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

public class ExtValue implements Serializable {
	@XStreamAlias("value")
	String value;
	@XStreamAlias("reason")
	String reason;

	@Override
	public String toString() {
		return "ExtValue [value=" + value + ", reason=" + reason + "]";
	}

	public ExtValue() {

	}
}
