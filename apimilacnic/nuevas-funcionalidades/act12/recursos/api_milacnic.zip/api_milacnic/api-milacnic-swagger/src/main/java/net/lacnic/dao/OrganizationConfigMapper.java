package net.lacnic.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.skife.jdbi.v2.StatementContext;
import org.skife.jdbi.v2.tweak.ResultSetMapper;

import net.lacnic.domain.OrganizationConfig;

public class OrganizationConfigMapper implements ResultSetMapper<OrganizationConfig> {

	@Override
	public OrganizationConfig map(int i, ResultSet rs, StatementContext statementContext) throws SQLException {
		OrganizationConfig oc = new OrganizationConfig();
		oc.setIdOrgConfig(rs.getString("idOrgConfig"));
		oc.setBaneado(rs.getBoolean("baneado"));
		oc.setClientId(rs.getString("clientId"));
		return oc;
	}
}
