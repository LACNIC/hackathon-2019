package net.lacnic.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * IpDTO
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2019-01-10T12:54:03.514Z[GMT]")

public class IpDTO {

	@JsonProperty("orgId")
	@Valid
	private String orgId = "";

	@JsonProperty("roid")
	@Valid
	private String roid = "";

	@JsonProperty("asn")
	@Valid
	private int asn = 0;

	@JsonProperty("ipnetwork_range")
	@Valid
	private IPNetworkRangeDTO ipnetworkRange = new IPNetworkRangeDTO();

	@JsonProperty("allocationType")
	@Valid
	private String allocationType = "";

	@JsonProperty("abuseContact")
	@Valid
	private String abuseContact = "";

	@JsonProperty("techContact")
	@Valid
	private String techContact = "";

	// @JsonProperty("contacts")
	// @Valid
	// private List<ContactDTO> contacts = new ArrayList<>();

	@JsonProperty("ipnetwork_reverses_dns")
	@Valid
	private List<ReverseDNSDTO> ipnetworkReversesDns = new ArrayList<>();

	@JsonProperty("ipnetwork_child_network")
	@Valid
	private List<IPNetworkChildDTO> ipnetworkChildNetwork = new ArrayList<>();

	@JsonProperty("ipnetwork_parent_network")
	@Valid
	private List<IPNetworkParentDTO> ipnetworkParentNetwork = new ArrayList<>();

	public IpDTO orgRequest(String orgId) {
		this.orgId = orgId;
		return this;
	}

	/**
	 * Get orgId
	 *
	 * @return orgId
	 *
	 */
	@ApiModelProperty(value = "")

	@Valid

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public IpDTO roid(String roid) {
		this.roid = roid;
		return this;
	}

	/**
	 * Get roid
	 *
	 * @return roid
	 *
	 */
	@ApiModelProperty(value = "")
	@Valid
	public String getRoid() {
		return roid;
	}

	public void setRoid(String roid) {
		this.roid = roid;
	}

	public IpDTO asn(int asn) {
		this.asn = asn;
		return this;
	}

	/**
	 * Get asn
	 *
	 * @return asn
	 *
	 */
	@ApiModelProperty(value = "")
	@Valid
	public int getAsn() {
		return asn;
	}

	public void setAsn(int asn) {
		this.asn = asn;
	}

	public IpDTO ipnetworkRange(IPNetworkRangeDTO ipnetworkRange) {
		this.ipnetworkRange = ipnetworkRange;
		return this;
	}

	/**
	 * Get ipnetworkRange
	 *
	 * @return ipnetworkRange
	 *
	 */
	@ApiModelProperty(value = "")

	@Valid

	public IPNetworkRangeDTO getIpnetworkRange() {
		return ipnetworkRange;
	}

	public void setIpnetworkRange(IPNetworkRangeDTO ipnetworkRange) {
		this.ipnetworkRange = ipnetworkRange;
	}

	public IpDTO allocationType(String allocationType) {
		this.allocationType = allocationType;
		return this;
	}

	/**
	 * Get allocationType
	 *
	 * @return allocationType
	 *
	 */
	@ApiModelProperty(value = "")
	@Valid
	public String getAllocationType() {
		return allocationType;
	}

	public void setAllocationType(String allocationType) {
		this.allocationType = allocationType;
	}

	public IpDTO abuseContact(String abuseContact) {
		this.abuseContact = abuseContact;
		return this;
	}

	/**
	 * Get abuseContact
	 *
	 * @return abuseContact
	 *
	 */
	@ApiModelProperty(value = "")
	@Valid
	public String getAbuseContact() {
		return abuseContact;
	}

	public void setAbuseContact(String abuseContact) {
		this.abuseContact = abuseContact;
	}

	public IpDTO techContact(String techContact) {
		this.techContact = techContact;
		return this;
	}

	/**
	 * Get techContact
	 *
	 * @return techContact
	 *
	 */
	@ApiModelProperty(value = "")
	@Valid
	public String getTechContact() {
		return techContact;
	}

	public void setTechContact(String techContact) {
		this.techContact = techContact;
	}

	public IpDTO ipnetworkReversesDns(List<ReverseDNSDTO> ipnetworkReversesDns) {
		this.ipnetworkReversesDns = ipnetworkReversesDns;
		return this;
	}

	public IpDTO addIpnetworkReversesDnsItem(ReverseDNSDTO ipnetworkReversesDnsItem) {
		if (this.ipnetworkReversesDns == null) {
			this.ipnetworkReversesDns = new ArrayList<>();
		}
		this.ipnetworkReversesDns.add(ipnetworkReversesDnsItem);
		return this;
	}

	/**
	 * Get ipnetworkReversesDns
	 *
	 * @return ipnetworkReversesDns
	 *
	 */
	@ApiModelProperty(value = "")

	@Valid

	public List<ReverseDNSDTO> getIpnetworkReversesDns() {
		return ipnetworkReversesDns;
	}

	public void setIpnetworkReversesDns(List<ReverseDNSDTO> ipnetworkReversesDns) {
		this.ipnetworkReversesDns = ipnetworkReversesDns;
	}

	public List<IPNetworkChildDTO> getIpnetworkChildNetwork() {
		return ipnetworkChildNetwork;
	}

	public void setIpnetworkChildNetwork(List<IPNetworkChildDTO> ipnetworkChildNetwork) {
		this.ipnetworkChildNetwork = ipnetworkChildNetwork;
	}

	public List<IPNetworkParentDTO> getIpnetworkParentNetwork() {
		return ipnetworkParentNetwork;
	}

	public void setIpnetworkParentNetwork(List<IPNetworkParentDTO> ipnetworkParentNetwork) {
		this.ipnetworkParentNetwork = ipnetworkParentNetwork;
	}

	@Override
	public boolean equals(java.lang.Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		IpDTO ip = (IpDTO) o;
		return Objects.equals(this.orgId, ip.orgId) && Objects.equals(this.roid, ip.roid) && Objects.equals(this.ipnetworkRange, ip.ipnetworkRange) && Objects.equals(this.allocationType, ip.allocationType) && Objects.equals(this.ipnetworkReversesDns, ip.ipnetworkReversesDns) && Objects.equals(this.ipnetworkChildNetwork, ip.ipnetworkChildNetwork) && Objects.equals(this.ipnetworkParentNetwork, ip.ipnetworkParentNetwork) && Objects.equals(this.techContact, ip.techContact) && Objects.equals(this.abuseContact, ip.abuseContact);
	}

	@Override
	public int hashCode() {
		return Objects.hash(orgId, roid, ipnetworkRange, techContact, abuseContact, ipnetworkReversesDns, ipnetworkChildNetwork, ipnetworkParentNetwork);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class IpDTO {\n");
		sb.append("    orgId: ").append(toIndentedString(orgId)).append("\n");
		sb.append("    roid: ").append(toIndentedString(roid)).append("\n");
		sb.append("    ipnetworkRange: ").append(toIndentedString(ipnetworkRange)).append("\n");
		sb.append("    allocationType: ").append(toIndentedString(allocationType)).append("\n");
		sb.append("    abuseContact: ").append(toIndentedString(abuseContact)).append("\n");
		sb.append("    techContact: ").append(toIndentedString(techContact)).append("\n");
		sb.append("    ipnetworkReversesDns: ").append(toIndentedString(ipnetworkReversesDns)).append("\n");
		sb.append("    ipnetworkChildNetwork: ").append(toIndentedString(ipnetworkChildNetwork)).append("\n");
		sb.append("    ipnetworkParentNetwork: ").append(toIndentedString(ipnetworkParentNetwork)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

}
