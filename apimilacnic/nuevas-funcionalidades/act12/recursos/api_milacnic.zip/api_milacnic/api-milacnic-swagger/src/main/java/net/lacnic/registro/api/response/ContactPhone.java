package net.lacnic.registro.api.response;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

@XStreamAlias("contact:voice")
public class ContactPhone implements Serializable {

	private static final long serialVersionUID = -2441255265577891312L;

	@XStreamAsAttribute
	String x; // attribute

	// String contactVoice;

	public String getX() {
		return x;
	}

	public void setX(String x) {
		this.x = x;
	}

}
