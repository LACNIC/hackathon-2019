package net.lacnic.api.response;

public class ResData {

	private ResDataInfoData infData = new ResDataInfoData();
	private CreData creData = new CreData();

	public ResData() {
	}

	public ResDataInfoData getInfData() {
		return infData;
	}

	public void setInfData(ResDataInfoData infData) {
		this.infData = infData;
	}

	public CreData getCreData() {
		return creData;
	}

	public void setCreData(CreData creData) {
		this.creData = creData;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class ResData {\n");
		sb.append("    infData: ").append(toIndentedString(infData)).append("\n");
		sb.append("    creData: ").append(toIndentedString(creData)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

}
