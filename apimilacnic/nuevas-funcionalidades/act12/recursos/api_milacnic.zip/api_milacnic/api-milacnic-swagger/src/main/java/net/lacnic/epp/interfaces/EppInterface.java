package net.lacnic.epp.interfaces;

import net.lacnic.registro.api.request.ASNRequest;
import net.lacnic.registro.api.request.IpRequest;
import net.lacnic.registro.api.request.OrgRequest;
import net.lacnic.registro.api.request.TipoContacto;
import net.lacnic.registro.api.request.UserRequest;
import net.lacnic.registro.api.response.ResponseObject;

/**
 * Interfaz que define los métodos expuestos por el cliente.
 *
 */
public interface EppInterface {

	/**
	 * 
	 * @param org
	 * @return
	 * @throws Exception
	 */
	ResponseObject editarOrganizacion(OrgRequest org, String nombreOrg) throws Exception;

	/**
	 * 
	 * @param org
	 * @return
	 * @throws Exception
	 */
	ResponseObject crearOrganizacionLACNIC(OrgRequest org, String nombreOrg) throws Exception;

	ResponseObject editarOrganizacionContacto(String user, String ip, String identificadorOrganizacion, String handleContacto, TipoContacto tipoContacto) throws Exception;

	ResponseObject editarOrganizacionContactos(OrgRequest org) throws Exception;

	/**
	 * 
	 * @param user
	 * @return
	 * @throws Exception
	 */
	ResponseObject modificarUsuario(UserRequest user) throws Exception;

	/**
	 * 
	 * @param user
	 * @return
	 * @throws Exception
	 */
	ResponseObject crearUsuarioLACNIC(UserRequest user) throws Exception;

	ResponseObject crearUsuarioLACNIC(String xml) throws Exception;

	ResponseObject infoIP(IpRequest ip) throws Exception;

	ResponseObject createIP(IpRequest ip, String nombreOrg) throws Exception;

	ResponseObject editarIP(IpRequest ip, String nombreOrg) throws Exception;

	ResponseObject editarAsnAnnouncerIP(IpRequest ip) throws Exception;

	ResponseObject editarIPContacto(IpRequest ip) throws Exception;

	ResponseObject deleteIP(IpRequest ip, String nombreOrg) throws Exception;

	ResponseObject createDomain(IpRequest ip, String nombreOrg) throws Exception;

	ResponseObject deleteDomain(IpRequest ip, String nombreOrg) throws Exception;

	/**
	 * Subasigna recursos y crea la organización que será dueña del bloque
	 * subasignado
	 * 
	 * @param ip
	 * @return
	 * 
	 * @throws Exception
	 */
	ResponseObject subasignarYCrearOrg(IpRequest ip, String nombreOrg) throws Exception;

	String infoASN(ASNRequest ip) throws Exception;

	ResponseObject editarASNContacto(ASNRequest asn) throws Exception;

	ResponseObject editarIPContactoYAsn(IpRequest ip, String nombreOrg) throws Exception;

	ResponseObject infoOrg(OrgRequest org) throws Exception;

	ResponseObject infoUsuario(UserRequest user) throws Exception;

}
