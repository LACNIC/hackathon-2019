package net.lacnic.api.response;

public class IPNetworkChildNetwork {

	private IPNetworkIPRange ipRange = new IPNetworkIPRange();
	private String roid = "";

	public IPNetworkChildNetwork() {
	}

	public IPNetworkIPRange getIpRange() {
		return ipRange;
	}

	public void setIpRange(IPNetworkIPRange ipRange) {
		this.ipRange = ipRange;
	}

	public String getRoid() {
		return roid;
	}

	public void setRoid(String roid) {
		this.roid = roid;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class IPNetworkChildNetwork {\n");
		sb.append("    ipRange: ").append(toIndentedString(ipRange)).append("\n");
		sb.append("    roid: ").append(toIndentedString(roid)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

}
