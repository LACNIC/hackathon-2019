package net.lacnic.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * IpDelegarUpdateDTO
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2019-01-10T12:54:03.514Z[GMT]")

public class IpDelegarUpdateDTO {

	@JsonProperty("hostnamesAdd")
	@Valid
	private List<String> hostnamesAdd = new ArrayList<>();

	public IpDelegarUpdateDTO hostnamesAdd(List<String> hostnamesAdd) {
		this.hostnamesAdd = hostnamesAdd;
		return this;
	}

	public IpDelegarUpdateDTO addHostnamesAddItem(String hostnameAddItem) {
		if (this.hostnamesAdd == null) {
			this.hostnamesAdd = new ArrayList<String>();
		}
		this.hostnamesAdd.add(hostnameAddItem);
		return this;
	}

	/**
	 * Get hostnamesAdd
	 * 
	 * @return hostnamesAdd
	 **/
	@ApiModelProperty(value = "")

	public List<String> getHostnamesAdd() {
		return hostnamesAdd;
	}

	public void setHostnamesAdd(List<String> hostnamesAdd) {
		this.hostnamesAdd = hostnamesAdd;
	}

	@Override
	public boolean equals(java.lang.Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		IpDelegarUpdateDTO ip = (IpDelegarUpdateDTO) o;
		return Objects.equals(this.hostnamesAdd, ip.hostnamesAdd);
	}

	@Override
	public int hashCode() {
		return Objects.hash(hostnamesAdd);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class IpDelegarUpdateDTO {\n");
		sb.append("    hostnamesAdd: ").append(toIndentedString(hostnamesAdd)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}
}
