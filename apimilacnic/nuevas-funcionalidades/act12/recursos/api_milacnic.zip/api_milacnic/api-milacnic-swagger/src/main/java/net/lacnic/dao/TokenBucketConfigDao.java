package net.lacnic.dao;

import java.sql.Connection;
import java.util.List;

import javax.sql.DataSource;

import org.skife.jdbi.v2.DBI;
import org.skife.jdbi.v2.Handle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.stereotype.Component;

import net.lacnic.domain.TokenBucketConfig;

@Component
public class TokenBucketConfigDao {

	@Qualifier("dsApi")
	@Autowired
	private DataSource dataSource;

	public TokenBucketConfigSQLs connectionTokenBucketConfig() {
		Connection conn = DataSourceUtils.getConnection(dataSource);
		Handle handle = DBI.open(conn);
		TokenBucketConfigSQLs tbcSQLs = handle.attach(TokenBucketConfigSQLs.class);
		return tbcSQLs;
	}

	public List<TokenBucketConfig> listTBConfig() {
		TokenBucketConfigSQLs tbcSQLs = connectionTokenBucketConfig();
		return tbcSQLs.listTBConfig();
	}

	public TokenBucketConfig obtenerDefaultTokenBucket() {
		TokenBucketConfigSQLs tbcSQLs = connectionTokenBucketConfig();
		return tbcSQLs.obtenerDefaultTokenBucketByOrgId();
	}

	public List<TokenBucketConfig> obtenerOtrosTokenBucket() {
		TokenBucketConfigSQLs tbcSQLs = connectionTokenBucketConfig();
		return tbcSQLs.obtenerOtrosTokenBucket();
	}

	public TokenBucketConfig insert(TokenBucketConfig tokenBucketConfig) {
		TokenBucketConfigSQLs tbcSQLs = connectionTokenBucketConfig();
		tbcSQLs.insertTBC(tokenBucketConfig);
		return tokenBucketConfig;
	}

	public Integer getCantTokenBucketConfig() {
		TokenBucketConfigSQLs tbcSQLs = connectionTokenBucketConfig();
		return tbcSQLs.getCantTokenBucketConfig();
	}

	public List<TokenBucketConfig> obtenerNoEstanEnTokenBucketOrg(String orgId) {
		TokenBucketConfigSQLs tbcSQLs = connectionTokenBucketConfig();
		return tbcSQLs.obtenerNoEstanEnTokenBucketOrg(orgId);
	}

}
