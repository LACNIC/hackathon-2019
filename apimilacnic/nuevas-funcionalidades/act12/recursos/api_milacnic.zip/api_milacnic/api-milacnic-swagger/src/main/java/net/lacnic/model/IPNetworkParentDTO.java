package net.lacnic.model;

import java.util.Objects;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * IPNetworkParentDTO
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2019-01-10T12:54:03.514Z[GMT]")

public class IPNetworkParentDTO {

	@JsonProperty("ipnetwork_range")
	private IPNetworkRangeDTO ipnetworkRange = new IPNetworkRangeDTO();

	@JsonProperty("roid")
	private String roid = null;

	/**
	 * Get ipnetworkRange
	 *
	 * @return ipnetworkRange
	 *
	 */
	@ApiModelProperty(value = "")

	@Valid

	public IPNetworkRangeDTO getIpnetworkRange() {
		return ipnetworkRange;
	}

	public void setIpnetworkRange(IPNetworkRangeDTO ipnetworkRange) {
		this.ipnetworkRange = ipnetworkRange;
	}

	/**
	 * Get roid
	 *
	 * @return roid
	 *
	 */
	@ApiModelProperty(value = "")

	public String getRoid() {
		return roid;
	}

	public void setRoid(String roid) {
		this.roid = roid;
	}

	@Override
	public boolean equals(java.lang.Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		IPNetworkParentDTO ipParent = (IPNetworkParentDTO) o;
		return Objects.equals(this.ipnetworkRange, ipParent.ipnetworkRange) && Objects.equals(this.roid, ipParent.roid);
	}

	@Override
	public int hashCode() {
		return Objects.hash(roid, ipnetworkRange);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class IPNetworkParentDTO {\n");
		sb.append("    ipnetworkRange: ").append(toIndentedString(ipnetworkRange)).append("\n");
		sb.append("    roid: ").append(toIndentedString(roid)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

}
