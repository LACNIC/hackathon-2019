package net.lacnic.registro.api.response;

import java.io.Serializable;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

@XStreamAlias("ipnetwork:ipRangeInfo")
public class IPNetworkIPRangeInfo implements Serializable {
	@XStreamAsAttribute
	String version; // attribute

	@XStreamAlias("ipnetwork:startAddress")
	String startAddress;

	@XStreamAlias("ipnetwork:endAddress")
	String endAddress;

	@XStreamImplicit(itemFieldName = "ipnetwork:reverseDNS")
	List<IPNetworkReverseDNS> reverse;

	@XStreamImplicit(itemFieldName = "ipnetwork:childNetwork")
	List<String> childNetwork;

	@XStreamAlias("ipnetwork:roid")
	String roid;

	@XStreamAlias("ipnetwork:asn")
	String asn;

	@XStreamAlias("ipnetwork:allocType")
	String allocType;

	@XStreamAlias("ipnetwork:organization")
	String organization;

	@XStreamImplicit(itemFieldName = "ipnetwork:contact")
	List<IPNetworkContact> contact;

	@XStreamAlias("ipnetwork:parentNetwork")
	IPNetworkParent parentNetwork;

	@XStreamAlias("ipnetwork:clID")
	String clID;

	@XStreamAlias("ipnetwork:crID")
	String crID;

	@XStreamAlias("ipnetwork:crDate")
	String crDate;

	@XStreamAlias("ipnetwork:upDate")
	String upDate;

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getStartAddress() {
		return startAddress;
	}

	public void setStartAddress(String startAddress) {
		this.startAddress = startAddress;
	}

	public String getEndAddress() {
		return endAddress;
	}

	public void setEndAddress(String endAddress) {
		this.endAddress = endAddress;
	}

	public List<String> getChildNetwork() {
		return childNetwork;
	}

	public void setChildNetwork(List<String> childNetwork) {
		this.childNetwork = childNetwork;
	}

	public String getRoid() {
		return roid;
	}

	public void setRoid(String roid) {
		this.roid = roid;
	}

	public String getAllocType() {
		return allocType;
	}

	public void setAllocType(String allocType) {
		this.allocType = allocType;
	}

	public String getOrganization() {
		return organization;
	}

	public void setOrganization(String organization) {
		this.organization = organization;
	}

	public List<IPNetworkContact> getContact() {
		return contact;
	}

	public void setContact(List<IPNetworkContact> contact) {
		this.contact = contact;
	}

	public IPNetworkParent getParentNetwork() {
		return parentNetwork;
	}

	public void setParentNetwork(IPNetworkParent parentNetwork) {
		this.parentNetwork = parentNetwork;
	}

	public String getClID() {
		return clID;
	}

	public void setClID(String clID) {
		this.clID = clID;
	}

	public String getCrDate() {
		return crDate;
	}

	public void setCrDate(String crDate) {
		this.crDate = crDate;
	}

	public String getUpDate() {
		return upDate;
	}

	public void setUpDate(String upDate) {
		this.upDate = upDate;
	}

}
