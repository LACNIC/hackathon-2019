package net.lacnic.api;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import net.lacnic.model.AsnDTO;
import springfox.documentation.annotations.ApiIgnore;

@RunWith(SpringRunner.class)
@SpringBootTest
@ApiIgnore
public class AsnsApiControllerIntegrationTest {

	@Autowired
	private AsnsApi api;

	@Test
	public void asnsIdGetTest() throws Exception {
		String id = "id_example";
		ResponseEntity<Object> responseEntity = api.asnsIdGet(id);
		assertEquals(HttpStatus.NOT_IMPLEMENTED, responseEntity.getStatusCode());
	}

	@Test
	public void asnsIdPutTest() throws Exception {
		AsnDTO body = new AsnDTO();
		long id = 0;
		ResponseEntity<Void> responseEntity = api.asnsIdPut(body, id);
		assertEquals(HttpStatus.NOT_IMPLEMENTED, responseEntity.getStatusCode());
	}

}
