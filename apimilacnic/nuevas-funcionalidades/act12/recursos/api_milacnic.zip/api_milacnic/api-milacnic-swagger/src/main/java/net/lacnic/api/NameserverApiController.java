package net.lacnic.api;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;

import com.auth0.jwt.JWT;
import com.auth0.jwt.exceptions.JWTDecodeException;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.swagger.annotations.ApiParam;
import net.lacnic.ejb.service.impl.ApiAdminServices;
import net.lacnic.epp.util.ResponseWs;
import net.lacnic.registro.api.request.IPNetworkRange;
import net.lacnic.registro.api.request.IpRequest;
import net.lacnic.registro.api.response.ResponseObject;
import net.lacnic.tb.StorageTokenBucket;
import net.lacnic.utils.RateLimit;
import net.lacnic.utils.SocketFactory;
import net.ripe.ipresource.IpRange;
import net.ripe.ipresource.IpResourceType;
import springfox.documentation.annotations.ApiIgnore;

@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2019-01-07T15:51:50.032Z[GMT]")

@ApiIgnore
@Controller
public class NameserverApiController implements NameserverApi {

	private static final Logger LOGGER = LoggerFactory.getLogger(NameserverApiController.class);

	private final ObjectMapper objectMapper;

	private final HttpServletRequest request;

	@Autowired
	ApiAdminServices apiAdminService;

	@org.springframework.beans.factory.annotation.Autowired
	public NameserverApiController(ObjectMapper objectMapper, HttpServletRequest request) {
		this.objectMapper = objectMapper;
		this.request = request;
	}

	public ResponseEntity<Object> nameserverPrefixGet(@ApiParam(value = "", required = true) @PathVariable("prefix") String prefix, @ApiParam(value = "", required = true) @PathVariable("prefixLength") String prefixLength) {
		String accept = request.getHeader("Accept");
		String ip = request.getRemoteAddr();
		String user = "ANU";
		LOGGER.info("EJECUTANDO Obtener **");
		try {
			// Ratelimit
			String token = request.getHeader("Authorization");
			String clientId = "";
			if (token != null && token.startsWith("Bearer")) {
				Authentication auth = SecurityContextHolder.getContext().getAuthentication();
				if (auth.getName().contains("@")) {
					String[] clients = auth.getName().split("@");
					clientId = clients[0];
					System.out.println("+++****El clientId es:" + clientId);
				} else {
					try {
						DecodedJWT jwt = JWT.decode(auth.getCredentials().toString());
						clientId = jwt.getClaims().get("azp").asString();
						System.out.println("+++****El clientId es:" + clientId);
					} catch (JWTDecodeException exception) {
						// Invalid token
					}
				}
				if (apiAdminService.existeOrgConfig(clientId)) {
					apiAdminService.insertarTokensBucketOrg(clientId);

					StorageTokenBucket storageTokenBucket = new StorageTokenBucket(apiAdminService);
					String idOrgRequest = apiAdminService.obtenerOrgConfig(clientId).getIdOrgConfig();
					LOGGER.info("Operación ejecutada por la organización " + idOrgRequest);
					if (!storageTokenBucket.tryConsumeAction(idOrgRequest, RateLimit.HOSTNAME_INFO)) {
						LOGGER.warn("No tiene consultas disponibles");
						return new ResponseEntity<Object>(HttpStatus.TOO_MANY_REQUESTS);
					}
				} else {
					LOGGER.warn("Organización no autorizada");
					return new ResponseEntity<Object>(HttpStatus.UNAUTHORIZED);
				}
			} else {
				LOGGER.warn("Token incorrecto");
				return new ResponseEntity<Object>(HttpStatus.UNAUTHORIZED);
			}
			// Ratelimit
			String estructuraCidr = prefix + "/" + prefixLength;
			System.out.println("estructuraCirdddddddd: " + estructuraCidr);

			IpRange ipRange = IpRange.parse(estructuraCidr);
			String version = "";
			if (ipRange.getType().equals(IpResourceType.IPv4)) {
				version = "v4";
			} else if (ipRange.getType().equals(IpResourceType.IPv6)) {
				version = "v6";
			}
			LOGGER.info("Valores del IpRange, inicial: " + ipRange.getStart().toString() + ", final: " + ipRange.getEnd().toString() + ", version: " + version);
			IPNetworkRange ipNR = new IPNetworkRange(ipRange.getStart().toString(), ipRange.getEnd().toString(), version);
			IpRequest ipRequest = new IpRequest(user, ip);
			ipRequest.setIpnetwork_range(ipNR);

			ResponseWs res = obtenerNameserver(ipRequest);
			if (res != null) {
				LOGGER.info("ResponseWS NO devolvió nulo");
				return new ResponseEntity<Object>(HttpStatus.OK);
			} else {
				LOGGER.warn("ResponseWS SI devolvió nulo");
				return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			LOGGER.error("Ha ocurrido el siguiente error: " + e);
			return new ResponseEntity<Object>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	public ResponseWs obtenerNameserver(IpRequest ipRequest) {
		// No está hecho
		try {
			ResponseObject responseObject = SocketFactory.getInstance().getEppExternalConnection().infoIP(ipRequest);
			return new ResponseWs(responseObject.getResponse());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}
