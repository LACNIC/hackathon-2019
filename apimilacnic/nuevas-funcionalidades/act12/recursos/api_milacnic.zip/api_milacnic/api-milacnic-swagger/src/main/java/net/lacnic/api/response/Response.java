package net.lacnic.api.response;

import java.util.LinkedList;
import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;

public class Response {

	@JacksonXmlElementWrapper(useWrapping = false)
	private List<Result> result = new LinkedList<>();
	private ResData resData = new ResData();
	private Extension extension = new Extension();
	private TrId trID = new TrId();

	public Response() {
	}

	public List<Result> getResult() {
		return result;
	}

	public void setResult(List<Result> result) {
		this.result = result;
	}

	public ResData getResData() {
		return resData;
	}

	public void setResData(ResData resData) {
		this.resData = resData;
	}

	public Extension getExtension() {
		return extension;
	}

	public void setExtension(Extension extension) {
		this.extension = extension;
	}

	public TrId getTrID() {
		return trID;
	}

	public void setTrID(TrId trID) {
		this.trID = trID;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class Response {\n");
		sb.append("    result: ").append(toIndentedString(result)).append("\n");
		sb.append("    resData: ").append(toIndentedString(resData)).append("\n");
		sb.append("    extension: ").append(toIndentedString(extension)).append("\n");
		sb.append("    trID: ").append(toIndentedString(trID)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

}
