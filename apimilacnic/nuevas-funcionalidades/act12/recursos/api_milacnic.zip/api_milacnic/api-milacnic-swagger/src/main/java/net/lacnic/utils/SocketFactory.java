package net.lacnic.utils;

import net.lacnic.epp.EppAdminConnection;
import net.lacnic.epp.EppExternalConnection;
import net.lacnic.epp.pooling.EppAdminConnectionFactory;
import net.lacnic.epp.pooling.EppExternalConnectionFactory;

public class SocketFactory {

	private static SocketFactory instance;
	private static EppExternalConnection eppExternalConnection;
	private static EppAdminConnection eppAdminConnection;

	private SocketFactory() {
	}

	public static SocketFactory getInstance() {
		if (instance == null) {
			instance = new SocketFactory();
		}
		return instance;
	}

	public EppExternalConnection getEppExternalConnection() {

		if (eppExternalConnection == null) {
			try {
				eppExternalConnection = new EppExternalConnectionFactory().create();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return eppExternalConnection;
	}

	public EppAdminConnection getEppAdminConnection() {

		// if (eppAdminConnection == null) {
		try {
			eppAdminConnection = new EppAdminConnectionFactory().create();
		} catch (Exception e) {
			e.printStackTrace();
		}
		// }
		return eppAdminConnection;
	}

	public void invalidate() {
		instance = null;
		eppExternalConnection = null;
		eppAdminConnection = null;
	}
}
