package net.lacnic.dao;

import java.util.List;

import org.skife.jdbi.v2.sqlobject.Bind;
import org.skife.jdbi.v2.sqlobject.BindBean;
import org.skife.jdbi.v2.sqlobject.GetGeneratedKeys;
import org.skife.jdbi.v2.sqlobject.SqlQuery;
import org.skife.jdbi.v2.sqlobject.SqlUpdate;
import org.skife.jdbi.v2.sqlobject.customizers.RegisterMapper;

import net.lacnic.domain.TokenBucketConfig;

@RegisterMapper(TokenBucketConfigMapper.class)
public interface TokenBucketConfigSQLs {

	@SqlQuery("SELECT * FROM TokenBucketConfig")
	List<TokenBucketConfig> listTBConfig();

	@SqlUpdate("INSERT into TokenBucketConfig (id, bucketSize, periodMinToRerill, tokensToAdd)" + " values(:id, :bucketSize, :periodMinToRerill, :tokensToAdd) ")
	@GetGeneratedKeys
	Integer insertTBC(@BindBean TokenBucketConfig test);

	@SqlQuery("SELECT count(*) FROM TokenBucketConfig")
	Integer getCantTokenBucketConfig();

	@SqlQuery("SELECT * FROM TokenBucketConfig WHERE id='DEFAULT'")
	TokenBucketConfig obtenerDefaultTokenBucketByOrgId();

	@SqlQuery("SELECT * FROM TokenBucketConfig WHERE id!='DEFAULT'")
	List<TokenBucketConfig> obtenerOtrosTokenBucket();

	@SqlQuery("SELECT * FROM TokenBucketConfig tbc WHERE tbc.id NOT IN (SELECT tbo.tokenBucketConfig FROM TokenBucketOrg tbo WHERE tbo.organization=:organization)")
	List<TokenBucketConfig> obtenerNoEstanEnTokenBucketOrg(@Bind("organization") String organization);
}
