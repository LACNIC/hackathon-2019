package net.lacnic.api.response;

import net.lacnic.model.IPNetworkRangeDTO;

public class IPNetworkIPRange {

	private String version = "";
	private String startAddress = "";
	private String endAddress = "";

	public IPNetworkIPRange() {
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getStartAddress() {
		return startAddress;
	}

	public void setStartAddress(String startAddress) {
		this.startAddress = startAddress;
	}

	public String getEndAddress() {
		return endAddress;
	}

	public void setEndAddress(String endAddress) {
		this.endAddress = endAddress;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class IPNetworkIPRange {\n");
		sb.append("    version: ").append(toIndentedString(version)).append("\n");
		sb.append("    startAddress: ").append(toIndentedString(startAddress)).append("\n");
		sb.append("    endAddress: ").append(toIndentedString(endAddress)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

	// Se usa en el convertirIP
	public IPNetworkRangeDTO convertToDto(IPNetworkIPRange ipNetworkIPRange) {
		IPNetworkRangeDTO ipNetworkRangeDTO = new IPNetworkRangeDTO();
		ipNetworkRangeDTO.setStartAddress(ipNetworkIPRange.getStartAddress());
		ipNetworkRangeDTO.setEndAddress(ipNetworkIPRange.getEndAddress());
		ipNetworkRangeDTO.setVersion(ipNetworkIPRange.getVersion());

		return ipNetworkRangeDTO;
	}

}
