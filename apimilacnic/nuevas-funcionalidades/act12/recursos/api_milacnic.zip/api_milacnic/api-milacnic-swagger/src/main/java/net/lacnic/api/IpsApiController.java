package net.lacnic.api;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.auth0.jwt.JWT;
import com.auth0.jwt.exceptions.JWTDecodeException;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.swagger.annotations.ApiParam;
import net.lacnic.ejb.service.impl.ApiAdminServices;
import net.lacnic.epp.util.ResponseWs;
import net.lacnic.model.IpDTO;
import net.lacnic.model.IpSubasignarDTO;
import net.lacnic.model.IpSubasignarUpdateDTO;
import net.lacnic.registro.api.request.Contact;
import net.lacnic.registro.api.request.IPNetworkRange;
import net.lacnic.registro.api.request.IpRequest;
import net.lacnic.registro.api.request.OrgRequest;
import net.lacnic.registro.api.request.TipoContacto;
import net.lacnic.tb.StorageTokenBucket;
import net.lacnic.utils.RateLimit;
import net.lacnic.utils.SocketFactory;
import net.ripe.ipresource.IpRange;
import net.ripe.ipresource.IpResourceType;

@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2019-01-07T15:51:50.032Z[GMT]")

@Controller
public class IpsApiController implements IpsApi {

	private static final Logger LOGGER = LoggerFactory.getLogger(IpsApiController.class);

	private final ObjectMapper objectMapper;

	private final HttpServletRequest request;

	private final String userOrgEPP = "SERGIO";

	@Autowired
	ApiAdminServices apiAdminService;

	@org.springframework.beans.factory.annotation.Autowired
	public IpsApiController(ObjectMapper objectMapper, HttpServletRequest request) {
		this.objectMapper = objectMapper;
		this.request = request;
	}

	// Eliminar Bloque Ip
	public ResponseEntity<Object> ipsPrefixDelete(@ApiParam(value = "", required = true) @PathVariable("prefix") String prefix, @ApiParam(value = "", required = true) @PathVariable("prefixLength") String prefixLength) {
		String accept = request.getHeader("Accept");
		String ip = request.getRemoteAddr();
		String user = "";
		String idOrgRequest = "";
		LOGGER.info("**EJECUTANDO Eliminar Subasignación**");
		try {
			// Ratelimit
			String token = request.getHeader("Authorization");
			String clientId = "";
			if (token != null && token.startsWith("Bearer")) {
				Authentication auth = SecurityContextHolder.getContext().getAuthentication();
				if (auth.getName().contains("@")) {
					String[] clients = auth.getName().split("@");
					clientId = clients[0];
				} else {
					try {
						DecodedJWT jwt = JWT.decode(auth.getCredentials().toString());
						clientId = jwt.getClaims().get("azp").asString();
					} catch (JWTDecodeException exception) {
						// Invalid token
					}
				}
				if (apiAdminService.existeOrgConfig(clientId)) {
					apiAdminService.insertarTokensBucketOrg(clientId);

					StorageTokenBucket storageTokenBucket = new StorageTokenBucket(apiAdminService);
					idOrgRequest = apiAdminService.obtenerOrgConfig(clientId).getIdOrgConfig();
					LOGGER.info("Operación ejecutada por la organización " + idOrgRequest);
					OrgRequest org = new OrgRequest(userOrgEPP, ip, idOrgRequest);
					apiAdminService.obtenerOrgEppAdmin(org);
					user = apiAdminService.convertirOrg(SocketFactory.getInstance().getEppAdminConnection().getFrameOrg()).getAdminContact();
					if (!storageTokenBucket.tryConsumeAction(idOrgRequest, RateLimit.SUBASIGNAR_DELETE)) {
						LOGGER.warn("No tiene consultas disponibles");
						return new ResponseEntity<Object>(HttpStatus.TOO_MANY_REQUESTS);
					}
				} else {
					LOGGER.warn("Organización no autorizada");
					return new ResponseEntity<Object>(HttpStatus.UNAUTHORIZED);
				}
			} else {
				LOGGER.warn("Token incorrecto");
				return new ResponseEntity<Object>(HttpStatus.UNAUTHORIZED);
			}
			// Ratelimit
			String estructuraCidr = prefix + "/" + prefixLength;
			IpRange ipRange = IpRange.parse(estructuraCidr);
			String version = "";
			if (ipRange.getType().equals(IpResourceType.IPv4)) {
				version = "v4";
			} else if (ipRange.getType().equals(IpResourceType.IPv6)) {
				version = "v6";
			}
			// ******************
			IPNetworkRange ipNR = new IPNetworkRange(ipRange.getStart().toString(), ipRange.getEnd().toString(), version);
			IpRequest ipRequest = new IpRequest(user, ip);
			ipRequest.setIpnetwork_range(ipNR);
			apiAdminService.obtenerBloqueIp(ipRequest);
			String roid = apiAdminService.convertirIP().getRoid();
			System.out.println("+++*****El roid es : " + roid);
			// ***********
			ipRequest.setRoid(roid);
			ResponseWs res = apiAdminService.eliminarBloqueIp(ipRequest, idOrgRequest);
			System.out.println("+++*****El res es : " + res);
			String trId = apiAdminService.infoMetodoEPP();
			System.out.println("+++*****El trId es : " + trId);
			if (res != null) {
				LOGGER.info("ResponseWS NO devolvió nulo");
				LOGGER.info("Info del TRID:\n" + trId);
				return ResponseEntity.ok(trId);
			} else {
				LOGGER.warn("ResponseWS SI devolvió nulo");
				return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			LOGGER.error("Ha ocurrido el siguiente error: " + e);
			return new ResponseEntity<Object>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	// GET Subasignacion
	public ResponseEntity<Object> ipsPrefixGet(@ApiParam(value = "", required = true) @PathVariable("prefix") String prefix, @ApiParam(value = "", required = true) @PathVariable("prefixLength") String prefixLength) {
		String accept = request.getHeader("Accept");
		String ip = request.getRemoteAddr();
		String user = "";
		LOGGER.info("**EJECUTANDO Obtener BloqueIP**");
		try {
			// Ratelimit
			String token = request.getHeader("Authorization");
			String clientId = "";
			if (token != null && token.startsWith("Bearer")) {
				Authentication auth = SecurityContextHolder.getContext().getAuthentication();
				if (auth.getName().contains("@")) {
					String[] clients = auth.getName().split("@");
					clientId = clients[0];
				} else {
					try {
						DecodedJWT jwt = JWT.decode(auth.getCredentials().toString());
						clientId = jwt.getClaims().get("azp").asString();
					} catch (JWTDecodeException exception) {
						// Invalid token
					}
				}
				if (apiAdminService.existeOrgConfig(clientId)) {
					apiAdminService.insertarTokensBucketOrg(clientId);

					StorageTokenBucket storageTokenBucket = new StorageTokenBucket(apiAdminService);
					String idOrgRequest = apiAdminService.obtenerOrgConfig(clientId).getIdOrgConfig();
					LOGGER.info("Operación ejecutada por la organización " + idOrgRequest);
					OrgRequest org = new OrgRequest(userOrgEPP, ip, idOrgRequest);
					apiAdminService.obtenerOrgEppAdmin(org);
					String xml = SocketFactory.getInstance().getEppAdminConnection().getFrameOrg();
					System.out.println("+++++****Este es el xml que le paso al convertirOrg: " + xml + "******++++++");
					user = apiAdminService.convertirOrg(xml).getAdminContact();
					if (!storageTokenBucket.tryConsumeAction(idOrgRequest, RateLimit.SUBASIGNAR_INFO)) {
						LOGGER.warn("No tiene consultas disponibles");
						return new ResponseEntity<Object>(HttpStatus.TOO_MANY_REQUESTS);
					}
				} else {
					LOGGER.warn("Organización no autorizada");
					return new ResponseEntity<Object>(HttpStatus.UNAUTHORIZED);
				}
			} else {
				LOGGER.warn("Token incorrecto");
				return new ResponseEntity<Object>(HttpStatus.UNAUTHORIZED);
			}
			// Ratelimit
			String estructuraCidr = prefix + "/" + prefixLength;
			IpRange ipRange = IpRange.parse(estructuraCidr);
			String version = "";
			if (ipRange.getType().equals(IpResourceType.IPv4)) {
				version = "v4";
			} else if (ipRange.getType().equals(IpResourceType.IPv6)) {
				version = "v6";
			}
			IPNetworkRange ipNR = new IPNetworkRange(ipRange.getStart().toString(), ipRange.getEnd().toString(), version);
			IpRequest ipRequest = new IpRequest(user, ip);
			ipRequest.setIpnetwork_range(ipNR);

			ResponseWs res = apiAdminService.obtenerBloqueIp(ipRequest);
			if (res != null) {
				LOGGER.info("ResponseWS NO devolvió nulo");
				IpDTO datos = apiAdminService.convertirIP();
				return ResponseEntity.ok(datos);
			} else {
				LOGGER.warn("ResponseWS SI devolvió nulo");
				return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			LOGGER.error("Ha ocurrido el siguiente error: " + e);
			return new ResponseEntity<Object>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	// Editar Bloque Ip
	public ResponseEntity<Object> ipsPrefixPut(@ApiParam(value = "Estos son los datos necesarios para realizar la operación.", required = true) @Valid @RequestBody IpSubasignarUpdateDTO body, @ApiParam(value = "", required = true) @PathVariable("prefix") String prefix, @ApiParam(value = "", required = true) @PathVariable("prefixLength") String prefixLength) {
		String accept = request.getHeader("Accept");
		String ip = request.getRemoteAddr();
		String user = "";
		String idOrgRequest = "";
		LOGGER.info("**EJECUTANDO Editar Subasignación**");
		try {
			// Ratelimit
			String token = request.getHeader("Authorization");
			String clientId = "";
			if (token != null && token.startsWith("Bearer")) {
				Authentication auth = SecurityContextHolder.getContext().getAuthentication();
				if (auth.getName().contains("@")) {
					String[] clients = auth.getName().split("@");
					clientId = clients[0];
				} else {
					try {
						DecodedJWT jwt = JWT.decode(auth.getCredentials().toString());
						clientId = jwt.getClaims().get("azp").asString();
					} catch (JWTDecodeException exception) {
						// Invalid token
					}
				}
				if (apiAdminService.existeOrgConfig(clientId)) {
					apiAdminService.insertarTokensBucketOrg(clientId);

					StorageTokenBucket storageTokenBucket = new StorageTokenBucket(apiAdminService);
					idOrgRequest = apiAdminService.obtenerOrgConfig(clientId).getIdOrgConfig();
					LOGGER.info("Operación ejecutada por la organización " + idOrgRequest);
					OrgRequest org = new OrgRequest(userOrgEPP, ip, idOrgRequest);
					apiAdminService.obtenerOrgEppAdmin(org);
					user = apiAdminService.convertirOrg(SocketFactory.getInstance().getEppAdminConnection().getFrameOrg()).getAdminContact();
					if (!storageTokenBucket.tryConsumeAction(idOrgRequest, RateLimit.SUBASIGNAR_UPDATE)) {
						LOGGER.warn("No tiene consultas disponibles");
						return new ResponseEntity<Object>(HttpStatus.TOO_MANY_REQUESTS);
					}
				} else {
					LOGGER.warn("Organización no autorizada");
					return new ResponseEntity<Object>(HttpStatus.UNAUTHORIZED);
				}
			} else {
				LOGGER.warn("Token incorrecto");
				return new ResponseEntity<Object>(HttpStatus.UNAUTHORIZED);
			}
			// Ratelimit
			String estructuraCidr = prefix + "/" + prefixLength;
			IpRange ipRange = IpRange.parse(estructuraCidr);
			String version = "";
			if (ipRange.getType().equals(IpResourceType.IPv4)) {
				version = "v4";
			} else if (ipRange.getType().equals(IpResourceType.IPv6)) {
				version = "v6";
			}
			// ************
			IPNetworkRange ipNR = new IPNetworkRange(ipRange.getStart().toString(), ipRange.getEnd().toString(), version);
			IpRequest ipRequestOR = new IpRequest(user, ip);
			ipRequestOR.setIpnetwork_range(ipNR);
			apiAdminService.obtenerBloqueIp(ipRequestOR);
			String roid = apiAdminService.convertirIP().getRoid();
			// *************
			List<Contact> contacts = new ArrayList<Contact>();
			contacts.add(new Contact(body.getTechContact(), TipoContacto.TECH));
			contacts.add(new Contact(body.getAbuseContact(), TipoContacto.ABUSE));

			ipRequestOR.setRoid(roid);
			ipRequestOR.setContacts(contacts);
			ipRequestOR.setAsn(body.getAsn());

			ResponseWs res = apiAdminService.editarIPContactoYAsn(ipRequestOR, idOrgRequest);
			String trId = apiAdminService.infoMetodoEPP();
			if (res != null) {
				LOGGER.info("ResponseWS NO devolvió nulo");
				LOGGER.info("Info del TRID:\n" + trId);
				return ResponseEntity.ok(trId);
			} else {
				LOGGER.warn("ResponseWS SI devolvió nulo");
				return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			LOGGER.error("Ha ocurrido el siguiente error: " + e);
			return new ResponseEntity<Object>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	// Crear Bloque Ip(Subasignar)
	public ResponseEntity<Object> ipsPost(@ApiParam(value = "Estos son los datos necesarios para realizar la operación.", required = true) @Valid @RequestBody IpSubasignarDTO body) {
		String accept = request.getHeader("Accept");
		String ip = request.getRemoteAddr();
		String user = "";
		String idOrgRequest = "";
		LOGGER.info("**EJECUTANDO Subasignar**");
		try {
			// Ratelimit
			String token = request.getHeader("Authorization");
			String clientId = "";
			if (token != null && token.startsWith("Bearer")) {
				Authentication auth = SecurityContextHolder.getContext().getAuthentication();
				if (auth.getName().contains("@")) {
					String[] clients = auth.getName().split("@");
					clientId = clients[0];
				} else {
					try {
						DecodedJWT jwt = JWT.decode(auth.getCredentials().toString());
						clientId = jwt.getClaims().get("azp").asString();
					} catch (JWTDecodeException exception) {
						// Invalid token
					}
				}
				if (apiAdminService.existeOrgConfig(clientId)) {
					apiAdminService.insertarTokensBucketOrg(clientId);

					StorageTokenBucket storageTokenBucket = new StorageTokenBucket(apiAdminService);
					idOrgRequest = apiAdminService.obtenerOrgConfig(clientId).getIdOrgConfig();
					LOGGER.info("Operación ejecutada por la organización " + idOrgRequest);
					OrgRequest org = new OrgRequest(userOrgEPP, ip, idOrgRequest);
					apiAdminService.obtenerOrgEppAdmin(org);
					user = apiAdminService.convertirOrg(SocketFactory.getInstance().getEppAdminConnection().getFrameOrg()).getAdminContact();
					if (!storageTokenBucket.tryConsumeAction(idOrgRequest, RateLimit.SUBASIGNAR)) {
						LOGGER.warn("No tiene consultas disponibles");
						return new ResponseEntity<Object>(HttpStatus.TOO_MANY_REQUESTS);
					}
				} else {
					LOGGER.warn("Organización no autorizada");
					return new ResponseEntity<Object>(HttpStatus.UNAUTHORIZED);
				}
			} else {
				LOGGER.warn("Token incorrecto");
				return new ResponseEntity<Object>(HttpStatus.UNAUTHORIZED);
			}
			// Ratelimit
			OrgRequest orgDestino = new OrgRequest(user, ip, body.getDestinationOrg());
			IpRange ipRange = IpRange.parse(body.getCidr());
			String version = "";
			if (ipRange.getType().equals(IpResourceType.IPv4)) {
				version = "v4";
			} else if (ipRange.getType().equals(IpResourceType.IPv6)) {
				version = "v6";
			}
			IPNetworkRange ipNR = new IPNetworkRange(ipRange.getStart().toString(), ipRange.getEnd().toString(), version);
			IpRequest ipRequest = new IpRequest(user, ip, orgDestino, body.getStatusAllocation(), ipNR, body.getTechContact());
			apiAdminService.modificarContactosBloqueIp(body.getTechContact(), body.getAbuseContact(), ipRequest);
			ResponseWs res = apiAdminService.crearBloqueIp(ipRequest, idOrgRequest);
			String trId = apiAdminService.infoMetodoEPP();
			if (res != null) {
				LOGGER.info("ResponseWS NO devolvió nulo");
				LOGGER.info("Info del TRID:\n" + trId);
				return ResponseEntity.ok(trId);
			} else {
				LOGGER.warn("ResponseWS SI devolvió nulo");
				return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			LOGGER.error("Ha ocurrido el siguiente error: " + e);
			return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
		}
	}

}
