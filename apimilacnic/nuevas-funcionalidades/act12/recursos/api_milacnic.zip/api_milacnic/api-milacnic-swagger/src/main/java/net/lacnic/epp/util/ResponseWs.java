package net.lacnic.epp.util;


import java.io.Serializable;

import net.lacnic.registro.api.response.Response;

public class ResponseWs implements Serializable {

	private String result;
	private String resData;
	private String extension;
	private String trID;

	public ResponseWs(Response r) {
		// this.result = r.getResult() != null ? r.getResultToString() : "";
		this.result = "ok";
		this.resData = r.getResData() != null ? r.getResData().toString() : "";
		this.extension = r.getExtension() != null ? r.getExtension().toString() : "";
		this.trID = r.getTrID() != null ? r.getTrID().toString() : "";
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getResData() {
		return resData;
	}

	public void setResData(String resData) {
		this.resData = resData;
	}

	public String getExtension() {
		return extension;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	}

	public String getTrID() {
		return trID;
	}

	public void setTrID(String trID) {
		this.trID = trID;
	}

}
