package net.lacnic.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class TokenBucketOrg implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "idTokenBucketOrg")
	private String idTokenBucketOrg;

	@Column
	private String tokenBucketConfig;

	@Column
	private Integer bucketSize;

	@Column
	private Integer tokensToAdd;

	@Column
	private Integer periodMinToRerill;

	@Column
	private String organization;

	public TokenBucketOrg() {
	}

	public String getIdTokenBucketOrg() {
		return idTokenBucketOrg;
	}

	public void setIdTokenBucketOrg(String idTokenBucketOrg) {
		this.idTokenBucketOrg = idTokenBucketOrg;
	}

	public Integer getBucketSize() {
		return bucketSize;
	}

	public void setBucketSize(Integer bucketSize) {
		this.bucketSize = bucketSize;
	}

	public Integer getTokensToAdd() {
		return tokensToAdd;
	}

	public void setTokensToAdd(Integer tokensToAdd) {
		this.tokensToAdd = tokensToAdd;
	}

	public Integer getPeriodMinToRerill() {
		return periodMinToRerill;
	}

	public void setPeriodMinToRerill(Integer periodMinToRerill) {
		this.periodMinToRerill = periodMinToRerill;
	}

	public String getOrganization() {
		return organization;
	}

	public void setOrganization(String organization) {
		this.organization = organization;
	}

	public String getTokenBucketConfig() {
		return tokenBucketConfig;
	}

	public void setTokenBucketConfig(String tokenBucketConfig) {
		this.tokenBucketConfig = tokenBucketConfig;
	}

}
