package net.lacnic.api;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import net.lacnic.model.OrganizationCreateDTO;
import net.lacnic.model.OrganizationUpdateDTO;
import net.lacnic.model.UserCreateDTO;
import springfox.documentation.annotations.ApiIgnore;

@RunWith(SpringRunner.class)
@SpringBootTest
public class EntityApiControllerIntegrationTest {

	@Autowired
	private EntityApi api;

	@Test
	public void entityOrganizationsOrgIdGetTest() throws Exception {
		String orgId = "orgId_example";
		ResponseEntity<Object> responseEntity = api.entityOrganizationsOrgIdGet(orgId);
		assertEquals(HttpStatus.NOT_IMPLEMENTED, responseEntity.getStatusCode());
	}

	@Test
	public void entityOrganizationsOrgIdPutTest() throws Exception {
		OrganizationUpdateDTO body = new OrganizationUpdateDTO();
		String orgId = "orgId_example";
		ResponseEntity<Object> responseEntity = api.entityOrganizationsOrgIdPut(body, orgId);
		assertEquals(HttpStatus.NOT_IMPLEMENTED, responseEntity.getStatusCode());
	}

	@Test
	public void entityOrganizationsPostTest() throws Exception {
		OrganizationCreateDTO body = new OrganizationCreateDTO();
		ResponseEntity<Object> responseEntity = api.entityOrganizationsPost(body);
		assertEquals(HttpStatus.NOT_IMPLEMENTED, responseEntity.getStatusCode());
	}

	@Test
	@ApiIgnore
	public void entityUsersIdPutTest() throws Exception {
		UserCreateDTO body = new UserCreateDTO();
		String id = "id_example";
		ResponseEntity<Object> responseEntity = api.entityUsersIdPut(body, id);
		assertEquals(HttpStatus.NOT_IMPLEMENTED, responseEntity.getStatusCode());
	}

	@Test
	@ApiIgnore
	public void entityUsersPostTest() throws Exception {
		UserCreateDTO body = new UserCreateDTO();
		ResponseEntity<Object> responseEntity = api.entityUsersPost(body);
		assertEquals(HttpStatus.NOT_IMPLEMENTED, responseEntity.getStatusCode());
	}

	@Test
	public void entityUsersIdGetTest() throws Exception {
		String id = "id_example";
		ResponseEntity<Object> responseEntity = api.entityUsersIdGet(id);
		assertEquals(HttpStatus.NOT_IMPLEMENTED, responseEntity.getStatusCode());
	}
}
