package net.lacnic.model;

import java.util.Objects;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * UserDTO
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2019-01-10T12:54:03.514Z[GMT]")

public class UserDTO {

	@JsonProperty("name")
	private String name = null;

	@JsonProperty("email")
	private String email = null;

	@JsonProperty("language")
	private String language = null;

	@JsonProperty("address")
	private AddressDTO address = null;

	@JsonProperty("phone")
	private PhoneDTO phone = null;

	public UserDTO name(String name) {
		this.name = name;
		return this;
	}

	/**
	 * Get name
	 *
	 * @return name
	 *
	 */
	@ApiModelProperty(value = "")

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public UserDTO email(String email) {
		this.email = email;
		return this;
	}

	/**
	 * Get email
	 *
	 * @return email
	 *
	 */
	@ApiModelProperty(value = "")

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public UserDTO language(String language) {
		this.language = language;
		return this;
	}

	/**
	 * Get language
	 *
	 * @return language
	 *
	 */
	@ApiModelProperty(value = "")

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public UserDTO address(AddressDTO address) {
		this.address = address;
		return this;
	}

	/**
	 * Get address
	 *
	 * @return address
	 *
	 */
	@ApiModelProperty(value = "")

	@Valid

	public AddressDTO getAddress() {
		return address;
	}

	public void setAddress(AddressDTO address) {
		this.address = address;
	}

	public UserDTO phone(PhoneDTO phone) {
		this.phone = phone;
		return this;
	}

	/**
	 * Get phone
	 *
	 * @return phone
	 *
	 */
	@ApiModelProperty(value = "")

	@Valid

	public PhoneDTO getPhone() {
		return phone;
	}

	public void setPhone(PhoneDTO phone) {
		this.phone = phone;
	}

	@Override
	public boolean equals(java.lang.Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		UserDTO usuarioDTO = (UserDTO) o;
		return Objects.equals(this.name, usuarioDTO.name) && Objects.equals(this.email, usuarioDTO.email) && Objects.equals(this.language, usuarioDTO.language) && Objects.equals(this.address, usuarioDTO.address) && Objects.equals(this.phone, usuarioDTO.phone);
	}

	@Override
	public int hashCode() {
		return Objects.hash(name, email, language, address, phone);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class UserDTO {\n");
		sb.append("    name: ").append(toIndentedString(name)).append("\n");
		sb.append("    email: ").append(toIndentedString(email)).append("\n");
		sb.append("    language: ").append(toIndentedString(language)).append("\n");
		sb.append("    address: ").append(toIndentedString(address)).append("\n");
		sb.append("    phone: ").append(toIndentedString(phone)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}
}
