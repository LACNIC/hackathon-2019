package net.lacnic.model;

import java.util.Objects;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;
import net.lacnic.registro.api.request.IPNetworkRange;
import net.ripe.ipresource.IpAddress;
import net.ripe.ipresource.IpRange;

/**
 * IPNetworkRangeDTO
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2019-01-10T12:54:03.514Z[GMT]")
// **Se usa para modelar los datos del Get**
public class IPNetworkRangeDTO {
	@JsonProperty("start_address")
	private String startAddress = null;

	@JsonProperty("end_address")
	private String endAddress = null;

	@JsonProperty("version")
	private String version = null;

	@JsonProperty("prefixLength")
	private int prefixLength = 0;

	public IPNetworkRangeDTO startAddress(String startAddress) {
		this.startAddress = startAddress;
		return this;
	}

	/**
	 * Get startAddress
	 * 
	 * @return startAddress
	 **/
	@ApiModelProperty(value = "")

	public String getStartAddress() {
		return startAddress;
	}

	public void setStartAddress(String startAddress) {
		this.startAddress = startAddress;
	}

	public IPNetworkRangeDTO endAddress(String endAddress) {
		this.endAddress = endAddress;
		return this;
	}

	/**
	 * Get endAddress
	 * 
	 * @return endAddress
	 **/
	@ApiModelProperty(value = "")

	public String getEndAddress() {
		return endAddress;
	}

	public void setEndAddress(String endAddress) {
		this.endAddress = endAddress;
	}

	public IPNetworkRangeDTO version(String version) {
		this.version = version;
		return this;
	}

	/**
	 * Get version
	 * 
	 * @return version
	 **/
	@ApiModelProperty(value = "")

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public IPNetworkRangeDTO prefixLength(int prefixLength) {
		this.prefixLength = prefixLength;
		return this;
	}

	/**
	 * Get prefixLength
	 * 
	 * @return prefixLength
	 **/
	@ApiModelProperty(value = "")

	public int getPrefixLength() {
		return this.calcularPrefijo();
	}

	public void setPrefixLength(int prefixLength) {
		this.prefixLength = prefixLength;
	}

	@Override
	public boolean equals(java.lang.Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		IPNetworkRangeDTO ipNetworkRange = (IPNetworkRangeDTO) o;
		return Objects.equals(this.startAddress, ipNetworkRange.startAddress) && Objects.equals(this.endAddress, ipNetworkRange.endAddress) && Objects.equals(this.version, ipNetworkRange.version) && Objects.equals(this.prefixLength, ipNetworkRange.prefixLength);
	}

	@Override
	public int hashCode() {
		return Objects.hash(startAddress, endAddress, version, prefixLength);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class IPNetworkRangeDTO {\n");
		sb.append("    startAddress: ").append(toIndentedString(startAddress)).append("\n");
		sb.append("    endAddress: ").append(toIndentedString(endAddress)).append("\n");
		sb.append("    version: ").append(toIndentedString(version)).append("\n");
		sb.append("    prefixLength: ").append(toIndentedString(prefixLength)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

	public IPNetworkRange converterToModel(final IPNetworkRangeDTO ipNRDTO) {
		final IPNetworkRange ipNR = new IPNetworkRange();
		ipNR.setStart_address(ipNRDTO.getStartAddress());
		ipNR.setEnd_address(ipNRDTO.getEndAddress());
		ipNR.setVersion(ipNRDTO.getVersion());
		return ipNR;
	}

	public int calcularPrefijo() {
		IpRange ipR = IpRange.range(IpAddress.parse(getStartAddress()), IpAddress.parse(getEndAddress()));
		return ipR.getPrefixLength();
	}
}
