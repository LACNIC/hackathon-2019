package net.lacnic.registro.api.response;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("trID")
public class TrId  implements Serializable{
	@XStreamAlias("clTRID")
	String clTRID;
	@XStreamAlias("svTRID")
	String svTRID;
	
	@Override
	public String toString() {
		return "TrId [clTRID=" + clTRID + ", svTRID=" + svTRID + "]";
	}

	public TrId() {
	}
}
