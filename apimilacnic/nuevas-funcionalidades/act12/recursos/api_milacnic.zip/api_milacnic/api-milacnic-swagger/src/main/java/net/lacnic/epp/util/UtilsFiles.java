package net.lacnic.epp.util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InterruptedIOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import javax.net.ssl.SSLSocket;

import net.lacnic.registro.api.response.Frame;

public class UtilsFiles {
	protected final static int INT_SZ = 4;
	private final static String GREETING = "<greeting>";

	public static byte[] getBytesFromFile(File file) throws IOException {
		InputStream is = new FileInputStream(file);
		// Get the size of the file
		long length = file.length();

		// You cannot create an array using a long type.
		// It needs to be an int type.
		// Before converting to an int type, check
		// to ensure that file is not larger than Integer.MAX_VALUE.
		if (length > Integer.MAX_VALUE) {
			// File is too large
		}

		// Create the byte array to hold the data
		byte[] bytes = new byte[(int) length];

		// Read in the bytes
		int offset = 0;
		int numRead = 0;
		while (offset < bytes.length && (numRead = is.read(bytes, offset, bytes.length - offset)) >= 0) {
			offset += numRead;
		}

		// Ensure all the bytes have been read in
		if (offset < bytes.length) {
			throw new IOException("Could not completely read file " + file.getName());
		}
		// Close the input stream and return bytes
		is.close();

		return bytes;
	}

	public static void writeResponses(String nombreOrg, String value) {
		try {
			Properties properties = new Properties();
			properties.load(new FileInputStream("src/main/resources/application.properties"));

			String directorioLogs = properties.getProperty("directorio.logs");
			System.out.println("++++++******Este es el valor de la variable de la carpeta de rollback: " + directorioLogs);
			// Se le pone por defecto la fecha y hora como nombre al fichero, por si no se
			// puede obtener el código de la operación
			String nombFile = formatDate();
			// Convertir el XML en un arreglo, según los saltos de línea, para buscar la
			// línea que tiene el código y definir el nombre del fichero
			if (value != null && !value.isEmpty() && value.contains("<svTRID>")) {
				String[] arrayValue = value.split("<svTRID>");
				if (arrayValue.length > 0) {
					String[] arrayCodigo = arrayValue[1].split("</");
					nombFile = arrayCodigo[0];
				}
				// Ruta de la carpeta base hasta el nombre de la organización
				File rollbackDir = new File(directorioLogs + "rollback/" + nombreOrg);
				File fichero = new File(directorioLogs + "rollback/" + nombreOrg + "/" + nombFile + ".txt");

				if (!rollbackDir.exists()) {
					rollbackDir.mkdirs();
				}
				fichero.createNewFile();
				BufferedWriter writer = new BufferedWriter(new FileWriter(fichero));
				writer.write(value);
				writer.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void writeRequests(String nombreOrg, String value) {
		try {
			Properties properties = new Properties();
			properties.load(new FileInputStream("src/main/resources/application.properties"));

			String directorioLogs = properties.getProperty("directorio.logs");
			String nombFile = formatDate();

			if (value != null && !value.isEmpty() && value.contains("<clTRID>")) {
				String[] arrayValue = value.split("<clTRID>");
				if (arrayValue.length > 0) {
					String[] arrayLineaCodigo = arrayValue[1].split("-");
					if (arrayLineaCodigo.length > 3) {
						String[] arrayCodigo = arrayValue[1].split("-")[3].split("</");
						nombFile = arrayCodigo[0];
					}
				}
				File rollbackDir = new File(directorioLogs + "rollback/" + nombreOrg);
				File fichero = new File(directorioLogs + "rollback/" + nombreOrg + "/" + nombFile + ".txt");

				if (!rollbackDir.exists()) {
					rollbackDir.mkdirs();
				}
				fichero.createNewFile();
				BufferedWriter writer = new BufferedWriter(new FileWriter(fichero));
				writer.write(value);
				writer.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static String formatDate() {
		Date date = new Date();
		SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		return formato.format(date);
	}

	public static Frame getFrame(InputStream in_stream) throws Exception {

		int len = 0;
		try {
			len = readBufferSize(in_stream);
		} catch (Exception e) {
			throw new Exception("Failed to read from server [" + e.getClass().toString() + "] [" + e.getMessage() + "]");
		}

		if (len <= 0) {
			return null;
		}

		len -= INT_SZ;

		byte[] in_buf = null;
		try {
			in_buf = readInputBuffer(in_stream, len);
		} catch (Exception e) {
			throw new Exception("Failed to read from server [" + e.getClass().toString() + "] [" + e.getMessage() + "]");

		}

		String value = new String(in_buf);

		if (!value.contains(GREETING)) {
			value = value.replace("   ", "\n");
		}
		return new Frame(value);
	}

	public static void writeFrame(String xml_to_server, OutputStream out_stream) throws Exception {

		try {
			// if (!xml_to_server.contains("<login>"))
			// ;
			int len = xml_to_server.getBytes().length;
			writeBufferSize(out_stream, len + INT_SZ);
			out_stream.write(xml_to_server.getBytes(), 0, len);
			// out_stream.write(xml_to_server.getBytes());
			out_stream.flush();
		} catch (Exception e) {
			throw new Exception("Failed to write to server [" + e.getClass().toString() + "] [" + e.getMessage() + "]");
		}
	}

	public static void disconnect(SSLSocket sslSocket, InputStream in_stream) throws IOException {
		try {
			if (sslSocket != null) {
				sslSocket.close();
			}
			sslSocket = null;

			if (in_stream != null) {
				in_stream.close();
			}
			in_stream = null;

		} catch (IOException e) {
			throw e;
		}

	}

	protected static int readBufferSize(InputStream in) throws Exception {
		int inbuf_sz = 0;
		byte[] in_buf = new byte[INT_SZ];

		int len = 0;
		int bytesRead = 0;
		while (bytesRead < INT_SZ) {
			try {
				len = in.read(in_buf, bytesRead, INT_SZ - bytesRead);
			} catch (IOException e) {
				// System.out.println("getFrame: IOException:" +
				// e.getMessage());
				if (e instanceof InterruptedIOException)
					throw e;
				return -1;
			}
			if (len < 0) {
				return -1;
			}
			bytesRead += len;
		}

		return (((in_buf[0] & 0xff) << 24) | ((in_buf[1] & 0xff) << 16) | ((in_buf[2] & 0xff) << 8) | (in_buf[3] & 0xff));

	}

	protected static byte[] readInputBuffer(InputStream in, int inbuf_sz) throws Exception {
		byte[] in_buf = new byte[inbuf_sz];

		int len = 0;
		int bytesRead = 0;
		while (bytesRead < inbuf_sz) {
			try {
				len = in.read(in_buf, bytesRead, inbuf_sz - bytesRead);
			} catch (IOException e) {
				if (e instanceof InterruptedIOException)
					throw e;
				return null;
			}
			if (len < 0) {
				return null;
			}
			bytesRead += len;
		}
		return in_buf;
	}

	protected static void writeBufferSize(OutputStream out, int buf_sz) throws IOException {
		byte[] out_buf = new byte[INT_SZ];
		out_buf[0] = (byte) (0xff & (buf_sz >> 24));
		out_buf[1] = (byte) (0xff & (buf_sz >> 16));
		out_buf[2] = (byte) (0xff & (buf_sz >> 8));
		out_buf[3] = (byte) (0xff & buf_sz);

		out.write(out_buf, 0, INT_SZ);
	}
}
