package net.lacnic.tb;

import java.util.HashMap;

public class TokenBucket {

	private String id;
	private int bucketSize;
	private int tokensToAdd;
	private int periodMinToRerill;

	private HashMap<String, int[]> buckets = new HashMap<String, int[]>();
	private int bucketAction = 1;

	public TokenBucket(int bucketSize, int tokensToAdd, int periodMinToRerill) {
		this("DEFAULT", bucketSize, tokensToAdd, periodMinToRerill);
	}

	public TokenBucket(String id, int bucketSize, int tokensToAdd, int periodMinToRerill) {
		this.id = id;
		this.bucketSize = bucketSize;
		this.tokensToAdd = tokensToAdd;
		this.periodMinToRerill = periodMinToRerill;
	}

	// public boolean tryConsume(String ip) {
	// int[] valueWrapper = buckets.get(ip);
	//
	// if (valueWrapper == null) {
	// buckets.put(ip, new int[] { 1 });
	// valueWrapper = buckets.get(ip);
	// } else {
	// if (valueWrapper[0] < bucketSize) {
	// valueWrapper[0]++;
	// } else {
	// System.out.println("[CONSUME] " + ip + " no puede hacer mas consultas,
	// alcanzó el limite de: " + bucketSize + " consultas");
	// return false;
	// }
	// }
	// System.out.println("[CONSUME] " + ip + " tiene: " + valueWrapper[0] + "
	// consultas hechas, el limite es: " + bucketSize + " consultas");
	// return true;
	// }

	public boolean tryConsume() {
		System.out.println("Entro al tryConsume() ded TokenBucket");
		if (bucketAction < bucketSize) {
			bucketAction++;
			System.out.println("[CONSUME] " + id + " tiene: " + bucketAction + " consultas hechas, el limite es: " + bucketSize + " consultas");
			return true;
		} else {
			System.out.println("[CONSUME] " + id + " no puede hacer mas consultas, alcanzó el limite de: " + bucketSize + " consultas");
			return false;
		}
	}

	public void refillDefault() {
		buckets.forEach((k, v) -> {
			int bucket = buckets.get(k)[0];
			v[0] = buckets.get(k)[0] - tokensToAdd;
			if (v[0] < 0)
				v[0] = 0;

			System.out.println("[REFILL] " + k + " Tenia: " + bucket + " consultas hechas, ahora tiene: " + v[0] + " consultas hechas");
		});
		buckets.entrySet().removeIf(e -> e.getValue()[0] <= 0);

	}

	public void refillAction() {
		int oldbucketAction = bucketAction;
		bucketAction = bucketAction - tokensToAdd;
		if (bucketAction < 0)
			bucketAction = 0;

		System.out.println("[REFILL] " + id + " Tenia: " + oldbucketAction + " consultas hechas, ahora tiene: " + bucketAction + " consultas hechas");

	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getBucketSize() {
		return bucketSize;
	}

	public void setBucketSize(int bucketSize) {
		this.bucketSize = bucketSize;
	}

	public int getPeriodMinToRerill() {
		return periodMinToRerill;
	}

	public void setPeriodMinToRerill(int periodMinToRerill) {
		this.periodMinToRerill = periodMinToRerill;
	}

	public int getTokensToAdd() {
		return tokensToAdd;
	}

	public void setTokensToAdd(int tokensToAdd) {
		this.tokensToAdd = tokensToAdd;
	}

	public HashMap<String, int[]> getBuckets() {
		return buckets;
	}

	public void setBuckets(HashMap<String, int[]> buckets) {
		this.buckets = buckets;
	}

	public int getBucketAction() {
		return bucketAction;
	}

	public void setBucketAction(int bucketAction) {
		this.bucketAction = bucketAction;
	}

}
