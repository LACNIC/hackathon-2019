package net.lacnic.api.response;

public class TrId {

	private String clTRID = "";
	private String svTRID = "";

	public TrId() {
	}

	public String getClTRID() {
		return clTRID;
	}

	public void setClTRID(String clTRID) {
		this.clTRID = clTRID;
	}

	public String getSvTRID() {
		return svTRID;
	}

	public void setSvTRID(String svTRID) {
		this.svTRID = svTRID;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class TrId {\n");
		sb.append("    clTRID: ").append(toIndentedString(clTRID)).append("\n");
		sb.append("    svTRID: ").append(toIndentedString(svTRID)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

}
