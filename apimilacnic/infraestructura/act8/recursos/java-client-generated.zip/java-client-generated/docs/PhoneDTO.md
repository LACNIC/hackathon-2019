# PhoneDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**countryCode** | **String** |  |  [optional]
**areaCode** | **String** |  |  [optional]
**phoneNumber** | **String** |  |  [optional]
**phoneExtension** | **String** |  |  [optional]
