# AsnDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**adminContact** | **String** |  |  [optional]
**cobContact** | **String** |  |  [optional]
**memContact** | **String** |  |  [optional]
