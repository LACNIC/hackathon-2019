# DsDataDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ipnetworkRange** | [**IPNetworkRangeDTO**](IPNetworkRangeDTO.md) |  |  [optional]
**keyTag** | **String** |  |  [optional]
**alg** | **String** |  |  [optional]
**digestType** | **String** |  |  [optional]
**digest** | **String** |  |  [optional]
