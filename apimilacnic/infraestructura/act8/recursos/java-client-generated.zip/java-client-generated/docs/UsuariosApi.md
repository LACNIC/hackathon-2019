# UsuariosApi

All URIs are relative to *https://virtserver.swaggerhub.com/Violet48/SugarAPI/1.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**entityUsersIdPut**](UsuariosApi.md#entityUsersIdPut) | **PUT** /entity/users/{id} | Editar usuario
[**entityUsersPost**](UsuariosApi.md#entityUsersPost) | **POST** /entity/users | Agregar usuario nuevo

<a name="entityUsersIdPut"></a>
# **entityUsersIdPut**
> entityUsersIdPut(body, id)

Editar usuario

Utilizada para editar un usuario, es necesario proveer el id del usuario y la información que se quiere editar en el mismo.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.UsuariosApi;


UsuariosApi apiInstance = new UsuariosApi();
UsuarioDTO body = new UsuarioDTO(); // UsuarioDTO | Estos son los datos necesarios para realizar la operación.
String id = "id_example"; // String | 
try {
    apiInstance.entityUsersIdPut(body, id);
} catch (ApiException e) {
    System.err.println("Exception when calling UsuariosApi#entityUsersIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**UsuarioDTO**](UsuarioDTO.md)| Estos son los datos necesarios para realizar la operación. |
 **id** | **String**|  |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: Not defined

<a name="entityUsersPost"></a>
# **entityUsersPost**
> entityUsersPost(body)

Agregar usuario nuevo

Utilizada para agregar un usuario nuevo, es necesario proveer la información del usuario que se va a crear.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.UsuariosApi;


UsuariosApi apiInstance = new UsuariosApi();
UsuarioDTO body = new UsuarioDTO(); // UsuarioDTO | Estos son los datos necesarios para realizar la operación.
try {
    apiInstance.entityUsersPost(body);
} catch (ApiException e) {
    System.err.println("Exception when calling UsuariosApi#entityUsersPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**UsuarioDTO**](UsuarioDTO.md)| Estos son los datos necesarios para realizar la operación. |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: Not defined

