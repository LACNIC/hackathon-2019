# AsnApi

All URIs are relative to *https://virtserver.swaggerhub.com/Violet48/SugarAPI/1.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**asnsIdGet**](AsnApi.md#asnsIdGet) | **GET** /asns/{id} | Obtener ASN
[**asnsIdPut**](AsnApi.md#asnsIdPut) | **PUT** /asns/{id} | Editar ASN

<a name="asnsIdGet"></a>
# **asnsIdGet**
> Object asnsIdGet(id)

Obtener ASN

Devuelve un ASN que coincida con el id especificado.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.AsnApi;


AsnApi apiInstance = new AsnApi();
String id = "id_example"; // String | 
try {
    Object result = apiInstance.asnsIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AsnApi#asnsIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |

### Return type

**Object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="asnsIdPut"></a>
# **asnsIdPut**
> asnsIdPut(body, id)

Editar ASN

Utilizada para editar un ASN, es necesario proveer el id del ASN y la información que se quiere editar en el mismo.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.AsnApi;


AsnApi apiInstance = new AsnApi();
AsnDTO body = new AsnDTO(); // AsnDTO | Estos son los datos necesarios para realizar la operación.
String id = "id_example"; // String | 
try {
    apiInstance.asnsIdPut(body, id);
} catch (ApiException e) {
    System.err.println("Exception when calling AsnApi#asnsIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**AsnDTO**](AsnDTO.md)| Estos son los datos necesarios para realizar la operación. |
 **id** | **String**|  |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: Not defined

