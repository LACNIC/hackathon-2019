# ContactDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**handle** | **String** |  |  [optional]
**tipoContacto** | **String** |  |  [optional]
