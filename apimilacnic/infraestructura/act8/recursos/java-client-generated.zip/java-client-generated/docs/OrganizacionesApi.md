# OrganizacionesApi

All URIs are relative to *https://virtserver.swaggerhub.com/Violet48/SugarAPI/1.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**entityOrganizationsOrgIdGet**](OrganizacionesApi.md#entityOrganizationsOrgIdGet) | **GET** /entity/organizations/{orgId} | Obtener organización
[**entityOrganizationsOrgIdPut**](OrganizacionesApi.md#entityOrganizationsOrgIdPut) | **PUT** /entity/organizations/{orgId} | Editar organización
[**entityOrganizationsPost**](OrganizacionesApi.md#entityOrganizationsPost) | **POST** /entity/organizations | Agregar entidad nueva

<a name="entityOrganizationsOrgIdGet"></a>
# **entityOrganizationsOrgIdGet**
> Object entityOrganizationsOrgIdGet(orgId)

Obtener organización

Devuelve una organización que coincida con el id especificado.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.OrganizacionesApi;


OrganizacionesApi apiInstance = new OrganizacionesApi();
String orgId = "orgId_example"; // String | 
try {
    Object result = apiInstance.entityOrganizationsOrgIdGet(orgId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OrganizacionesApi#entityOrganizationsOrgIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **orgId** | **String**|  |

### Return type

**Object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="entityOrganizationsOrgIdPut"></a>
# **entityOrganizationsOrgIdPut**
> entityOrganizationsOrgIdPut(body, orgId)

Editar organización

Utilizada para editar una organización, es necesario proveer el id de la entidad y la información que se quiere editar en la misma.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.OrganizacionesApi;


OrganizacionesApi apiInstance = new OrganizacionesApi();
OrganizacionDTO body = new OrganizacionDTO(); // OrganizacionDTO | Estos datos son necesarios para realizar la operación.
String orgId = "orgId_example"; // String | 
try {
    apiInstance.entityOrganizationsOrgIdPut(body, orgId);
} catch (ApiException e) {
    System.err.println("Exception when calling OrganizacionesApi#entityOrganizationsOrgIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**OrganizacionDTO**](OrganizacionDTO.md)| Estos datos son necesarios para realizar la operación. |
 **orgId** | **String**|  |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: Not defined

<a name="entityOrganizationsPost"></a>
# **entityOrganizationsPost**
> entityOrganizationsPost(body)

Agregar entidad nueva

Utilizada para agregar una entidad nueva, es necesario proveer la información de la entidad que se va a crear.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.OrganizacionesApi;


OrganizacionesApi apiInstance = new OrganizacionesApi();
OrganizacionDTO body = new OrganizacionDTO(); // OrganizacionDTO | Estos son los datos necesarios para realizar la operación.
try {
    apiInstance.entityOrganizationsPost(body);
} catch (ApiException e) {
    System.err.println("Exception when calling OrganizacionesApi#entityOrganizationsPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**OrganizacionDTO**](OrganizacionDTO.md)| Estos son los datos necesarios para realizar la operación. |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: Not defined

