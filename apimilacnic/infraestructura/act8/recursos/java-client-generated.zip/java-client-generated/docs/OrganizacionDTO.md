# OrganizacionDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  |  [optional]
**responsible** | **String** |  |  [optional]
**adminContact** | **String** |  |  [optional]
**cobContact** | **String** |  |  [optional]
**memContact** | **String** |  |  [optional]
**address** | [**AddressDTO**](AddressDTO.md) |  |  [optional]
**phone** | [**PhoneDTO**](PhoneDTO.md) |  |  [optional]
