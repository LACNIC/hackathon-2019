# IpDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**orgRequest** | [**OrganizacionDTO**](OrganizacionDTO.md) |  |  [optional]
**roid** | **String** |  |  [optional]
**ipnetworkRange** | [**IPNetworkRangeDTO**](IPNetworkRangeDTO.md) |  |  [optional]
**type** | **String** |  |  [optional]
**asn** | **String** |  |  [optional]
**contacts** | [**List&lt;ContactDTO&gt;**](ContactDTO.md) |  |  [optional]
**ipnetworkReversesDns** | [**List&lt;ReverseDNSDTO&gt;**](ReverseDNSDTO.md) |  |  [optional]
**ipnetworkReversesDnsAdd** | [**List&lt;ReverseDNSDTO&gt;**](ReverseDNSDTO.md) |  |  [optional]
**ipnetworkReversesDnsRem** | [**List&lt;ReverseDNSDTO&gt;**](ReverseDNSDTO.md) |  |  [optional]
**ipnetworkDsdataDns** | [**List&lt;DsDataDTO&gt;**](DsDataDTO.md) |  |  [optional]
**ipnetworkDsdataDnsAdd** | [**List&lt;DsDataDTO&gt;**](DsDataDTO.md) |  |  [optional]
**ipnetworkDsdataDnsRem** | [**List&lt;DsDataDTO&gt;**](DsDataDTO.md) |  |  [optional]
