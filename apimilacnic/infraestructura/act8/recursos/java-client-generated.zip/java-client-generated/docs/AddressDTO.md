# AddressDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**streetAddress** | **String** |  |  [optional]
**numberAddress** | **String** |  |  [optional]
**complementAddress** | **String** |  |  [optional]
**city** | **String** |  |  [optional]
**state** | **String** |  |  [optional]
**pc** | **String** |  |  [optional]
**country** | **String** |  |  [optional]
