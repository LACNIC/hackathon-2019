# BloquesIpApi

All URIs are relative to *https://virtserver.swaggerhub.com/Violet48/SugarAPI/1.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ipsPost**](BloquesIpApi.md#ipsPost) | **POST** /ips | Agregar bloque IP nuevo
[**ipsRoidDelete**](BloquesIpApi.md#ipsRoidDelete) | **DELETE** /ips/{roid} | Eliminar bloque IP
[**ipsRoidGet**](BloquesIpApi.md#ipsRoidGet) | **GET** /ips/{roid} | Obtener bloque IP
[**ipsRoidPut**](BloquesIpApi.md#ipsRoidPut) | **PUT** /ips/{roid} | Editar bloque IP

<a name="ipsPost"></a>
# **ipsPost**
> ipsPost(body)

Agregar bloque IP nuevo

Utilizada para agregar un bloque IP nuevo, es necesario proveer la información del bloque IP que se va a crear.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.BloquesIpApi;


BloquesIpApi apiInstance = new BloquesIpApi();
IpDTO body = new IpDTO(); // IpDTO | Estos son los datos necesarios para realizar la operación.
try {
    apiInstance.ipsPost(body);
} catch (ApiException e) {
    System.err.println("Exception when calling BloquesIpApi#ipsPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**IpDTO**](IpDTO.md)| Estos son los datos necesarios para realizar la operación. |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: Not defined

<a name="ipsRoidDelete"></a>
# **ipsRoidDelete**
> ipsRoidDelete(roid)

Eliminar bloque IP

Utilizada para eliminar un bloque IP, es necesario proveer el roid del bloque IP que se quiere eliminar.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.BloquesIpApi;


BloquesIpApi apiInstance = new BloquesIpApi();
String roid = "roid_example"; // String | 
try {
    apiInstance.ipsRoidDelete(roid);
} catch (ApiException e) {
    System.err.println("Exception when calling BloquesIpApi#ipsRoidDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **roid** | **String**|  |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="ipsRoidGet"></a>
# **ipsRoidGet**
> Object ipsRoidGet(roid)

Obtener bloque IP

Devuelve un bloque IP que coincida con el roid especificado.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.BloquesIpApi;


BloquesIpApi apiInstance = new BloquesIpApi();
String roid = "roid_example"; // String | 
try {
    Object result = apiInstance.ipsRoidGet(roid);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling BloquesIpApi#ipsRoidGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **roid** | **String**|  |

### Return type

**Object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="ipsRoidPut"></a>
# **ipsRoidPut**
> ipsRoidPut(body, roid)

Editar bloque IP

Utilizada para editar un bloque IP, es necesario proveer el roid del bloque IP y la información que se quiere editar en el mismo.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.BloquesIpApi;


BloquesIpApi apiInstance = new BloquesIpApi();
IpDTO body = new IpDTO(); // IpDTO | Estos son los datos necesarios para realizar la operación.
String roid = "roid_example"; // String | 
try {
    apiInstance.ipsRoidPut(body, roid);
} catch (ApiException e) {
    System.err.println("Exception when calling BloquesIpApi#ipsRoidPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**IpDTO**](IpDTO.md)| Estos son los datos necesarios para realizar la operación. |
 **roid** | **String**|  |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: Not defined

