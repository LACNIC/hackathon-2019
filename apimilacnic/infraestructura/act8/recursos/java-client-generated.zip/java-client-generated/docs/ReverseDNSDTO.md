# ReverseDNSDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ipnetworkRange** | [**IPNetworkRangeDTO**](IPNetworkRangeDTO.md) |  |  [optional]
**hostnames** | **List&lt;String&gt;** |  |  [optional]
