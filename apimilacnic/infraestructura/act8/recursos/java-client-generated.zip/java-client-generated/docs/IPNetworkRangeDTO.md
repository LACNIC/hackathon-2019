# IPNetworkRangeDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**startAddress** | **String** |  |  [optional]
**endAddress** | **String** |  |  [optional]
**version** | **String** |  |  [optional]
