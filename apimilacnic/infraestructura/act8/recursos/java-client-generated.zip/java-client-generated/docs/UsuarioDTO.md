# UsuarioDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  |  [optional]
**email** | **String** |  |  [optional]
**password** | **String** |  |  [optional]
**reminderPassword** | **String** |  |  [optional]
**language** | **String** |  |  [optional]
**address** | [**AddressDTO**](AddressDTO.md) |  |  [optional]
**phone** | [**PhoneDTO**](PhoneDTO.md) |  |  [optional]
