# ReversosApi

All URIs are relative to *https://virtserver.swaggerhub.com/Violet48/SugarAPI/1.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**domainsRoidDelete**](ReversosApi.md#domainsRoidDelete) | **DELETE** /domains/{roid} | Eliminar dominio
[**domainsRoidGet**](ReversosApi.md#domainsRoidGet) | **GET** /domains/{roid} | Obtener rango IP de dominio
[**domainsRoidPut**](ReversosApi.md#domainsRoidPut) | **PUT** /domains/{roid} | Editar dominio
[**nameserverRangoGet**](ReversosApi.md#nameserverRangoGet) | **GET** /nameserver/{rango} | Obtener dominio de rango IP

<a name="domainsRoidDelete"></a>
# **domainsRoidDelete**
> domainsRoidDelete(roid)

Eliminar dominio

Utilizada para eliminar un dominio, es necesario proveer el roid del dominio que se quiere eliminar.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ReversosApi;


ReversosApi apiInstance = new ReversosApi();
String roid = "roid_example"; // String | 
try {
    apiInstance.domainsRoidDelete(roid);
} catch (ApiException e) {
    System.err.println("Exception when calling ReversosApi#domainsRoidDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **roid** | **String**|  |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="domainsRoidGet"></a>
# **domainsRoidGet**
> Object domainsRoidGet(roid)

Obtener rango IP de dominio

Devuelve un rango IP que coincida con el DNS especificado.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ReversosApi;


ReversosApi apiInstance = new ReversosApi();
String roid = "roid_example"; // String | 
try {
    Object result = apiInstance.domainsRoidGet(roid);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ReversosApi#domainsRoidGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **roid** | **String**|  |

### Return type

**Object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="domainsRoidPut"></a>
# **domainsRoidPut**
> domainsRoidPut(body, roid)

Editar dominio

Utilizada para editar un dominio, es necesario proveer el roid del dominio y la información que se quiere editar en el mismo.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ReversosApi;


ReversosApi apiInstance = new ReversosApi();
IpDTO body = new IpDTO(); // IpDTO | Estos son los datos necesarios para realizar la operación.
String roid = "roid_example"; // String | 
try {
    apiInstance.domainsRoidPut(body, roid);
} catch (ApiException e) {
    System.err.println("Exception when calling ReversosApi#domainsRoidPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**IpDTO**](IpDTO.md)| Estos son los datos necesarios para realizar la operación. |
 **roid** | **String**|  |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: Not defined

<a name="nameserverRangoGet"></a>
# **nameserverRangoGet**
> Object nameserverRangoGet(rango)

Obtener dominio de rango IP

Devuelve un DNS que coincida con el rango IP especificado.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ReversosApi;


ReversosApi apiInstance = new ReversosApi();
String rango = "rango_example"; // String | 
try {
    Object result = apiInstance.nameserverRangoGet(rango);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ReversosApi#nameserverRangoGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **rango** | **String**|  |

### Return type

**Object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

