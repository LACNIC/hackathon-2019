package net.lacnic.registro.api.response;

import java.io.Serializable;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

@XStreamAlias("ipnetwork:reverseDNS")
public class IPNetworkReverseDNS implements Serializable {

	@XStreamAlias("ipnetwork:ipRange")
	IPNetworkIPRange ipRange;

	@XStreamImplicit(itemFieldName = "ipnetwork:hostName")
	List<String> hostName;

	public IPNetworkIPRange getIpRange() {
		return ipRange;
	}

	public void setIpRange(IPNetworkIPRange ipRange) {
		this.ipRange = ipRange;
	}

	public List<String> getHostName() {
		return hostName;
	}

	public void setHostName(List<String> hostName) {
		this.hostName = hostName;
	}

}
