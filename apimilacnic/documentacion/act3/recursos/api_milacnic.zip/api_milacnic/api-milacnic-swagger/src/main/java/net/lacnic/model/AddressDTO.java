package net.lacnic.model;

import java.util.Objects;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;
import net.lacnic.registro.api.request.Address;

/**
 * AddressDTO
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2019-01-10T12:54:03.514Z[GMT]")

public class AddressDTO {
	@JsonProperty("street_address")
	private String streetAddress;

	@JsonProperty("number_address")
	private String numberAddress;

	@JsonProperty("complement_address")
	private String complementAddress;

	@JsonProperty("city")
	private String city;

	@JsonProperty("state")
	private String state;

	@JsonProperty("pc")
	private String pc;

	// @JsonProperty("sp")
	// private String sp;

	@JsonProperty("country")
	private String country;

	public AddressDTO streetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
		return this;
	}

	/**
	 * Get streetAddress
	 * 
	 * @return streetAddress
	 **/
	@ApiModelProperty(value = "")

	public String getStreetAddress() {
		return streetAddress;
	}

	public void setStreetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
	}

	public AddressDTO numberAddress(String numberAddress) {
		this.numberAddress = numberAddress;
		return this;
	}

	/**
	 * Get numberAddress
	 * 
	 * @return numberAddress
	 **/
	@ApiModelProperty(value = "")

	public String getNumberAddress() {
		return numberAddress;
	}

	public void setNumberAddress(String numberAddress) {
		this.numberAddress = numberAddress;
	}

	public AddressDTO complementAddress(String complementAddress) {
		this.complementAddress = complementAddress;
		return this;
	}

	/**
	 * Get complementAddress
	 * 
	 * @return complementAddress
	 **/
	@ApiModelProperty(value = "")

	public String getComplementAddress() {
		return complementAddress;
	}

	public void setComplementAddress(String complementAddress) {
		this.complementAddress = complementAddress;
	}

	public AddressDTO city(String city) {
		this.city = city;
		return this;
	}

	/**
	 * Get city
	 * 
	 * @return city
	 **/
	@ApiModelProperty(value = "")

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public AddressDTO state(String state) {
		this.state = state;
		return this;
	}

	/**
	 * Get state
	 * 
	 * @return state
	 **/
	@ApiModelProperty(value = "")

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public AddressDTO pc(String pc) {
		this.pc = pc;
		return this;
	}

	/**
	 * Get pc
	 * 
	 * @return pc
	 **/
	@ApiModelProperty(value = "")

	public String getPc() {
		return pc;
	}

	public void setPc(String pc) {
		this.pc = pc;
	}

	// public AddressDTO sp(String sp) {
	// this.sp = sp;
	// return this;
	// }

	// /**
	// * Get sp
	// *
	// * @return sp
	// **/
	// @ApiModelProperty(value = "")
	//
	// public String getSp() {
	// return sp;
	// }
	//
	// public void setSp(String sp) {
	// this.sp = sp;
	// }

	public AddressDTO country(String country) {
		this.country = country;
		return this;
	}

	/**
	 * Get country
	 * 
	 * @return country
	 **/
	@ApiModelProperty(value = "")

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	@Override
	public boolean equals(java.lang.Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		AddressDTO address = (AddressDTO) o;
		return Objects.equals(this.streetAddress, address.streetAddress) && Objects.equals(this.numberAddress, address.numberAddress) && Objects.equals(this.complementAddress, address.complementAddress) && Objects.equals(this.city, address.city) && Objects.equals(this.state, address.state) && Objects.equals(this.pc, address.pc) && Objects.equals(this.country, address.country);
	}

	@Override
	public int hashCode() {
		return Objects.hash(streetAddress, numberAddress, complementAddress, city, state, pc, country);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class AddressDTO {\n");
		sb.append("    streetAddress: ").append(toIndentedString(streetAddress)).append("\n");
		sb.append("    numberAddress: ").append(toIndentedString(numberAddress)).append("\n");
		sb.append("    complementAddress: ").append(toIndentedString(complementAddress)).append("\n");
		sb.append("    city: ").append(toIndentedString(city)).append("\n");
		sb.append("    state: ").append(toIndentedString(state)).append("\n");
		sb.append("    pc: ").append(toIndentedString(pc)).append("\n");
		// sb.append(" sp: ").append(toIndentedString(sp)).append("\n");
		sb.append("    country: ").append(toIndentedString(country)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

	public Address converterToModel(AddressDTO addressDTO) {
		Address address = new Address();
		address.setStreet_address(addressDTO.getStreetAddress());
		address.setNumber_address(addressDTO.getNumberAddress());
		address.setComplement_address(addressDTO.getComplementAddress());
		address.setCity(addressDTO.getCity());
		address.setState(addressDTO.getState());
		address.setPc(addressDTO.getPc());
		address.setCountry(addressDTO.getCountry());
		return address;
	}

}
