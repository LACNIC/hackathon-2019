package net.lacnic.api;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.fasterxml.jackson.databind.ObjectMapper;

import io.swagger.annotations.ApiParam;
import net.lacnic.epp.util.ResponseWs;
import net.lacnic.model.AsnDTO;
import net.lacnic.registro.api.request.ASNRequest;
import net.lacnic.registro.api.request.Contact;
import net.lacnic.registro.api.response.ResponseObject;
import net.lacnic.utils.SocketFactory;

@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2019-01-07T15:51:50.032Z[GMT]")

@Controller
public class AsnsApiController implements AsnsApi {

	private static final Logger LOGGER = LoggerFactory.getLogger(AsnsApiController.class);

	private final ObjectMapper objectMapper;

	private final HttpServletRequest request;

	@org.springframework.beans.factory.annotation.Autowired
	public AsnsApiController(ObjectMapper objectMapper, HttpServletRequest request) {
		this.objectMapper = objectMapper;
		this.request = request;
	}

	public ResponseEntity<Object> asnsIdGet(@ApiParam(value = "", required = true) @PathVariable("id") String id) {
		String accept = request.getHeader("Accept");
		return new ResponseEntity<Object>(HttpStatus.NOT_IMPLEMENTED);
	}

	// Editar ASN-Probando**
	public ResponseEntity<Void> asnsIdPut(@ApiParam(value = "Estos son los datos necesarios para realizar la operación.", required = true) @Valid @RequestBody AsnDTO body, @ApiParam(value = "", required = true) @PathVariable("id") long id) {
		String accept = request.getHeader("Accept");
		String ip = request.getRemoteAddr();
		String user = request.getRemoteUser();

		ASNRequest asnRequest = new ASNRequest(user, ip, id);
		modificarContactos(body, asnRequest);
		ResponseWs res = editarASNContactos(asnRequest);
		if (res != null) {
			System.out.println("ResponseWS no devolvió nulo");
			return new ResponseEntity<Void>(HttpStatus.OK);
		}
		return new ResponseEntity<Void>(HttpStatus.BAD_REQUEST);
	}

	private void modificarContactos(AsnDTO body, ASNRequest asnRequest) {
		List<Contact> contacts = asnRequest.getContacts();
		if (body.getAdminContact() != null) {
			contacts.get(0).setHandle(body.getAdminContact());
		}
		if (body.getCobContact() != null) {
			contacts.get(1).setHandle(body.getCobContact());
		}
		if (body.getMemContact() != null) {
			contacts.get(2).setHandle(body.getMemContact());
		}
		asnRequest.setContacts(contacts);
	}

	public ResponseWs editarASNContactos(ASNRequest asnRequest) {
		try {
			ResponseObject responseObject = SocketFactory.getInstance().getEppExternalConnection().editarASNContacto(asnRequest);
			return new ResponseWs(responseObject.getResponse());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}
