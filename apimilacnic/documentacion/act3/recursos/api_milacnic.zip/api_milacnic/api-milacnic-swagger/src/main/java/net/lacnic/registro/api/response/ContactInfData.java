package net.lacnic.registro.api.response;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("contact:infData")
public class ContactInfData implements Serializable {

	private static final long serialVersionUID = -8603085385230437016L;

	@XStreamAlias("contact:id")
	String contactId;

	@XStreamAlias("contact:roid")
	String contactRoid;

	@XStreamAlias("contact:status")
	String contactStatus;

	@XStreamAlias("contact:postalInfo")
	String contactPostalInfo;

	@XStreamAlias("contact:voice")
	ContactPhone contactVoice;

	@XStreamAlias("contact:fax")
	String contactFax;

	@XStreamAlias("contact:email")
	String contactEmail;

	@XStreamAlias("contact:clID")
	String contactClID;

	@XStreamAlias("contact:crID")
	String contactCrID;

	@XStreamAlias("contact:crDate")
	String crDate;

	@XStreamAlias("contact:upDate")
	String upDate;
}
