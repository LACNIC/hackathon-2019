package net.lacnic.configuration;

import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import com.auth0.spring.security.api.JwtWebSecurityConfigurer;

@EnableWebSecurity
@Configuration
public class SecurityConfig extends WebSecurityConfigurerAdapter {

	private static final Logger LOGGER = LoggerFactory.getLogger(SecurityConfig.class);

	// YOUR_API_IDENTIFIER
	@Value("${auth0.apiAudience}")
	private String apiAudience;

	// YOUR_AUTH0_DOMAIN/
	@Value("${auth0.issuer}")
	private String issuer;

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		JwtWebSecurityConfigurer.forRS256(apiAudience, issuer).configure(http).authorizeRequests()
		.antMatchers(HttpMethod.POST, "/entity/organizations").hasAuthority("org:create")
		.antMatchers(HttpMethod.PUT, "/entity/organizations/{orgId}").hasAuthority("org:update")
		.antMatchers(HttpMethod.GET, "/entity/organizations/{orgId}").hasAuthority("org:info")
		.antMatchers(HttpMethod.GET, "/entity/users/{id}").hasAuthority("user:info")
		.antMatchers(HttpMethod.POST, "/ips").hasAuthority("subasignar:create")
		.antMatchers(HttpMethod.PUT, "/ips/{prefix}/{prefixLength}").hasAuthority("subasignar:update")
		.antMatchers(HttpMethod.DELETE, "/ips/{prefix}/{prefixLength}").hasAuthority("subasignar:delete")
		.antMatchers(HttpMethod.GET, "/ips/{prefix}/{prefixLength}").hasAuthority("ip:info")
		.antMatchers(HttpMethod.POST, "/domains").hasAuthority("delegar:create")
		.antMatchers(HttpMethod.PUT, "/domains/{prefix}/{prefixLength}").hasAuthority("delegar:update")
		.antMatchers(HttpMethod.DELETE, "/domains/{prefix}/{prefixLength}").hasAuthority("delegar:delete");
	}

	@Bean
	CorsConfigurationSource corsConfigurationSource() {
		CorsConfiguration configuration = new CorsConfiguration();
		configuration.setAllowedOrigins(Arrays.asList("http://localhost:3000"));
		configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE"));
		configuration.setAllowCredentials(true);
		configuration.addAllowedHeader("Authorization");
		UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		source.registerCorsConfiguration("/**", configuration);
		return source;
	}
}
