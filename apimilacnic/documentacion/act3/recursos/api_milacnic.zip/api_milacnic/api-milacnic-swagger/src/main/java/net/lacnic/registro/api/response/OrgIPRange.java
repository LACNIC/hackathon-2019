package net.lacnic.registro.api.response;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

@XStreamAlias("brorg:ipRange")
public class OrgIPRange implements Serializable {
	@XStreamAsAttribute
	String version; // attribute

	@XStreamAlias("brorg:startAddress")
	String startAddress;

	@XStreamAlias("brorg:endAddress")
	String endAddress;

}
