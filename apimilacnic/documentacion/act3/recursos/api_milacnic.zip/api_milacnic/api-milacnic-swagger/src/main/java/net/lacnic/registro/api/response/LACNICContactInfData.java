package net.lacnic.registro.api.response;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("lacniccontact:infData")
public class LACNICContactInfData implements Serializable {

	private static final long serialVersionUID = -8603085385230437016L;

	@XStreamAlias("lacniccontact:reminder")
	String reminder;

	@XStreamAlias("lacniccontact:language")
	String language;

	@XStreamAlias("lacniccontact:legacy")
	String legacy;

	@XStreamAlias("lacniccontact:property")
	String property;

	@XStreamAlias("contact:id")
	String contactId;

	@XStreamAlias("contact:roid")
	String contactRoid;

	@XStreamAlias("contact:status")
	String contactStatus;

	@XStreamAlias("contact:postalInfo")
	String contactPostalInfo;

	@XStreamAlias("contact:voice")
	String contactVoice;

	@XStreamAlias("contact:fax")
	String contactFax;

	@XStreamAlias("contact:email")
	String contactEmail;

	@XStreamAlias("contact:clID")
	String contactClID;

	@XStreamAlias("contact:crID")
	String contactCrID;

	@XStreamAlias("contact:crDate")
	String crDate;

	@XStreamAlias("contact:upDate")
	String upDate;

	public String getReminder() {
		return reminder;
	}

	public void setReminder(String reminder) {
		this.reminder = reminder;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getLegacy() {
		return legacy;
	}

	public void setLegacy(String legacy) {
		this.legacy = legacy;
	}

	public String getContactId() {
		return contactId;
	}

	public void setContactId(String contactId) {
		this.contactId = contactId;
	}

	public String getContactRoid() {
		return contactRoid;
	}

	public void setContactRoid(String contactRoid) {
		this.contactRoid = contactRoid;
	}

	public String getContactStatus() {
		return contactStatus;
	}

	public void setContactStatus(String contactStatus) {
		this.contactStatus = contactStatus;
	}

	public String getContactPostalInfo() {
		return contactPostalInfo;
	}

	public void setContactPostalInfo(String contactPostalInfo) {
		this.contactPostalInfo = contactPostalInfo;
	}

	public String getContactVoice() {
		return contactVoice;
	}

	public void setContactVoice(String contactVoice) {
		this.contactVoice = contactVoice;
	}

	public String getContactFax() {
		return contactFax;
	}

	public void setContactFax(String contactFax) {
		this.contactFax = contactFax;
	}

	public String getContactEmail() {
		return contactEmail;
	}

	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}

	public String getContactClID() {
		return contactClID;
	}

	public void setContactClID(String contactClID) {
		this.contactClID = contactClID;
	}

	public String getContactCrID() {
		return contactCrID;
	}

	public void setContactCrID(String contactCrID) {
		this.contactCrID = contactCrID;
	}

	public String getCrDate() {
		return crDate;
	}

	public void setCrDate(String crDate) {
		this.crDate = crDate;
	}

	public String getUpDate() {
		return upDate;
	}

	public void setUpDate(String upDate) {
		this.upDate = upDate;
	}
}
