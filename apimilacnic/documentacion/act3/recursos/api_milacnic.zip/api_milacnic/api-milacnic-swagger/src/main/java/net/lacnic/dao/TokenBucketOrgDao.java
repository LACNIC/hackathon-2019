package net.lacnic.dao;

import java.sql.Connection;
import java.util.List;

import javax.sql.DataSource;

import org.skife.jdbi.v2.DBI;
import org.skife.jdbi.v2.Handle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.stereotype.Component;

import net.lacnic.domain.TokenBucketOrg;

@Component
public class TokenBucketOrgDao {

	@Qualifier("dsApi")
	@Autowired
	private DataSource dataSource;

	public TokenBucketOrgSQLs connectionTokenBucketOrg() {
		Connection conn = DataSourceUtils.getConnection(dataSource);
		Handle handle = DBI.open(conn);
		TokenBucketOrgSQLs tboSQLs = handle.attach(TokenBucketOrgSQLs.class);
		return tboSQLs;
	}

	public List<TokenBucketOrg> listTBOrg() {
		TokenBucketOrgSQLs tboSQLs = connectionTokenBucketOrg();
		return tboSQLs.listTBOrg();
	}

	public TokenBucketOrg insertTBO(TokenBucketOrg tokenBucketOrg) {
		System.out.println("Entrooó al insertTBO");
		TokenBucketOrgSQLs tboSQLs = connectionTokenBucketOrg();
		tboSQLs.insertTBO(tokenBucketOrg);
		return tokenBucketOrg;
	}

	public TokenBucketOrg obtenerDefaultTokenBucketByOrgId(String orgId) {
		System.out.println("Entro al obtenerDefaultTokenBucket1 de TokenBucketConfigDao");
		TokenBucketOrgSQLs tboSQLs = connectionTokenBucketOrg();
		return tboSQLs.obtenerDefaultTokenBucketByOrgId(orgId);
	}

	public List<TokenBucketOrg> obtenerOtrosTokenBucketByOrgId(String orgId) {
		TokenBucketOrgSQLs tboSQLs = connectionTokenBucketOrg();
		return tboSQLs.obtenerOtrosTokenBucketByOrgId(orgId);
	}

	public Integer getCantTokenBucketOrgByIdOrg(String idOrgConfig) {
		TokenBucketOrgSQLs tboSQLs = connectionTokenBucketOrg();
		return tboSQLs.getCantTokenBucketOrgByIdOrg(idOrgConfig);
	}

	// public TokenBucketOrg obtenerDefaultTokenBucketOrg1() {
	// System.out.println("Entro al obtenerDefaultTokenBucket1 de
	// TokenBucketOrgDao");
	// TokenBucketOrgSQLs tboSQLs = connectionTokenBucketOrg();
	// return tboSQLs.obtenerDefaultTokenBucket();
	// }
	//
	// public List<TokenBucketOrg> obtenerOtrosTokenBucketOrg1() {
	// TokenBucketOrgSQLs tboSQLs = connectionTokenBucketOrg();
	// return tboSQLs.obtenerOtrosTokenBucket();
	// }
}
