package net.lacnic.registro.api.response;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("ipnetwork:parentNetwork")
public class IPNetworkParent implements Serializable {
	// @XStreamAsAttribute
	// String type; // attribute

	@XStreamAlias("ipnetwork:ipRange")
	IPNetworkIPRange ipRange;

	@XStreamAlias("ipnetwork:roid")
	String roid;

}
