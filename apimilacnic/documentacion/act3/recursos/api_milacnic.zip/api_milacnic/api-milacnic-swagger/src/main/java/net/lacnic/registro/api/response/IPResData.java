package net.lacnic.registro.api.response;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("resData")
public class IPResData extends ResData  implements Serializable{
	@XStreamAlias("ipnetwork:creData")
	IPNetworkCreData ipnetworkCreData;
	
	public IPResData(){
		
		
	}

	public IPNetworkCreData getCreData() {
		return ipnetworkCreData;
	}
}
