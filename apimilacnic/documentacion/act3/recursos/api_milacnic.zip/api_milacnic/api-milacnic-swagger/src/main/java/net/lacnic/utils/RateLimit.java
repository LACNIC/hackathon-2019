package net.lacnic.utils;

public enum RateLimit {

	ORG_CREATE("ORG_CREATE"), ORG_UPDATE("ORG_UPDATE"), ORG_INFO("ORG_INFO"), SUBASIGNAR("SUBASIGNAR"), SUBASIGNAR_DELETE("SUBASIGNAR_DELETE"), SUBASIGNAR_UPDATE("SUBASIGNAR_UPDATE"), SUBASIGNAR_INFO("SUBASIGNAR_INFO"), DELEGAR("DELEGAR"), DELEGAR_DELETE("DELEGAR_DELETE"), DELEGAR_UPDATE("DELEGAR_UPDATE"), CONTACT_INFO("CONTACT_INFO"), HOSTNAME_INFO("HOSTNAME_INFO");

	// CONTACT_CREATE,
	// CONTACT_UPDATE,

	// ASN_INFO,
	// ASN_UPDATE,
	// ASN_CONTACT,
	// ASN_UPDATE_CONTACTS,
	private String nombre;

	private RateLimit(String nombre) {
		this.nombre = nombre;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
}