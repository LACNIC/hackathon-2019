package net.lacnic.registro.api.response;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("ipnetwork:infData")
public class IPNetworkInfData implements Serializable {

	private static final long serialVersionUID = -8603085385230437016L;

	@XStreamAlias("ipnetwork:ipRange")
	IPNetworkIPRange ipRange;

	@XStreamAlias("ipnetwork:ipRangeInfo") // TODO ver si aplica
	IPNetworkIPRangeInfo ipRangeInfo;

	public IPNetworkIPRange getIpRange() {
		return ipRange;
	}

	public void setIpRange(IPNetworkIPRange ipRange) {
		this.ipRange = ipRange;
	}

	public IPNetworkIPRangeInfo getIpRangeInfo() {
		return ipRangeInfo;
	}

	public void setIpRangeInfo(IPNetworkIPRangeInfo ipRangeInfo) {
		this.ipRangeInfo = ipRangeInfo;
	}
}
