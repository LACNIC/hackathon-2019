package net.lacnic.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class TokenBucketConfig implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "id")
	private String id;

	@Column
	private Integer bucketSize;

	@Column
	private Integer tokensToAdd;

	@Column
	private Integer periodMinToRerill;

	public TokenBucketConfig() {
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Integer getBucketSize() {
		return bucketSize;
	}

	public void setBucketSize(Integer bucketSize) {
		this.bucketSize = bucketSize;
	}

	public Integer getTokensToAdd() {
		return tokensToAdd;
	}

	public void setTokensToAdd(Integer tokensToAdd) {
		this.tokensToAdd = tokensToAdd;
	}

	public Integer getPeriodMinToRerill() {
		return periodMinToRerill;
	}

	public void setPeriodMinToRerill(Integer periodMinToRerill) {
		this.periodMinToRerill = periodMinToRerill;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
