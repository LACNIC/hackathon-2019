package net.lacnic.api.response;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;

public class Result {

	private String code = ""; // attribute
	private String msg = "";

	@JacksonXmlElementWrapper(useWrapping = false)
	private List<ExtValue> extValues = new ArrayList<ExtValue>();

	public Result() {
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public List<ExtValue> getExtValues() {
		return extValues;
	}

	public void setExtValues(List<ExtValue> extValues) {
		this.extValues = extValues;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class Result {\n");
		sb.append("    code: ").append(toIndentedString(code)).append("\n");
		sb.append("    msg: ").append(toIndentedString(msg)).append("\n");
		sb.append("    extValues: ").append(toIndentedString(extValues)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

}
