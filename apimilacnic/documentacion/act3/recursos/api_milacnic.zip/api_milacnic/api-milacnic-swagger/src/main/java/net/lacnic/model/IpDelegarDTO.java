package net.lacnic.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * IpDelegarDTO
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2019-01-10T12:54:03.514Z[GMT]")

public class IpDelegarDTO {

	@JsonProperty("cidrs")
	private List<String> cidrs = new ArrayList<>();

	@JsonProperty("hostnames")
	@Valid
	private List<String> hostnames = new ArrayList<>();

	public IpDelegarDTO cidrs(List<String> cidrs) {
		this.cidrs = cidrs;
		return this;
	}

	public IpDelegarDTO addCidrsItem(String cidr) {
		if (this.cidrs == null) {
			this.cidrs = new ArrayList<String>();
		}
		this.cidrs.add(cidr);
		return this;
	}

	/**
	 * Get cidrs
	 * 
	 * @return cidrs
	 **/
	@ApiModelProperty(value = "")

	@Valid

	public List<String> getCidrs() {
		return cidrs;
	}

	public void setCidrs(List<String> cidrs) {
		this.cidrs = cidrs;
	}

	public IpDelegarDTO hostnames(List<String> hostnames) {
		this.hostnames = hostnames;
		return this;
	}

	public IpDelegarDTO addHostnamesItem(String hostnamesItem) {
		if (this.hostnames == null) {
			this.hostnames = new ArrayList<String>();
		}
		this.hostnames.add(hostnamesItem);
		return this;
	}

	/**
	 * Get hostnames
	 * 
	 * @return hostnames
	 **/
	@ApiModelProperty(value = "")

	public List<String> getHostnames() {
		return hostnames;
	}

	public void setHostnames(List<String> hostnames) {
		this.hostnames = hostnames;
	}

	@Override
	public boolean equals(java.lang.Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		IpDelegarDTO ip = (IpDelegarDTO) o;
		return Objects.equals(this.cidrs, ip.cidrs) && Objects.equals(this.hostnames, ip.hostnames);
	}

	@Override
	public int hashCode() {
		return Objects.hash(cidrs, hostnames);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class IpDelegarDTO {\n");
		sb.append("    cidrs: ").append(toIndentedString(cidrs)).append("\n");
		sb.append("    hostnames: ").append(toIndentedString(hostnames)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}
}
