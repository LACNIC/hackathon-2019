package net.lacnic.model;

import java.util.Objects;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * IpSubasignarUpdateDTO
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2019-01-10T12:54:03.514Z[GMT]")

public class IpSubasignarUpdateDTO {

	@JsonProperty("asn")
	private String asn = null;

	@JsonProperty("techContact")
	@Valid
	private String techContact = null;

	@JsonProperty("abuseContact")
	@Valid
	private String abuseContact = null;

	public IpSubasignarUpdateDTO asn(String asn) {
		this.asn = asn;
		return this;
	}

	/**
	 * Get asn
	 * 
	 * @return asn
	 **/
	@ApiModelProperty(value = "")

	public String getAsn() {
		return asn;
	}

	public void setAsn(String asn) {
		this.asn = asn;
	}

	public IpSubasignarUpdateDTO techContact(String techContact) {
		this.techContact = techContact;
		return this;
	}

	/**
	 * Get techContact
	 * 
	 * @return techContact
	 **/
	@ApiModelProperty(value = "")

	@Valid

	public String getTechContact() {
		return techContact;
	}

	public void setTechContact(String techContact) {
		this.techContact = techContact;
	}

	public IpSubasignarUpdateDTO abuseContact(String abuseContact) {
		this.abuseContact = abuseContact;
		return this;
	}

	/**
	 * Get abuseContact
	 * 
	 * @return abuseContact
	 **/
	@ApiModelProperty(value = "")

	@Valid

	public String getAbuseContact() {
		return abuseContact;
	}

	public void setAbuseContact(String abuseContact) {
		this.abuseContact = abuseContact;
	}

	@Override
	public boolean equals(java.lang.Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		IpSubasignarUpdateDTO ip = (IpSubasignarUpdateDTO) o;
		return Objects.equals(this.asn, ip.asn) && Objects.equals(this.techContact, ip.techContact) && Objects.equals(this.abuseContact, ip.abuseContact);
	}

	@Override
	public int hashCode() {
		return Objects.hash(asn, techContact, abuseContact);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class IpSubasignarUpdateDTO {\n");
		sb.append("    asn: ").append(toIndentedString(asn)).append("\n");
		sb.append("    techContact: ").append(toIndentedString(techContact)).append("\n");
		sb.append("    abuseContact: ").append(toIndentedString(abuseContact)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

}
