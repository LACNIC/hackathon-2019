package net.lacnic.registro.api.response;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("ipnetwork:creData")
public class IPNetworkCreData implements Serializable {

	@XStreamAlias("ipnetwork:ipRange")
	IPNetworkIPRange ipRange;

	@XStreamAlias("ipnetwork:roid")
	String roid;

	@XStreamAlias("ipnetwork:crDate")
	String crDate;

	// @XStreamAlias("ipnetwork:ipRangeInfo")// TODO ver si aplica
	// IPNetworkIPRange ipRangeInfo;

	public String getRoid() {
		return roid;
	}
}
