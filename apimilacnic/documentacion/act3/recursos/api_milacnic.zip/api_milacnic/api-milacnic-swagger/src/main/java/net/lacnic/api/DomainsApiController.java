package net.lacnic.api;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.auth0.jwt.JWT;
import com.auth0.jwt.exceptions.JWTDecodeException;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.swagger.annotations.ApiParam;
import net.lacnic.ejb.service.impl.ApiAdminServices;
import net.lacnic.epp.util.ResponseWs;
import net.lacnic.model.IpDelegarDTO;
import net.lacnic.model.IpDelegarUpdateDTO;
import net.lacnic.model.IpDTO;
import net.lacnic.model.ReverseDNSDTO;
import net.lacnic.registro.api.request.Contact;
import net.lacnic.registro.api.request.IPNetworkRange;
import net.lacnic.registro.api.request.IpRequest;
import net.lacnic.registro.api.request.OrgRequest;
import net.lacnic.registro.api.request.ReverseDNS;
import net.lacnic.registro.api.request.TipoAlocacion;
import net.lacnic.tb.StorageTokenBucket;
import net.lacnic.utils.RateLimit;
import net.lacnic.utils.SocketFactory;
import net.ripe.ipresource.IpRange;
import net.ripe.ipresource.IpResourceType;

@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2019-01-07T15:51:50.032Z[GMT]")

@Controller
public class DomainsApiController implements DomainsApi {

	private static final Logger LOGGER = LoggerFactory.getLogger(DomainsApiController.class);

	private final ObjectMapper objectMapper;

	private final HttpServletRequest request;

	private final String userOrgEPP = "SERGIO";

	@Autowired
	ApiAdminServices apiAdminService;

	@org.springframework.beans.factory.annotation.Autowired
	public DomainsApiController(ObjectMapper objectMapper, HttpServletRequest request) {
		this.objectMapper = objectMapper;
		this.request = request;
	}

	// DELETE
	public ResponseEntity<Object> domainsPrefixDelete(@ApiParam(value = "", required = true) @PathVariable("prefix") String prefix, @ApiParam(value = "", required = true) @PathVariable("prefixLength") String prefixLength) {
		String accept = request.getHeader("Accept");
		String ip = request.getRemoteAddr();
		String user = "";
		String idOrgRequest = "";
		LOGGER.info("**EJECUTANDO Eliminar delegación**");
		try {
			// Ratelimit
			String token = request.getHeader("Authorization");
			String clientId = "";
			if (token != null && token.startsWith("Bearer")) {
				Authentication auth = SecurityContextHolder.getContext().getAuthentication();
				if (auth.getName().contains("@")) {
					String[] clients = auth.getName().split("@");
					clientId = clients[0];
				} else {
					try {
						DecodedJWT jwt = JWT.decode(auth.getCredentials().toString());
						clientId = jwt.getClaims().get("azp").asString();
					} catch (JWTDecodeException exception) {
						// Invalid token
					}
				}
				if (apiAdminService.existeOrgConfig(clientId)) {
					apiAdminService.insertarTokensBucketOrg(clientId);

					StorageTokenBucket storageTokenBucket = new StorageTokenBucket(apiAdminService);
					idOrgRequest = apiAdminService.obtenerOrgConfig(clientId).getIdOrgConfig();
					LOGGER.info("Operación ejecutada por la organización " + idOrgRequest);
					OrgRequest org = new OrgRequest(userOrgEPP, ip, idOrgRequest);
					apiAdminService.obtenerOrgEppAdmin(org);
					user = apiAdminService.convertirOrg(SocketFactory.getInstance().getEppAdminConnection().getFrameOrg()).getAdminContact();
					if (!storageTokenBucket.tryConsumeAction(idOrgRequest, RateLimit.DELEGAR_DELETE)) {
						LOGGER.warn("No tiene consultas disponibles");
						return new ResponseEntity<Object>(HttpStatus.TOO_MANY_REQUESTS);
					}
				} else {
					LOGGER.warn("Organización no autorizada");
					return new ResponseEntity<Object>(HttpStatus.UNAUTHORIZED);
				}
			} else {
				LOGGER.warn("Token incorrecto");
				return new ResponseEntity<Object>(HttpStatus.UNAUTHORIZED);
			}
			// Ratelimit
			String estructuraCidr = prefix + "/" + prefixLength;
			System.out.println("estructuraCirdddddddd: " + estructuraCidr);

			IpRange ipRange = IpRange.parse(estructuraCidr);
			String version = "";
			if (ipRange.getType().equals(IpResourceType.IPv4)) {
				version = "v4";
			} else if (ipRange.getType().equals(IpResourceType.IPv6)) {
				version = "v6";
			}
			// **********
			IPNetworkRange ipNRange = new IPNetworkRange(ipRange.getStart().toString(), ipRange.getEnd().toString(), version);
			IpRequest ipRequest = new IpRequest(user, ip);
			ipRequest.setIpnetwork_range(ipNRange);
			apiAdminService.obtenerBloqueIp(ipRequest);
			IpDTO ipResponse = apiAdminService.convertirIP();
			// *******
			List<String> hostnames = new ArrayList<String>();
			for (ReverseDNSDTO dnsDTO : ipResponse.getIpnetworkReversesDns()) {
				if (dnsDTO.getIpnetworkRange().getStartAddress().equalsIgnoreCase(ipNRange.getStart_address()) && dnsDTO.getIpnetworkRange().getEndAddress().equalsIgnoreCase(ipNRange.getEnd_address())) {
					hostnames.addAll(dnsDTO.getHostnames());
				}
			}
			// ****************
			List<ReverseDNS> listaRSAEliminar = new ArrayList<ReverseDNS>();
			if (!hostnames.isEmpty()) {
				ReverseDNS rAEliminar = new ReverseDNS(ipNRange, hostnames);
				listaRSAEliminar.add(rAEliminar);
			}
			ipRequest.setIpnetwork_reverses_dns_rem(listaRSAEliminar);
			ipRequest.setRoid(ipResponse.getRoid());
			ResponseWs res = apiAdminService.eliminarDominio(ipRequest, idOrgRequest);
			String trId = apiAdminService.infoMetodoEPP();
			if (res != null) {
				LOGGER.info("ResponseWS NO devolvió nulo");
				LOGGER.info("Info del TRID:\n" + trId);
				return ResponseEntity.ok(trId);
			} else {
				LOGGER.warn("ResponseWS SI devolvió nulo");
				return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			LOGGER.error("Ha ocurrido el siguiente error: " + e);
			return new ResponseEntity<Object>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	// GET
	public ResponseEntity<Object> domainsHostnameGet(@ApiParam(value = "", required = true) @PathVariable("hostname") String hostname) {
		String accept = request.getHeader("Accept");
		return new ResponseEntity<Object>(HttpStatus.NOT_IMPLEMENTED);
	}

	// Editar delegación
	public ResponseEntity<Object> domainsPrefixPut(@ApiParam(value = "Estos son los datos necesarios para realizar la operación.", required = true) @Valid @RequestBody IpDelegarUpdateDTO body, @ApiParam(value = "", required = true) @PathVariable("prefix") String prefix, @ApiParam(value = "", required = true) @PathVariable("prefixLength") String prefixLength) {
		String accept = request.getHeader("Accept");
		String ip = request.getRemoteAddr();
		String user = "";
		String idOrgRequest = "";
		LOGGER.info("**EJECUTANDO Editar Delegación**");
		try {
			// Ratelimit
			String token = request.getHeader("Authorization");
			String clientId = "";
			if (token != null && token.startsWith("Bearer")) {
				Authentication auth = SecurityContextHolder.getContext().getAuthentication();
				if (auth.getName().contains("@")) {
					String[] clients = auth.getName().split("@");
					clientId = clients[0];
				} else {
					try {
						DecodedJWT jwt = JWT.decode(auth.getCredentials().toString());
						clientId = jwt.getClaims().get("azp").asString();
					} catch (JWTDecodeException exception) {
						// Invalid token
					}
				}
				if (apiAdminService.existeOrgConfig(clientId)) {
					apiAdminService.insertarTokensBucketOrg(clientId);

					StorageTokenBucket storageTokenBucket = new StorageTokenBucket(apiAdminService);
					idOrgRequest = apiAdminService.obtenerOrgConfig(clientId).getIdOrgConfig();
					LOGGER.info("Operación ejecutada por la organización " + idOrgRequest);
					OrgRequest org = new OrgRequest(userOrgEPP, ip, idOrgRequest);
					apiAdminService.obtenerOrgEppAdmin(org);
					user = apiAdminService.convertirOrg(SocketFactory.getInstance().getEppAdminConnection().getFrameOrg()).getAdminContact();
					if (!storageTokenBucket.tryConsumeAction(idOrgRequest, RateLimit.DELEGAR_UPDATE)) {
						LOGGER.warn("No tiene consultas disponibles");
						return new ResponseEntity<Object>(HttpStatus.TOO_MANY_REQUESTS);
					}
				} else {
					LOGGER.warn("Organización no autorizada");
					return new ResponseEntity<Object>(HttpStatus.UNAUTHORIZED);
				}
			} else {
				LOGGER.warn("Token incorrecto");
				return new ResponseEntity<Object>(HttpStatus.UNAUTHORIZED);
			}
			// Ratelimit
			String estructuraCidr = prefix + "/" + prefixLength;
			System.out.println("estructuraCirdddddddd: " + estructuraCidr);

			IpRange ipRange = IpRange.parse(estructuraCidr);
			String version = "";
			if (ipRange.getType().equals(IpResourceType.IPv4)) {
				version = "v4";
			} else if (ipRange.getType().equals(IpResourceType.IPv6)) {
				version = "v6";
			}
			// ****************
			IPNetworkRange ipNRange = new IPNetworkRange(ipRange.getStart().toString(), ipRange.getEnd().toString(), version);
			IpRequest ipRequest = new IpRequest(user, ip);
			ipRequest.setIpnetwork_range(ipNRange);
			apiAdminService.obtenerBloqueIp(ipRequest);
			IpDTO ipResponse = apiAdminService.convertirIP();
			// ****************
			List<ReverseDNS> listaRSAEliminar = new ArrayList<ReverseDNS>();
			List<ReverseDNS> listaRSAAgregar = new ArrayList<ReverseDNS>();

			if (!body.getHostnamesAdd().isEmpty()) {
				ReverseDNS rAAgregar = new ReverseDNS(ipNRange, body.getHostnamesAdd());
				listaRSAAgregar.add(rAAgregar);
			}
			List<String> hostnames = new ArrayList<String>();
			for (ReverseDNSDTO dnsDTO : ipResponse.getIpnetworkReversesDns()) {
				if (dnsDTO.getIpnetworkRange().getStartAddress().equalsIgnoreCase(ipNRange.getStart_address()) && dnsDTO.getIpnetworkRange().getEndAddress().equalsIgnoreCase(ipNRange.getEnd_address())) {
					hostnames.addAll(dnsDTO.getHostnames());
				}
			}
			if (!hostnames.isEmpty()) {
				ReverseDNS rAEliminar = new ReverseDNS(ipNRange, hostnames);
				listaRSAEliminar.add(rAEliminar);
			}
			ipRequest.setRoid(ipResponse.getRoid());
			ipRequest.setIpnetwork_reverses_dns_add(listaRSAAgregar);
			ipRequest.setIpnetwork_reverses_dns_rem(listaRSAEliminar);
			ResponseWs res = apiAdminService.editarDominio(ipRequest, idOrgRequest);
			String trId = apiAdminService.infoMetodoEPP();
			if (res != null) {
				LOGGER.info("ResponseWS NO devolvió nulo");
				LOGGER.info("Info del TRID:\n" + trId);
				return ResponseEntity.ok(trId);
			} else {
				LOGGER.warn("ResponseWS SI devolvió nulo");
				return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			LOGGER.error("Ha ocurrido el siguiente error: " + e);
			return new ResponseEntity<Object>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	// CREATE*** (Delegar)
	public ResponseEntity<Object> domainsPost(@ApiParam(value = "Estos son los datos necesarios para realizar la operación.", required = true) @Valid @RequestBody IpDelegarDTO body) {
		String accept = request.getHeader("Accept");
		String ip = request.getRemoteAddr();
		String user = "";
		String idOrgRequest = "";
		LOGGER.info("**EJECUTANDO Delegación Nombres de Dominio**");
		try {
			// Ratelimit
			String token = request.getHeader("Authorization");
			String clientId = "";
			if (token != null && token.startsWith("Bearer")) {
				Authentication auth = SecurityContextHolder.getContext().getAuthentication();
				if (auth.getName().contains("@")) {
					String[] clients = auth.getName().split("@");
					clientId = clients[0];
				} else {
					try {
						DecodedJWT jwt = JWT.decode(auth.getCredentials().toString());
						clientId = jwt.getClaims().get("azp").asString();
					} catch (JWTDecodeException exception) {
						// Invalid token
					}
				}
				if (apiAdminService.existeOrgConfig(clientId)) {
					apiAdminService.insertarTokensBucketOrg(clientId);

					StorageTokenBucket storageTokenBucket = new StorageTokenBucket(apiAdminService);
					idOrgRequest = apiAdminService.obtenerOrgConfig(clientId).getIdOrgConfig();
					LOGGER.info("Operación ejecutada por la organización " + idOrgRequest);
					OrgRequest org = new OrgRequest(userOrgEPP, ip, idOrgRequest);
					apiAdminService.obtenerOrgEppAdmin(org);
					user = apiAdminService.convertirOrg(SocketFactory.getInstance().getEppAdminConnection().getFrameOrg()).getAdminContact();
					if (!storageTokenBucket.tryConsumeAction(idOrgRequest, RateLimit.DELEGAR)) {
						LOGGER.warn("No tiene consultas disponibles");
						return new ResponseEntity<Object>(HttpStatus.TOO_MANY_REQUESTS);
					}
				} else {
					LOGGER.warn("Organización no autorizada");
					return new ResponseEntity<Object>(HttpStatus.UNAUTHORIZED);
				}
			} else {
				LOGGER.warn("Token incorrecto");
				return new ResponseEntity<Object>(HttpStatus.UNAUTHORIZED);
			}
			// End Ratelimit
			int ok = 0;
			List<String> trId = new ArrayList<String>();
			for (String cidr : body.getCidrs()) {

				IpRange ipRange = IpRange.parse(cidr);
				String version = "";
				if (ipRange.getType().equals(IpResourceType.IPv4)) {
					version = "v4";
				} else if (ipRange.getType().equals(IpResourceType.IPv6)) {
					version = "v6";
				}
				// ***************
				IPNetworkRange ipNRange = new IPNetworkRange(ipRange.getStart().toString(), ipRange.getEnd().toString(), version);
				IpRequest ipRequestOR = new IpRequest(user, ip);
				ipRequestOR.setIpnetwork_range(ipNRange);
				apiAdminService.obtenerBloqueIp(ipRequestOR);
				String roid = apiAdminService.convertirIP().getRoid();
				List<ReverseDNS> listaRSAAgregar = new ArrayList<ReverseDNS>();

				if (!body.getHostnames().isEmpty()) {
					ReverseDNS rAAgregar = new ReverseDNS(ipNRange, body.getHostnames());
					listaRSAAgregar.add(rAAgregar);
				}
				final IpRequest ipRequest = new IpRequest(user, ip, null, roid, null, ipNRange, TipoAlocacion.NOAPPLY, new ArrayList<Contact>(), new ArrayList<ReverseDNS>(), listaRSAAgregar, new ArrayList<ReverseDNS>());
				ResponseWs res = apiAdminService.editarDominio(ipRequest, idOrgRequest);
				trId.add("CIDR: " + cidr);
				String[] infoEpp = apiAdminService.infoMetodoEPP().split("\n");
				trId.add(infoEpp[0]);
				trId.add(infoEpp[1]);
				if (res != null) {
					LOGGER.info("ResponseWS NO devolvió nulo");
					ok++;
				} else
					LOGGER.warn("ResponseWS SI devolvió nulo");
			}

			if (ok == body.getCidrs().size()) {
				LOGGER.info("Todos los bloques se delegaron correctamente");
				LOGGER.info("Info del TRID:\n" + trId);
				return ResponseEntity.ok(trId);
			} else {
				LOGGER.warn("Alguna delegación devolvió nulo");
				return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			LOGGER.error("Ha ocurrido el siguiente error: " + e);
			return new ResponseEntity<Object>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
