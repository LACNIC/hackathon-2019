package net.lacnic.model;

import java.util.Objects;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * OrganizationDTO
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2019-01-10T12:54:03.514Z[GMT]")

public class OrganizationDTO {

	@JsonProperty("orgId")
	private String orgId = null;

	@JsonProperty("name")
	private String name = null;

	@JsonProperty("responsible")
	private String responsible = null;

	@JsonProperty("admin_contact")
	private String adminContact = null;

	@JsonProperty("cob_contact")
	private String cobContact = null;

	@JsonProperty("mem_contact")
	private String memContact = null;

	@JsonProperty("address")
	private AddressDTO address = null;

	@JsonProperty("phone")
	private PhoneDTO phone = null;

	public OrganizationDTO orgId(String orgId) {
		this.orgId = orgId;
		return this;
	}

	/**
	 * Get orgId
	 * 
	 * @return orgId
	 **/
	@ApiModelProperty(value = "")

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public OrganizationDTO name(String name) {
		this.name = name;
		return this;
	}

	/**
	 * Get name
	 * 
	 * @return name
	 **/
	@ApiModelProperty(value = "")

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public OrganizationDTO responsible(String responsible) {
		this.responsible = responsible;
		return this;
	}

	/**
	 * Get responsible
	 * 
	 * @return responsible
	 **/
	@ApiModelProperty(value = "")

	public String getResponsible() {
		return responsible;
	}

	public void setResponsible(String responsible) {
		this.responsible = responsible;
	}

	public OrganizationDTO adminContact(String adminContact) {
		this.adminContact = adminContact;
		return this;
	}

	/**
	 * Get adminContact
	 * 
	 * @return adminContact
	 **/
	@ApiModelProperty(value = "")

	public String getAdminContact() {
		return adminContact;
	}

	public void setAdminContact(String adminContact) {
		this.adminContact = adminContact;
	}

	public OrganizationDTO cobContact(String cobContact) {
		this.cobContact = cobContact;
		return this;
	}

	/**
	 * Get cobContact
	 * 
	 * @return cobContact
	 **/
	@ApiModelProperty(value = "")

	public String getCobContact() {
		return cobContact;
	}

	public void setCobContact(String cobContact) {
		this.cobContact = cobContact;
	}

	public OrganizationDTO memContact(String memContact) {
		this.memContact = memContact;
		return this;
	}

	/**
	 * Get memContact
	 * 
	 * @return memContact
	 **/
	@ApiModelProperty(value = "")

	public String getMemContact() {
		return memContact;
	}

	public void setMemContact(String memContact) {
		this.memContact = memContact;
	}

	public OrganizationDTO address(AddressDTO address) {
		this.address = address;
		return this;
	}

	/**
	 * Get address
	 * 
	 * @return address
	 **/
	@ApiModelProperty(value = "")

	@Valid
	public AddressDTO getAddress() {
		return address;
	}

	public void setAddress(AddressDTO address) {
		this.address = address;
	}

	public OrganizationDTO phone(PhoneDTO phone) {
		this.phone = phone;
		return this;
	}

	/**
	 * Get phone
	 * 
	 * @return phone
	 **/
	@ApiModelProperty(value = "")

	@Valid
	public PhoneDTO getPhone() {
		return phone;
	}

	public void setPhone(PhoneDTO phone) {
		this.phone = phone;
	}

	@Override
	public boolean equals(java.lang.Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		OrganizationDTO organizacion = (OrganizationDTO) o;
		return Objects.equals(this.orgId, organizacion.orgId) && Objects.equals(this.name, organizacion.name) && Objects.equals(this.responsible, organizacion.responsible) && Objects.equals(this.adminContact, organizacion.adminContact) && Objects.equals(this.cobContact, organizacion.cobContact) && Objects.equals(this.memContact, organizacion.memContact) && Objects.equals(this.address, organizacion.address) && Objects.equals(this.phone, organizacion.phone);
	}

	@Override
	public int hashCode() {
		return Objects.hash(orgId, name, responsible, adminContact, cobContact, memContact, address, phone);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class OrganizationDTO {\n");
		sb.append("    orgId: ").append(toIndentedString(orgId)).append("\n");
		sb.append("    name: ").append(toIndentedString(name)).append("\n");
		sb.append("    responsible: ").append(toIndentedString(responsible)).append("\n");
		sb.append("    adminContact: ").append(toIndentedString(adminContact)).append("\n");
		sb.append("    cobContact: ").append(toIndentedString(cobContact)).append("\n");
		sb.append("    memContact: ").append(toIndentedString(memContact)).append("\n");
		sb.append("    address: ").append(toIndentedString(address)).append("\n");
		sb.append("    phone: ").append(toIndentedString(phone)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}
}
