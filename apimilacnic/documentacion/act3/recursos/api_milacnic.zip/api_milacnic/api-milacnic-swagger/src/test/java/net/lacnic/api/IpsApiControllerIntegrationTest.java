package net.lacnic.api;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import net.lacnic.model.IpSubasignarDTO;
import net.lacnic.model.IpSubasignarUpdateDTO;

@RunWith(SpringRunner.class)
@SpringBootTest
public class IpsApiControllerIntegrationTest {

	@Autowired
	private IpsApi api;

	@Test
	public void ipsPrefixDeleteTest() throws Exception {
		String prefix = "prefix_example";
		String prefixLength = "prefixLength_example";
		ResponseEntity<Object> responseEntity = api.ipsPrefixDelete(prefix, prefixLength);
		assertEquals(HttpStatus.NOT_IMPLEMENTED, responseEntity.getStatusCode());
	}

	@Test
	public void ipsPrefixGetTest() throws Exception {
		String prefix = "prefix_example";
		String prefixLength = "prefixLength_example";
		ResponseEntity<Object> responseEntity = api.ipsPrefixGet(prefix, prefixLength);
		assertEquals(HttpStatus.NOT_IMPLEMENTED, responseEntity.getStatusCode());
	}

	@Test
	public void ipsPrefixPutTest() throws Exception {
		IpSubasignarUpdateDTO body = new IpSubasignarUpdateDTO();
		String prefix = "prefix_example";
		String prefixLength = "prefixLength_example";
		ResponseEntity<Object> responseEntity = api.ipsPrefixPut(body, prefix, prefixLength);
		assertEquals(HttpStatus.NOT_IMPLEMENTED, responseEntity.getStatusCode());
	}

	@Test
	public void ipsPostTest() throws Exception {
		IpSubasignarDTO body = new IpSubasignarDTO();
		ResponseEntity<Object> responseEntity = api.ipsPost(body);
		assertEquals(HttpStatus.NOT_IMPLEMENTED, responseEntity.getStatusCode());
	}

}
