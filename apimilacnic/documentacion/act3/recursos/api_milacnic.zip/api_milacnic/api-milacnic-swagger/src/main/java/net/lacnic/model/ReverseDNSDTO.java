package net.lacnic.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * ReverseDNSDTO
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2019-01-10T12:54:03.514Z[GMT]")

public class ReverseDNSDTO {
	@JsonProperty("ipnetwork_range")
	private IPNetworkRangeDTO ipnetworkRange = null;

	@JsonProperty("hostnames")
	@Valid
	private List<String> hostnames = null;

	public ReverseDNSDTO ipnetworkRange(IPNetworkRangeDTO ipnetworkRange) {
		this.ipnetworkRange = ipnetworkRange;
		return this;
	}

	/**
	 * Get ipnetworkRange
	 * 
	 * 
	 * @return ipnetworkRange
	 **/
	@ApiModelProperty(value = "")

	@Valid

	public IPNetworkRangeDTO getIpnetworkRange() {
		return ipnetworkRange;
	}

	public void setIpnetworkRange(IPNetworkRangeDTO ipnetworkRange) {
		this.ipnetworkRange = ipnetworkRange;
	}

	public ReverseDNSDTO hostnames(List<String> hostnames) {
		this.hostnames = hostnames;
		return this;
	}

	public ReverseDNSDTO addHostnamesItem(String hostnamesItem) {
		if (this.hostnames == null) {
			this.hostnames = new ArrayList<String>();
		}
		this.hostnames.add(hostnamesItem);
		return this;
	}

	/**
	 * Get hostnames
	 * 
	 * @return hostnames
	 **/
	@ApiModelProperty(value = "")

	public List<String> getHostnames() {
		return hostnames;
	}

	public void setHostnames(List<String> hostnames) {
		this.hostnames = hostnames;
	}

	@Override
	public boolean equals(java.lang.Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		ReverseDNSDTO reverseDNS = (ReverseDNSDTO) o;
		return Objects.equals(this.ipnetworkRange, reverseDNS.ipnetworkRange) && Objects.equals(this.hostnames, reverseDNS.hostnames);
	}

	@Override
	public int hashCode() {
		return Objects.hash(ipnetworkRange, hostnames);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class ReverseDNSDTO {\n");
		sb.append("    ipnetworkRange: ").append(toIndentedString(ipnetworkRange)).append("\n");
		sb.append("    hostnames: ").append(toIndentedString(hostnames)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}
}
