package net.lacnic.configuration;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import springfox.bean.validators.configuration.BeanValidatorPluginsConfiguration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.OAuthBuilder;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.AuthorizationScope;
import springfox.documentation.service.Contact;
import springfox.documentation.service.ResourceOwnerPasswordCredentialsGrant;
import springfox.documentation.service.SecurityScheme;
import springfox.documentation.service.Tag;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger.web.DocExpansion;
import springfox.documentation.swagger.web.ModelRendering;
import springfox.documentation.swagger.web.OperationsSorter;
import springfox.documentation.swagger.web.SecurityConfiguration;
import springfox.documentation.swagger.web.SecurityConfigurationBuilder;
import springfox.documentation.swagger.web.TagsSorter;
import springfox.documentation.swagger.web.UiConfiguration;
import springfox.documentation.swagger.web.UiConfigurationBuilder;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2019-01-07T15:51:50.032Z[GMT]")

@Configuration
@EnableSwagger2
@Import(BeanValidatorPluginsConfiguration.class) // Esto es para hacer
													// validaciones con
													// springfox
public class SwaggerDocumentationConfig {

	public static final String AUTH_SHCEMA_NAME = "OAuth2";

	@Value("${config.oauth2.accessTokenUri}")
	private String accessToken;

	ApiInfo apiInfo() {
		return new ApiInfoBuilder().title("API MiLACNIC").description("Api de LACNIC basado en el sistema MiLacnic").license("").licenseUrl("http://unlicense.org").termsOfServiceUrl("").version("0.9").contact(new Contact("", "", "desarrollo@lacnic.net")).build();
	}

	@Bean
	public Docket customImplementation() {
		return new Docket(DocumentationType.SWAGGER_2).select().apis(RequestHandlerSelectors.basePackage("net.lacnic.api")).build().directModelSubstitute(org.threeten.bp.LocalDate.class, java.sql.Date.class).directModelSubstitute(org.threeten.bp.OffsetDateTime.class, java.util.Date.class).tags(new Tag("Organizaciones", "Gestión de organizaciones"), new Tag("IPs", "Gestión de IPs"), new Tag("rDNS", "Gestión de delegaciones rDNS"), new Tag("Usuarios/Contactos", "Gestión de usuarios/contactos")).securitySchemes(Arrays.asList(securityScheme())).apiInfo(apiInfo());
	}

	@Bean
	UiConfiguration uiConfig() {
		return UiConfigurationBuilder.builder().deepLinking(true).displayOperationId(false).defaultModelsExpandDepth(1).defaultModelExpandDepth(1).defaultModelRendering(ModelRendering.EXAMPLE).displayRequestDuration(false).docExpansion(DocExpansion.LIST).filter(false).maxDisplayedTags(null).operationsSorter(OperationsSorter.ALPHA).showExtensions(false).tagsSorter(TagsSorter.ALPHA).supportedSubmitMethods(UiConfiguration.Constants.DEFAULT_SUBMIT_METHODS).validatorUrl(null).build();
	}

	private SecurityScheme securityScheme() {
		// The resource owner password credentials grant type is suitable in
		// cases where
		// the resource owner has a
		// trust relationship with the client, such as the device operating
		// system or a
		// highly privileged application.
		// The authorization server should take special care when enabling this
		// grant
		// type and only allow it when other
		// flows are not viable.
		ResourceOwnerPasswordCredentialsGrant resourceOwnerPasswordCredentialsGrant = new ResourceOwnerPasswordCredentialsGrant(accessToken);

		return new OAuthBuilder().name("OAuth2").grantTypes(Arrays.asList(resourceOwnerPasswordCredentialsGrant)).scopes(scopes()).build();
	}

	private List<AuthorizationScope> scopes() {
		List<AuthorizationScope> scopes = new ArrayList<AuthorizationScope>();
		scopes.add(new AuthorizationScope("org:create", "Crear organización"));
		scopes.add(new AuthorizationScope("org:update", "Editar organización"));
		scopes.add(new AuthorizationScope("org:info", "Obtener información de una organización"));
		scopes.add(new AuthorizationScope("user:info", "Obtener información de un usuario"));
		scopes.add(new AuthorizationScope("subasignar:create", "Crear subasignación IP"));
		scopes.add(new AuthorizationScope("subasignar:update", "Editar subasignación IP"));
		scopes.add(new AuthorizationScope("subasignar:delete", "Eliminar subasignación IP"));
		scopes.add(new AuthorizationScope("ip:info", "Obtener IP"));
		scopes.add(new AuthorizationScope("delegar:create", "Crear delegación rDNS"));
		scopes.add(new AuthorizationScope("delegar:update", "Editar delegación rDNS"));
		scopes.add(new AuthorizationScope("delegar:delete", "Eliminar delegación rDNS"));
		return scopes;
	}

	@Bean
	public SecurityConfiguration security() {
		return SecurityConfigurationBuilder.builder().scopeSeparator(" ").build();
	}
}
