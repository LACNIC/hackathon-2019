package net.lacnic.api.response;

public class CreData {

	private String ipnetwork = "";
	private String schemaLocation = "";
	private IPNetworkIPRange ipRange = new IPNetworkIPRange();
	private String roid = "";
	private String crDate = "";
	private String id = "";
	private String organization = "";

	public CreData() {
	}

	public String getIpnetwork() {
		return ipnetwork;
	}

	public void setIpnetwork(String ipnetwork) {
		this.ipnetwork = ipnetwork;
	}

	public String getSchemaLocation() {
		return schemaLocation;
	}

	public void setSchemaLocation(String schemaLocation) {
		this.schemaLocation = schemaLocation;
	}

	public IPNetworkIPRange getIpRange() {
		return ipRange;
	}

	public void setIpRange(IPNetworkIPRange ipRange) {
		this.ipRange = ipRange;
	}

	public String getRoid() {
		return roid;
	}

	public void setRoid(String roid) {
		this.roid = roid;
	}

	public String getCrDate() {
		return crDate;
	}

	public void setCrDate(String crDate) {
		this.crDate = crDate;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getOrganization() {
		return organization;
	}

	public void setOrganization(String organization) {
		this.organization = organization;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class IpNetworkCreData {\n");
		sb.append("    ipnetwork: ").append(toIndentedString(ipnetwork)).append("\n");
		sb.append("    schemaLocation: ").append(toIndentedString(schemaLocation)).append("\n");
		sb.append("    ipRange: ").append(toIndentedString(ipRange)).append("\n");
		sb.append("    roid: ").append(toIndentedString(roid)).append("\n");
		sb.append("    crDate: ").append(toIndentedString(crDate)).append("\n");
		sb.append("    id: ").append(toIndentedString(id)).append("\n");
		sb.append("    organization: ").append(toIndentedString(organization)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

}
