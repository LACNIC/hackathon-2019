package net.lacnic.domain;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class OrganizationConfig implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "idOrgConfig")
	private String idOrgConfig;

	@Column
	private Boolean baneado = false;

	@Column
	private String clientId;

	@OneToMany(mappedBy = "organization")
	private List<TokenBucketOrg> tokensBucketOrg;

	public OrganizationConfig() {

	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final OrganizationConfig other = (OrganizationConfig) obj;
		return Objects.equals(this.idOrgConfig, other.idOrgConfig);
	}

	@Override
	public int hashCode() {
		int hash = 7;
		hash = 47 * hash + Objects.hashCode(this.idOrgConfig);
		return hash;
	}

	public String getIdOrgConfig() {
		return idOrgConfig;
	}

	public void setIdOrgConfig(String idOrgConfig) {
		this.idOrgConfig = idOrgConfig;
	}

	public Boolean getBaneado() {
		return baneado;
	}

	public void setBaneado(Boolean baneado) {
		this.baneado = baneado;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public List<TokenBucketOrg> getTokensBucketOrg() {
		return tokensBucketOrg;
	}

	public void setTokensBucketOrg(List<TokenBucketOrg> tokensBucketOrg) {
		this.tokensBucketOrg = tokensBucketOrg;
	}
}