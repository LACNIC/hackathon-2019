package net.lacnic.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.skife.jdbi.v2.StatementContext;
import org.skife.jdbi.v2.tweak.ResultSetMapper;

import net.lacnic.domain.TokenBucketOrg;

public class TokenBucketOrgMapper implements ResultSetMapper<TokenBucketOrg> {

	@Override
	public TokenBucketOrg map(int i, ResultSet rs, StatementContext statementContext) throws SQLException {
		TokenBucketOrg tbo = new TokenBucketOrg();
		tbo.setIdTokenBucketOrg(rs.getString("idTokenBucketOrg"));
		tbo.setTokenBucketConfig(rs.getString("tokenBucketConfig"));
		tbo.setBucketSize(rs.getInt("bucketSize"));
		tbo.setTokensToAdd(rs.getInt("tokensToAdd"));
		tbo.setPeriodMinToRerill(rs.getInt("periodMinToRerill"));
		tbo.setOrganization(rs.getString("organization"));
		return tbo;
	}
}
