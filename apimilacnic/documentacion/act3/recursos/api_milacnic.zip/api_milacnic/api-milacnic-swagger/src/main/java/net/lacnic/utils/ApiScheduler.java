package net.lacnic.utils;

import java.util.Date;
import java.util.List;

import javax.ejb.Schedule;
import javax.ejb.Schedules;
import javax.ejb.Stateless;

import org.jboss.ejb3.annotation.TransactionTimeout;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import net.lacnic.domain.OrganizationConfig;
import net.lacnic.ejb.service.impl.ApiAdminServices;
import net.lacnic.epp.EppAdminConnection;
import net.lacnic.epp.EppExternalConnection;
import net.lacnic.tb.StorageTokenBucket;
import net.lacnic.tb.TokenBucket;

@Stateless
@TransactionTimeout(9000)
@EnableScheduling
@Service
public class ApiScheduler {

	@Autowired
	ApiAdminServices tbcService;

	@Scheduled(fixedDelay = 120000)
	public void helloExt() {
		System.out.println("************* helloExt " + new Date() + " *************");
		try {
			SocketFactory instance = SocketFactory.getInstance();
			EppExternalConnection eppExternalConnection = instance.getEppExternalConnection();
			boolean keepAlive = eppExternalConnection.hello();
			System.getProperty("java.classpath");
			System.out.println("************* CONECTANDO... " + new Date() + " *************" + keepAlive + " YEEEEEEE!! *************");
		} catch (Exception e) {
			System.out.println("************* RECONECTANDO... " + new Date() + " *************");
			e.printStackTrace();
		}
		System.out.println("************* helloExt " + new Date() + " FIN *************");
	}

	@Scheduled(fixedDelay = 130000)
	public void helloEPPAdmin() {
		System.out.println("************* helloEPPAdmin " + new Date() + " *************");
		try {
			SocketFactory instance = SocketFactory.getInstance();
			EppAdminConnection eppAdminConnection = instance.getEppAdminConnection();
			boolean keepAlive = eppAdminConnection.hello();
			System.getProperty("java.classpath");
			System.out.println("************* CONECTANDO... " + new Date() + " *************" + keepAlive + " Admin YEEEEEEE!! *************");
		} catch (Exception e) {
			System.out.println("************* RECONECTANDO... " + new Date() + " *************");
			e.printStackTrace();
		}
		System.out.println("************* helloEPPAdmin " + new Date() + " FIN *************");
	}

	@Schedules({ @Schedule(second = "0", minute = "*/1", hour = "*", persistent = false, info = "Refill token buckets") })
	public void refill() {
		Date now = new Date();
		long minutos = now.getTime() / 1000 / 60;

		StorageTokenBucket storageTokenBucket = new StorageTokenBucket(tbcService);

		List<OrganizationConfig> listaOrg = tbcService.listOrganizations();

		for (OrganizationConfig org : listaOrg) {
			TokenBucket defaultTB = storageTokenBucket.getDefaultTokenBucket(org.getIdOrgConfig());
			if (minutos % defaultTB.getPeriodMinToRerill() == 0)
				storageTokenBucket.getDefaultTokenBucket(org.getIdOrgConfig()).refillDefault();

			storageTokenBucket.getOtrosTokenBucket().get(org.getIdOrgConfig()).forEach((k, v) -> {
				if (v != null && (minutos % v.getPeriodMinToRerill() == 0))
					v.refillAction();
			});
		}

	}

}
