package net.lacnic.epp.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.commons.lang.RandomStringUtils;

public class Constantes {
	// solo funciona en Produccion
	// private static String getCONFIGFOLDER() {
	// return "/opt/java/apimilacnic/epp/";
	// }

	private static String getCONFIGFOLDER() {
		try {
			Properties properties = new Properties();
			// properties.load(new
			// FileInputStream("src/main/resources/application.properties"));
			properties.load(Constantes.class.getResourceAsStream("/application.properties"));

			// Esto va al else cuando no esta definida la propiedad en el
			// application.properties
			String property = properties.getProperty("config.epp.dir");
			if (property != null && !property.isEmpty())
				return property;
			else {
				property = System.getProperty("user.home");
				if (property != null && !property.isEmpty())
					return property.concat("/sugar-conf/apimilacnic/epp/");
				else
					return "/opt/java/apimilacnic/configuration/epp/";
			}
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Error, No se puede leer el archivo");
		}
		return "/opt/java/apimilacnic/configuration/epp/";
	}

	public static Properties getEppProperties() {
		Properties pp = new Properties();
		try {
			FileInputStream file = new FileInputStream(getCONFIGFOLDER() + "epp.properties");
			pp.load(file);
			System.out.println(pp);
			System.out.println("pp------------------------------------------------------------------------");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return pp;
	}

	public static String clTRID(String user, String ip, String modificador) {
		return modificador + "-" + user + "-" + ip + "-" + RandomStringUtils.randomAlphanumeric(16);
		// return "a-SERGIO-" + ip + "-" +
		// RandomStringUtils.randomAlphanumeric(16);
	}

	public static String XMLS_FOLDER = getCONFIGFOLDER() + "xmls/";
	public static String CERTS_FOLDER = getCONFIGFOLDER() + "certs/";
	public static String UTF8 = "UTF-8";
	public static String url = "epp.endpoint.url";
	public static String port = "epp.endpoint.port";

	public static String userAdminNumber = "user.admin.number";
	public static String userAdminId = "user.admin.id";
	public static String userAdminPassword = "user.admin.password";

	public static String userExtNumber = "user.ext.number";
	public static String userExtId = "user.ext.id";
	public static String userExtPassword = "user.ext.password";

}