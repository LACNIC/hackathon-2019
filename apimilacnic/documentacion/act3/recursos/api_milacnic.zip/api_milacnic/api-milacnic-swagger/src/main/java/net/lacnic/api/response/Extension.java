package net.lacnic.api.response;

public class Extension {

	private InfoData infData = new InfoData();
	private CreData creData = new CreData();

	public InfoData getInfData() {
		return infData;
	}

	public void setInfData(InfoData infData) {
		this.infData = infData;
	}

	public CreData getCreData() {
		return creData;
	}

	public void setCreData(CreData creData) {
		this.creData = creData;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class Extension {\n");
		sb.append("    infData: ").append(toIndentedString(infData)).append("\n");
		sb.append("    creData: ").append(toIndentedString(creData)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

}
