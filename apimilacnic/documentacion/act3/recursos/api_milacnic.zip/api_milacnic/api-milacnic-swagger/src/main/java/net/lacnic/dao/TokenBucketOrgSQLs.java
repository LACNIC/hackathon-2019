package net.lacnic.dao;

import java.util.List;

import org.skife.jdbi.v2.sqlobject.Bind;
import org.skife.jdbi.v2.sqlobject.BindBean;
import org.skife.jdbi.v2.sqlobject.GetGeneratedKeys;
import org.skife.jdbi.v2.sqlobject.SqlQuery;
import org.skife.jdbi.v2.sqlobject.SqlUpdate;
import org.skife.jdbi.v2.sqlobject.customizers.RegisterMapper;

import net.lacnic.domain.TokenBucketOrg;

@RegisterMapper(TokenBucketOrgMapper.class)
public interface TokenBucketOrgSQLs {

	@SqlQuery("select * from TokenBucketOrg")
	List<TokenBucketOrg> listTBOrg();

	// Ejemplo de insert
	@SqlUpdate("INSERT INTO TokenBucketOrg (idTokenBucketOrg, tokenBucketConfig, bucketSize, periodMinToRerill, tokensToAdd, organization) VALUES(:idTokenBucketOrg, :tokenBucketConfig, :bucketSize, :periodMinToRerill, :tokensToAdd, :organization)")
	@GetGeneratedKeys
	Integer insertTBO(@BindBean TokenBucketOrg tbo);

	// consulta para armar el id del nuevo TokenBucketOrg a crear
	@SqlQuery("SELECT count(*) FROM TokenBucketOrg where organization=:idOrgConfig")
	Integer getCantTokenBucketOrgByIdOrg(@Bind("idOrgConfig") String idOrgConfig);

	@SqlQuery("SELECT * FROM TokenBucketOrg where organization=:organization AND tokenBucketConfig='DEFAULT'")
	TokenBucketOrg obtenerDefaultTokenBucketByOrgId(@Bind("organization") String organization);

	@SqlQuery("SELECT * FROM TokenBucketOrg where organization=:organization AND tokenBucketConfig!='DEFAULT'")
	List<TokenBucketOrg> obtenerOtrosTokenBucketByOrgId(@Bind("organization") String organization);

}
