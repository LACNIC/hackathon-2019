package net.lacnic.model;

import java.util.Objects;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * IpSubasignarDTO
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2019-01-10T12:54:03.514Z[GMT]")

public class IpSubasignarDTO {
	@JsonProperty("destinationOrg")
	private String destinationOrg = null;

	@JsonProperty("cidr")
	private String cidr = "";

	@JsonProperty("statusAllocation")
	private long statusAllocation = 0;

	@JsonProperty("techContact")
	@Valid
	private String techContact = null;

	@JsonProperty("abuseContact")
	@Valid
	private String abuseContact = null;

	public IpSubasignarDTO destinationOrg(String destinationOrg) {
		this.destinationOrg = destinationOrg;
		return this;
	}

	/**
	 * Get destinationOrg
	 * 
	 * @return destinationOrg
	 **/
	@ApiModelProperty(value = "")

	@Valid

	public String getDestinationOrg() {
		return destinationOrg;
	}

	public void setDestinationOrg(String destinationOrg) {
		this.destinationOrg = destinationOrg;
	}

	public IpSubasignarDTO cidrs(String cidr) {
		this.cidr = cidr;
		return this;
	}

	/**
	 * Get cidr
	 * 
	 * @return cidr
	 **/
	@ApiModelProperty(value = "")

	@Valid

	public String getCidr() {
		return cidr;
	}

	public void setCidr(String cidr) {
		this.cidr = cidr;
	}

	public IpSubasignarDTO statusAllocation(long statusAllocation) {
		this.statusAllocation = statusAllocation;
		return this;
	}

	/**
	 * Get statusAllocation
	 * 
	 * @return statusAllocation
	 **/
	@ApiModelProperty(value = "")

	public long getStatusAllocation() {
		return statusAllocation;
	}

	public void setStatusAllocation(long statusAllocation) {
		this.statusAllocation = statusAllocation;
	}

	public IpSubasignarDTO techContact(String techContact) {
		this.techContact = techContact;
		return this;
	}

	/**
	 * Get techContact
	 * 
	 * @return techContact
	 **/
	@ApiModelProperty(value = "")

	@Valid

	public String getTechContact() {
		return techContact;
	}

	public void setTechContact(String techContact) {
		this.techContact = techContact;
	}

	public IpSubasignarDTO abuseContact(String abuseContact) {
		this.abuseContact = abuseContact;
		return this;
	}

	/**
	 * Get abuseContact
	 * 
	 * @return abuseContact
	 **/
	@ApiModelProperty(value = "")

	@Valid

	public String getAbuseContact() {
		return abuseContact;
	}

	public void setAbuseContact(String abuseContact) {
		this.abuseContact = abuseContact;
	}

	@Override
	public boolean equals(java.lang.Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		IpSubasignarDTO ip = (IpSubasignarDTO) o;
		return Objects.equals(this.destinationOrg, ip.destinationOrg) && Objects.equals(this.cidr, ip.cidr) && Objects.equals(this.statusAllocation, ip.statusAllocation) && Objects.equals(this.techContact, ip.techContact) && Objects.equals(this.abuseContact, ip.abuseContact);
	}

	@Override
	public int hashCode() {
		return Objects.hash(destinationOrg, cidr, statusAllocation, techContact, abuseContact);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class IpSubasignarDTO {\n");
		sb.append("    destinationOrg: ").append(toIndentedString(destinationOrg)).append("\n");
		sb.append("    cidr: ").append(toIndentedString(cidr)).append("\n");
		sb.append("    statusAllocation: ").append(toIndentedString(statusAllocation)).append("\n");
		sb.append("    techContact: ").append(toIndentedString(techContact)).append("\n");
		sb.append("    abuseContact: ").append(toIndentedString(abuseContact)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

}
