package net.lacnic.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.skife.jdbi.v2.StatementContext;
import org.skife.jdbi.v2.tweak.ResultSetMapper;

import net.lacnic.domain.TokenBucketConfig;

public class TokenBucketConfigMapper implements ResultSetMapper<TokenBucketConfig> {

	@Override
	public TokenBucketConfig map(int i, ResultSet rs, StatementContext statementContext) throws SQLException {
		TokenBucketConfig tbc = new TokenBucketConfig();
		tbc.setId(rs.getString("id"));
		tbc.setBucketSize(rs.getInt("bucketSize"));
		tbc.setTokensToAdd(rs.getInt("tokensToAdd"));
		tbc.setPeriodMinToRerill(rs.getInt("periodMinToRerill"));
		return tbc;
	}
}
