package net.lacnic.registro.api.response;

import java.io.Serializable;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

@XStreamAlias("lacnicorg:infData")
public class OrgInfDataAdmin implements Serializable {

	private static final long serialVersionUID = -8603085385230437016L;

	@XStreamAlias("lacnicorg:type")
	String type;

	@XStreamImplicit(itemFieldName = "lacnicorg:renewalType")
	List<String> renewalType;

	@XStreamAlias("lacnicorg:renewalDate")
	String renewalDate;

	@XStreamAlias("lacnicorg:resourcesClass")
	String resourcesClass;

	@XStreamAlias("lacnicorg:legacy")
	String legacy;

}
