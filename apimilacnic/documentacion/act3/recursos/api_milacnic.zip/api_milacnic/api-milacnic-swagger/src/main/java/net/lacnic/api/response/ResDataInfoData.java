package net.lacnic.api.response;

public class ResDataInfoData {

	private String schemaLocation = "";
	private String id = "";
	private String roid = "";
	private String status = "";
	private PostalInfo postalInfo = new PostalInfo();
	private ContactVoice voice = new ContactVoice();
	private String fax = "";
	private String email = "";
	private String clID = "";
	private String crID = "";
	private String crDate = "";
	private String upDate = "";
	private IPNetworkIPRange ipRange = new IPNetworkIPRange();
	private IPNetworkIPRangeInfo ipRangeInfo = new IPNetworkIPRangeInfo();

	public ResDataInfoData() {
	}

	public String getSchemaLocation() {
		return schemaLocation;
	}

	public void setSchemaLocation(String schemaLocation) {
		this.schemaLocation = schemaLocation;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getRoid() {
		return roid;
	}

	public void setRoid(String roid) {
		this.roid = roid;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public PostalInfo getPostalInfo() {
		return postalInfo;
	}

	public void setPostalInfo(PostalInfo postalInfo) {
		this.postalInfo = postalInfo;
	}

	public ContactVoice getVoice() {
		return voice;
	}

	public void setVoice(ContactVoice voice) {
		this.voice = voice;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getClID() {
		return clID;
	}

	public void setClID(String clID) {
		this.clID = clID;
	}

	public String getCrID() {
		return crID;
	}

	public void setCrID(String crID) {
		this.crID = crID;
	}

	public String getCrDate() {
		return crDate;
	}

	public void setCrDate(String crDate) {
		this.crDate = crDate;
	}

	public String getUpDate() {
		return upDate;
	}

	public void setUpDate(String upDate) {
		this.upDate = upDate;
	}

	public IPNetworkIPRange getIpRange() {
		return ipRange;
	}

	public void setIpRange(IPNetworkIPRange ipRange) {
		this.ipRange = ipRange;
	}

	public IPNetworkIPRangeInfo getIpRangeInfo() {
		return ipRangeInfo;
	}

	public void setIpRangeInfo(IPNetworkIPRangeInfo ipRangeInfo) {
		this.ipRangeInfo = ipRangeInfo;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class ContactInfoData {\n");
		sb.append("    id: ").append(toIndentedString(id)).append("\n");
		sb.append("    roid: ").append(toIndentedString(roid)).append("\n");
		sb.append("    status: ").append(toIndentedString(status)).append("\n");
		sb.append("    postalInfo: ").append(toIndentedString(postalInfo)).append("\n");
		sb.append("    voice: ").append(toIndentedString(voice)).append("\n");
		sb.append("    fax: ").append(toIndentedString(fax)).append("\n");
		sb.append("    email: ").append(toIndentedString(email)).append("\n");
		sb.append("    ipRange: ").append(toIndentedString(ipRange)).append("\n");
		sb.append("    ipRangeInfo: ").append(toIndentedString(ipRangeInfo)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

}
