package net.lacnic.registro.api.response;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

public class OrgCreExtension extends Extension  implements Serializable{

	@XStreamAlias("brorg:creData")
	OrgCreData orgCreData;
	
	public OrgCreExtension() {
		
		
		}
}
