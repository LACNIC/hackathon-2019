package net.lacnic.epp.pooling;

import java.util.NoSuchElementException;

import net.lacnic.epp.EppAdminConnection;
import net.lacnic.epp.EppExternalConnection;

import org.apache.commons.pool2.ObjectPool;

/**
 * Class that manages the EPPConnection pool
 * 
 * @author agustin
 *
 */
public class EppConnectionUtil {

	public ObjectPool<EppExternalConnection> externalPool;
	// public ObjectPool<EppAdminConnection> adminPool;

	private static EppConnectionUtil instance = null;

	private EppConnectionUtil(ObjectPool<EppExternalConnection> externalPool) {
		this.externalPool = externalPool;
	}

	// private EppConnectionUtil(ObjectPool<EppExternalConnection> externalPool,
	// ObjectPool<EppAdminConnection> adminPool) {
	// this.externalPool = externalPool;
	// this.adminPool = adminPool;
	// }

	private EppConnectionUtil() {

	}

	public static EppConnectionUtil getInstance() {
		if (instance == null) {
			try {
				EppExternalConnectionPool externalConnectionPool = new EppExternalConnectionPool(new EppExternalConnectionFactory());
				// EppAdminConnectionPool adminConnectionPool = new
				// EppAdminConnectionPool(new EppAdminConnectionFactory());

				externalConnectionPool.preparePool();
				instance = new EppConnectionUtil(externalConnectionPool);

				// adminConnectionPool.preparePool();
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		return instance;
	}

	/*
	 * EXTERNAL
	 */

	public EppExternalConnection borrowExternalConnection() throws NoSuchElementException, IllegalStateException, Exception {
		return externalPool.borrowObject();
	}

	public void returnExternalConnection(EppExternalConnection obj) throws Exception {
		externalPool.returnObject(obj);
	}

	public int getNumIdleExternalConnection() {
		return externalPool.getNumIdle();
	}

	public int getNumActiveExternalConnection() {
		return externalPool.getNumActive();
	}

	public ObjectPool<EppExternalConnection> getExternalConnectionPool() {
		return externalPool;
	}

	public void setExternalConnectionPool(ObjectPool<EppExternalConnection> pool) {
		this.externalPool = pool;
	}

	/*
	 * ADMIN
	 */

//	public EppAdminConnection borrowAdminConnection() throws NoSuchElementException, IllegalStateException, Exception {
//		return adminPool.borrowObject();
//	}
//
//	public void returnAdminConnection(EppAdminConnection obj) throws Exception {
//		adminPool.returnObject(obj);
//	}
//
//	public int getNumIdleAdminConnection() {
//		return adminPool.getNumIdle();
//	}
//
//	public int getNumActiveAdminConnection() {
//		return adminPool.getNumActive();
//	}
//
//	public ObjectPool<EppAdminConnection> getAdminConnectionPool() {
//		return adminPool;
//	}
//
//	public void setAdminConnectionPool(ObjectPool<EppAdminConnection> pool) {
//		this.adminPool = pool;
//	}

}
