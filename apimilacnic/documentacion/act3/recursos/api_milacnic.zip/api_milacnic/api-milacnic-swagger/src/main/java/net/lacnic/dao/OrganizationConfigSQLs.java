package net.lacnic.dao;

import java.util.List;

import org.skife.jdbi.v2.sqlobject.Bind;
import org.skife.jdbi.v2.sqlobject.BindBean;
import org.skife.jdbi.v2.sqlobject.GetGeneratedKeys;
import org.skife.jdbi.v2.sqlobject.SqlQuery;
import org.skife.jdbi.v2.sqlobject.SqlUpdate;
import org.skife.jdbi.v2.sqlobject.customizers.RegisterMapper;

import net.lacnic.domain.OrganizationConfig;

@RegisterMapper(OrganizationConfigMapper.class)
public interface OrganizationConfigSQLs {

	@SqlQuery("select * from OrganizationConfig")
	List<OrganizationConfig> listOrgConfig();

	@SqlQuery("select * from OrganizationConfig where idOrgConfig=:idOrgConfig")
	OrganizationConfig getOrgConfigById(@Bind("idOrgConfig") String idOrgConfig);

	@SqlQuery("select * from OrganizationConfig where clientId=:clientId")
	OrganizationConfig getOrgConfigByClientId(@Bind("clientId") String clientId);

	@SqlUpdate("insert into OrganizationConfig (idOrgConfig, baneado, clientId) values(:idOrgConfig, :baneado, :clientId) ")
	@GetGeneratedKeys
	Integer insertOrgConfig(@BindBean OrganizationConfig org);

}
