package net.lacnic.api;

import java.util.List;

import javax.annotation.Generated;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.auth0.jwt.JWT;
import com.auth0.jwt.exceptions.JWTDecodeException;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.swagger.annotations.ApiParam;
import net.lacnic.ejb.service.impl.ApiAdminServices;
import net.lacnic.epp.util.ResponseWs;
import net.lacnic.model.OrganizationCreateDTO;
import net.lacnic.model.OrganizationDTO;
import net.lacnic.model.OrganizationUpdateDTO;
import net.lacnic.model.UserCreateDTO;
import net.lacnic.model.UserDTO;
import net.lacnic.registro.api.request.Address;
import net.lacnic.registro.api.request.Contact;
import net.lacnic.registro.api.request.OrgRequest;
import net.lacnic.registro.api.request.Phone;
import net.lacnic.registro.api.request.UserRequest;
import net.lacnic.tb.StorageTokenBucket;
import net.lacnic.utils.RateLimit;
import net.lacnic.utils.SocketFactory;

@Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2019-01-07T15:51:50.032Z[GMT]")

@Controller
public class EntityApiController implements EntityApi {

	@Autowired
	ApiAdminServices apiAdminService;

	private static final Logger LOGGER = LoggerFactory.getLogger(EntityApiController.class);

	private final ObjectMapper objectMapper;

	private final HttpServletRequest request;

	private final String userOrgEPP = "SERGIO";

	@org.springframework.beans.factory.annotation.Autowired
	public EntityApiController(ObjectMapper objectMapper, HttpServletRequest request) {
		this.objectMapper = objectMapper;
		this.request = request;
	}

	// Get Org
	public ResponseEntity<Object> entityOrganizationsOrgIdGet(@ApiParam(value = "", required = true) @PathVariable("orgId") String orgId) {
		String accept = request.getHeader("Accept");
		String idOrgRequest = "";
		String ip = request.getRemoteAddr();
		LOGGER.info("**EJECUTANDO Obtener Organización**");
		try {
			OrgRequest org = new OrgRequest(userOrgEPP, ip, orgId);
			apiAdminService.obtenerOrgEppAdmin(org);
			String user = apiAdminService.convertirOrg(SocketFactory.getInstance().getEppAdminConnection().getFrameOrg()).getAdminContact();
			// Ratelimit
			String token = request.getHeader("Authorization");
			String clientId = "";
			if (token != null && token.startsWith("Bearer")) {
				Authentication auth = SecurityContextHolder.getContext().getAuthentication();
				if (auth.getName().contains("@")) {
					String[] clients = auth.getName().split("@");
					clientId = clients[0];
				} else {
					try {
						DecodedJWT jwt = JWT.decode(auth.getCredentials().toString());
						clientId = jwt.getClaims().get("azp").asString();
					} catch (JWTDecodeException exception) {
						// Invalid token
					}
				}
				if (apiAdminService.existeOrgConfig(clientId)) {
					apiAdminService.insertarTokensBucketOrg(clientId);

					StorageTokenBucket storageTokenBucket = new StorageTokenBucket(apiAdminService);
					idOrgRequest = apiAdminService.obtenerOrgConfig(clientId).getIdOrgConfig();
					LOGGER.info("Operación ejecutada por la organización " + idOrgRequest);
					if (!storageTokenBucket.tryConsumeAction(idOrgRequest, RateLimit.ORG_INFO)) {
						LOGGER.warn("No tiene consultas disponibles");
						return new ResponseEntity<Object>(HttpStatus.TOO_MANY_REQUESTS);
					}
				} else {
					LOGGER.warn("Organización no autorizada");
					return new ResponseEntity<Object>(HttpStatus.UNAUTHORIZED);
				}
			} else {
				LOGGER.warn("Token incorrecto");
				return new ResponseEntity<Object>(HttpStatus.UNAUTHORIZED);
			}
			// Ratelimit
			OrgRequest orgRequest = new OrgRequest(user, ip, orgId);
			ResponseWs res = apiAdminService.obtenerOrg(orgRequest);
			if (res != null) {
				LOGGER.info("ResponseWS NO devolvió nulo");
				OrganizationDTO datos = apiAdminService.convertirOrg(SocketFactory.getInstance().getEppExternalConnection().getFrameOrg());
				System.out.println("++++****Esto es el user que saqué con el OrgDTO: " + datos.getAdminContact());
				return ResponseEntity.ok(datos);
			} else {
				LOGGER.warn("ResponseWS SI devolvió nulo");
				return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			LOGGER.error("Ha ocurrido el siguiente error: " + e);
			return new ResponseEntity<Object>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	// Editar Organización
	// @PreAuthorize("hasAuthority('org:update')")
	public ResponseEntity<Object> entityOrganizationsOrgIdPut(@ApiParam(value = "Estos datos son necesarios para realizar la operación.", required = true) @Valid @RequestBody OrganizationUpdateDTO body, @ApiParam(value = "", required = true) @PathVariable("orgId") String orgId) {
		String accept = request.getHeader("Accept");
		String ip = request.getRemoteAddr();
		String user = "";
		String idOrgRequest = "";
		LOGGER.info("**EJECUTANDO Editar Organización**");
		try {
			// Ratelimit
			String token = request.getHeader("Authorization");
			String clientId = "";
			if (token != null && token.startsWith("Bearer")) {
				Authentication auth = SecurityContextHolder.getContext().getAuthentication();
				if (auth.getName().contains("@")) {
					String[] clients = auth.getName().split("@");
					clientId = clients[0];
					System.out.println("+++****El clientId es:" + clientId);
				} else {
					try {
						DecodedJWT jwt = JWT.decode(auth.getCredentials().toString());
						clientId = jwt.getClaims().get("azp").asString();
						System.out.println("+++****El clientId es:" + clientId);
					} catch (JWTDecodeException exception) {
						// Invalid token
					}
				}
				if (apiAdminService.existeOrgConfig(clientId)) {
					apiAdminService.insertarTokensBucketOrg(clientId);

					StorageTokenBucket storageTokenBucket = new StorageTokenBucket(apiAdminService);
					idOrgRequest = apiAdminService.obtenerOrgConfig(clientId).getIdOrgConfig();
					LOGGER.info("Operación ejecutada por la organización " + idOrgRequest);
					OrgRequest org = new OrgRequest(userOrgEPP, ip, idOrgRequest);
					apiAdminService.obtenerOrgEppAdmin(org);
					user = apiAdminService.convertirOrg(SocketFactory.getInstance().getEppAdminConnection().getFrameOrg()).getAdminContact();
					if (!storageTokenBucket.tryConsumeAction(idOrgRequest, RateLimit.ORG_UPDATE)) {
						LOGGER.warn("No tiene consultas disponibles");
						return new ResponseEntity<Object>(HttpStatus.TOO_MANY_REQUESTS);
					}
				} else {
					LOGGER.warn("Organización no autorizada");
					return new ResponseEntity<Object>(HttpStatus.UNAUTHORIZED);
				}
			} else {
				LOGGER.warn("Token incorrecto");
				return new ResponseEntity<Object>(HttpStatus.UNAUTHORIZED);
			}
			// End Ratelimit
			Address address = new Address();
			if (body.getAddress() != null) {
				address = body.getAddress().converterToModel(body.getAddress());
			}
			Phone phone = new Phone();
			if (body.getPhone() != null) {
				phone = body.getPhone().converterToModel(body.getPhone());
			} else
				phone = null; // EPP no reconoce cuando este valor viene null, por lo que fue necesario
								// declararlo null aquí antes de pasarselo al constructor del OrgRequest

			OrgRequest orgRequest = new OrgRequest(user, ip, orgId, body.getAdminContact(), body.getCobContact(), body.getMemContact(), body.getResponsible(), address, phone);
			ResponseWs res = apiAdminService.editarOrganizacion(orgRequest, idOrgRequest);
			String trId = apiAdminService.infoMetodoEPP();
			if (res != null) {
				LOGGER.info("ResponseWS NO devolvió nulo");
				LOGGER.info("Info del TRID:\n" + trId);
				return ResponseEntity.ok(trId);
			} else {
				LOGGER.warn("ResponseWS SI devolvió nulo");
				return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			LOGGER.error("Ha ocurrido el siguiente error: " + e);
			return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
		}
	}

	// Crear Organizacion
	public ResponseEntity<Object> entityOrganizationsPost(@ApiParam(value = "Estos son los datos necesarios para realizar la operación.", required = true) @Valid @RequestBody OrganizationCreateDTO body) {
		String accept = request.getHeader("Accept");
		String ip = request.getRemoteAddr();
		String user = "";
		String idOrgRequest = "";
		LOGGER.info("**EJECUTANDO Crear Organización**");
		try {
			// Ratelimit
			String token = request.getHeader("Authorization");
			String clientId = "";
			if (token != null && token.startsWith("Bearer")) {
				Authentication auth = SecurityContextHolder.getContext().getAuthentication();
				if (auth.getName().contains("@")) {
					String[] clients = auth.getName().split("@");
					clientId = clients[0];
				} else {
					try {
						DecodedJWT jwt = JWT.decode(auth.getCredentials().toString());
						clientId = jwt.getClaims().get("azp").asString();
					} catch (JWTDecodeException exception) {
						// Invalid token
					}
				}
				if (apiAdminService.existeOrgConfig(clientId)) {
					apiAdminService.insertarTokensBucketOrg(clientId);

					StorageTokenBucket storageTokenBucket = new StorageTokenBucket(apiAdminService);
					idOrgRequest = apiAdminService.obtenerOrgConfig(clientId).getIdOrgConfig();
					LOGGER.info("Operación ejecutada por la organización " + idOrgRequest);
					OrgRequest org = new OrgRequest(userOrgEPP, ip, idOrgRequest);
					apiAdminService.obtenerOrgEppAdmin(org);
					user = apiAdminService.convertirOrg(SocketFactory.getInstance().getEppAdminConnection().getFrameOrg()).getAdminContact();
					if (!storageTokenBucket.tryConsumeAction(idOrgRequest, RateLimit.ORG_CREATE)) {
						LOGGER.warn("No tiene consultas disponibles");
						return new ResponseEntity<Object>(HttpStatus.TOO_MANY_REQUESTS);
					}
				} else {
					LOGGER.warn("Organización no autorizada");
					return new ResponseEntity<Object>(HttpStatus.UNAUTHORIZED);
				}
			} else {
				LOGGER.warn("Token incorrecto");
				return new ResponseEntity<Object>(HttpStatus.UNAUTHORIZED);
			}
			// Ratelimit
			Address address = new Address();
			if (body.getAddress() != null) {
				address = body.getAddress().converterToModel(body.getAddress());
			}
			Phone phone = new Phone();
			if (body.getPhone() != null) {
				phone = body.getPhone().converterToModel(body.getPhone());
			}
			OrgRequest orgRequest = new OrgRequest(user, ip, body.getAddress().getCountry(), body.getPhone().getCountryCode());
			orgRequest.setName(body.getName());
			orgRequest.setResponsible(body.getResponsible());
			orgRequest.setPhone(phone);
			orgRequest.setAddress(address);
			List<Contact> contacts = apiAdminService.modificarContactosEntity(body.getAdminContact(), body.getCobContact(), body.getMemContact(), orgRequest);
			orgRequest.setContacts(contacts);
			ResponseWs res = apiAdminService.crearOrganizacion(orgRequest, idOrgRequest);
			String createdOrg = apiAdminService.getCreatedOrg();
			String trId = apiAdminService.infoMetodoEPP();
			if (res != null) {
				LOGGER.info("ResponseWS NO devolvió nulo");
				LOGGER.info("OrgId de la organización creada:\n" + createdOrg);
				LOGGER.info("Info del TRID:\n" + trId);
				return ResponseEntity.ok("OrgId: " + createdOrg + "\n" + trId);
			} else {
				LOGGER.warn("ResponseWS SI devolvió nulo");
				return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			LOGGER.error("Ha ocurrido el siguiente error: " + e);
			return new ResponseEntity<Object>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	// **Editar Usuario, Probando**
	public ResponseEntity<Object> entityUsersIdPut(@ApiParam(value = "Estos son los datos necesarios para realizar la operación.", required = true) @Valid @RequestBody UserCreateDTO body, @ApiParam(value = "", required = true) @PathVariable("id") String id) {
		String accept = request.getHeader("Accept");
		System.out.println("**EJECUTANDO Editar Usuario**");
		String ip = request.getRemoteAddr();
		String user = "ANU";
		Address address = new Address();
		if (body.getAddress() != null) {
			address = body.getAddress().converterToModel(body.getAddress());
		}
		Phone phone = new Phone();
		if (body.getPhone() != null) {
			phone = body.getPhone().converterToModel(body.getPhone());
		}
		UserRequest userRequest = new UserRequest(user, ip, id, body.getName(), body.getEmail(), body.getLanguage(), body.getPassword(), body.getReminderPassword(), address, phone);
		System.out.println("Convirtió este mail " + body.getEmail() + " a este mail " + userRequest.getEmail());
		ResponseWs res = apiAdminService.editarUsuario(userRequest);
		String trId = apiAdminService.infoMetodoEPP();
		if (res != null) {
			System.out.println("ResponseWS NO devolvió nulo");
			return ResponseEntity.ok(trId);
		}
		return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
	}

	// **Crear Usuario, Casi Listo**
	public ResponseEntity<Object> entityUsersPost(@ApiParam(value = "Estos son los datos necesarios para realizar la operación.", required = true) @Valid @RequestBody UserCreateDTO body) {
		String accept = request.getHeader("Accept");
		System.out.println("**EJECUTANDO Crear Usuario**");
		String ip = request.getRemoteAddr();
		String user = "ANU";
		Address address = new Address();
		if (body.getAddress() != null) {
			address = body.getAddress().converterToModel(body.getAddress());
		}
		Phone phone = new Phone();
		if (body.getPhone() != null) {
			phone = body.getPhone().converterToModel(body.getPhone());
		}
		UserRequest userRequest = new UserRequest(user, ip, body.getName(), body.getEmail(), body.getLanguage(), body.getPassword(), body.getReminderPassword(), address, phone);
		System.out.println("Convirtió este mail " + body.getEmail() + " a este mail " + userRequest.getEmail());
		ResponseWs res = apiAdminService.crearUsuario(userRequest);
		String trId = apiAdminService.infoMetodoEPP();
		if (res != null) {
			System.out.println("ResponseWS NO devolvió nulo");
			return ResponseEntity.ok(trId);
		}
		return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
	}

	// Get User
	public ResponseEntity<Object> entityUsersIdGet(@ApiParam(value = "", required = true) @PathVariable("id") String id) {
		String accept = request.getHeader("Accept");
		String ip = request.getRemoteAddr();
		String user = "";
		LOGGER.info("**EJECUTANDO Obtener Usuario**");
		try {
			// Ratelimit
			String token = request.getHeader("Authorization");
			String clientId = "";
			if (token != null && token.startsWith("Bearer")) {
				Authentication auth = SecurityContextHolder.getContext().getAuthentication();
				if (auth.getName().contains("@")) {
					String[] clients = auth.getName().split("@");
					clientId = clients[0];
				} else {
					try {
						DecodedJWT jwt = JWT.decode(auth.getCredentials().toString());
						clientId = jwt.getClaims().get("azp").asString();
					} catch (JWTDecodeException exception) {
						// Invalid token
					}
				}
				if (apiAdminService.existeOrgConfig(clientId)) {
					apiAdminService.insertarTokensBucketOrg(clientId);

					StorageTokenBucket storageTokenBucket = new StorageTokenBucket(apiAdminService);
					String idOrgRequest = apiAdminService.obtenerOrgConfig(clientId).getIdOrgConfig();
					LOGGER.info("Operación ejecutada por la organización " + idOrgRequest);
					OrgRequest org = new OrgRequest(userOrgEPP, ip, idOrgRequest);
					apiAdminService.obtenerOrgEppAdmin(org);
					user = apiAdminService.convertirOrg(SocketFactory.getInstance().getEppAdminConnection().getFrameOrg()).getAdminContact();
					if (!storageTokenBucket.tryConsumeAction(idOrgRequest, RateLimit.CONTACT_INFO)) {
						LOGGER.warn("No tiene consultas disponibles");
						return new ResponseEntity<Object>(HttpStatus.TOO_MANY_REQUESTS);
					}
				} else {
					LOGGER.warn("Organización no autorizada");
					return new ResponseEntity<Object>(HttpStatus.UNAUTHORIZED);
				}
			} else {
				LOGGER.warn("Token incorrecto");
				return new ResponseEntity<Object>(HttpStatus.UNAUTHORIZED);
			}
			// End Ratelimit
			UserRequest userRequest = new UserRequest(user, ip);
			userRequest.setId(id);
			ResponseWs res = apiAdminService.obtenerUsuario(userRequest);
			if (res != null) {
				LOGGER.warn("ResponseWS NO devolvió nulo");
				UserDTO datos = apiAdminService.convertirUser();
				return ResponseEntity.ok(datos);
			} else {
				LOGGER.warn("ResponseWS SI devolvió nulo");
				return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			LOGGER.error("Ha ocurrido el siguiente error: " + e);
			e.printStackTrace();
			return new ResponseEntity<Object>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
