package net.lacnic.dao;

import java.sql.Connection;
import java.util.List;

import javax.sql.DataSource;

import org.skife.jdbi.v2.DBI;
import org.skife.jdbi.v2.Handle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.stereotype.Component;

import net.lacnic.domain.OrganizationConfig;

@Component
public class OrganizationConfigDao {

	@Qualifier("dsApi")
	@Autowired
	private DataSource dataSource;

	public OrganizationConfigSQLs connectionOrganizationConfig() {
		Connection conn = DataSourceUtils.getConnection(dataSource);
		Handle handle = DBI.open(conn);
		OrganizationConfigSQLs ocSQLs = handle.attach(OrganizationConfigSQLs.class);
		return ocSQLs;
	}

	public List<OrganizationConfig> listOrgConfig() {
		OrganizationConfigSQLs ocSQLs = connectionOrganizationConfig();
		return ocSQLs.listOrgConfig();
	}

	public OrganizationConfig getOrgConfigById(String idOrgConfig) {
		OrganizationConfigSQLs ocSQLs = connectionOrganizationConfig();
		return ocSQLs.getOrgConfigById(idOrgConfig);
	}

	public OrganizationConfig getOrgConfigByClientId(String clientId) {
		OrganizationConfigSQLs ocSQLs = connectionOrganizationConfig();
		return ocSQLs.getOrgConfigByClientId(clientId);
	}

	public OrganizationConfig insertOrgConfig(OrganizationConfig orgConfig) {
		System.out.println("Entrooó al insertOrgConfig");
		OrganizationConfigSQLs ocSQLs = connectionOrganizationConfig();
		ocSQLs.insertOrgConfig(orgConfig);
		return orgConfig;
	}

}
