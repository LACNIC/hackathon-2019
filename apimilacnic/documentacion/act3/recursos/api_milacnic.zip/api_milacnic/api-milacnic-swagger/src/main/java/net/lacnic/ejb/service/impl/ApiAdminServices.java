package net.lacnic.ejb.service.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.dataformat.xml.XmlMapper;

import net.lacnic.api.response.ContactResponse;
import net.lacnic.api.response.EPP;
import net.lacnic.api.response.IPNetworkChildNetwork;
import net.lacnic.api.response.IPNetworkParentNetwork;
import net.lacnic.api.response.IPNetworkReverseDNS;
import net.lacnic.dao.OrganizationConfigDao;
import net.lacnic.dao.TokenBucketConfigDao;
import net.lacnic.dao.TokenBucketOrgDao;
import net.lacnic.domain.OrganizationConfig;
import net.lacnic.domain.TokenBucketConfig;
import net.lacnic.domain.TokenBucketOrg;
import net.lacnic.epp.util.ResponseWs;
import net.lacnic.model.AddressDTO;
import net.lacnic.model.IPNetworkChildDTO;
import net.lacnic.model.IPNetworkParentDTO;
import net.lacnic.model.IPNetworkRangeDTO;
import net.lacnic.model.IpDTO;
import net.lacnic.model.OrganizationDTO;
import net.lacnic.model.PhoneDTO;
import net.lacnic.model.ReverseDNSDTO;
import net.lacnic.model.UserDTO;
import net.lacnic.registro.api.request.Contact;
import net.lacnic.registro.api.request.IpRequest;
import net.lacnic.registro.api.request.OrgRequest;
import net.lacnic.registro.api.request.TipoAlocacion;
import net.lacnic.registro.api.request.UserRequest;
import net.lacnic.registro.api.response.ResponseObject;
import net.lacnic.utils.SocketFactory;

@Component
public class ApiAdminServices {

	@Autowired
	private TokenBucketConfigDao tbcDao;

	@Autowired
	private OrganizationConfigDao ocDao;

	@Autowired
	private TokenBucketOrgDao tboDao;

	protected String createdOrg;

	@Transactional
	public List<TokenBucketConfig> listTBConfig() {
		return tbcDao.listTBConfig();
	}

	@Transactional
	public TokenBucketConfig obtenerDefaultTokenBucket() {
		System.out.println("Entro al obtenerDefaultTokenBucket() del TokenBucketServices");
		return tbcDao.obtenerDefaultTokenBucket();
	}

	@Transactional
	public List<TokenBucketConfig> obtenerOtrosTokenBucket() {
		return tbcDao.obtenerOtrosTokenBucket();
	}

	@Transactional
	public void insertarTokensBucketOrg(String clientId) {
		try {
			System.out.println("Entrooó al insertarOrgConfig");
			OrganizationConfig orgConfig = ocDao.getOrgConfigByClientId(clientId);
			String orgId = orgConfig.getIdOrgConfig();
			System.out.println("El orgId es: " + orgId);

			int cantTBO = tboDao.getCantTokenBucketOrgByIdOrg(orgId);
			System.out.println("El cantTBO es: " + cantTBO);
			if (cantTBO != 0) {
				System.out.println("El cantTBC es: " + tbcDao.getCantTokenBucketConfig());
				if (cantTBO != tbcDao.getCantTokenBucketConfig()) {
					List<TokenBucketConfig> noEstanTBO = tbcDao.obtenerNoEstanEnTokenBucketOrg(orgId);

					for (TokenBucketConfig tbc : noEstanTBO) {
						System.out.println("No están en TBO: " + tbc.getId());
						insertTBO(orgId, tbc);
					}
				}
			} else {
				List<TokenBucketConfig> listTBC = tbcDao.listTBConfig();
				for (TokenBucketConfig tbc : listTBC) {
					insertTBO(orgId, tbc);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void insertTBO(String orgId, TokenBucketConfig tbc) {
		TokenBucketOrg tbOrg = new TokenBucketOrg();
		tbOrg.setIdTokenBucketOrg(this.armarIdTokenBucketConfig(orgId));
		tbOrg.setOrganization(orgId);
		tbOrg.setTokenBucketConfig(tbc.getId());
		tbOrg.setBucketSize(tbc.getBucketSize());
		tbOrg.setPeriodMinToRerill(tbc.getPeriodMinToRerill());
		tbOrg.setTokensToAdd(tbc.getTokensToAdd());
		tboDao.insertTBO(tbOrg);
	}

	@Transactional
	public TokenBucketOrg obtenerDefaultTokenBucketByOrgId(String orgId) {
		System.out.println("Entro al obtenerDefaultTokenBucketByOrgId() del TokenBucketServices");
		return tboDao.obtenerDefaultTokenBucketByOrgId(orgId);
	}

	@Transactional
	public List<TokenBucketOrg> obtenerOtrosTokenBucketByOrgId(String orgId) {
		return tboDao.obtenerOtrosTokenBucketByOrgId(orgId);
	}

	@Transactional
	public boolean existeTokenBucketOrg(String orgId) {
		System.out.println("Entrooó al existeTokenBucketOrg");
		int cantTBO = tboDao.getCantTokenBucketOrgByIdOrg(orgId);
		return cantTBO != 0;
	}

	@Transactional
	public boolean existeOrgConfig(String clientId) {
		System.out.println("Entrooó al existeOrgConfig");
		OrganizationConfig oc = ocDao.getOrgConfigByClientId(clientId);
		return oc != null;
	}

	@Transactional
	public OrganizationConfig obtenerOrgConfig(String clientId) {
		System.out.println("Entrooó al obtenerOrgConfig");
		return ocDao.getOrgConfigByClientId(clientId);
	}

	@Transactional
	public List<OrganizationConfig> listOrganizations() {
		System.out.println("Entrooó al existeOrgConfig");
		return ocDao.listOrgConfig();
	}

	@Transactional
	public String armarIdTokenBucketConfig(String orgId) {
		return orgId + "_" + tboDao.getCantTokenBucketOrgByIdOrg(orgId);

	}

	public ResponseWs crearUsuario(UserRequest userRequest) {
		try {
			System.out.println("ENTRÓ A ResponseWS");
			ResponseObject responseObject = SocketFactory.getInstance().getEppExternalConnection().crearUsuarioLACNIC(userRequest);
			System.out.println("ResponseObject tine esto dentro: " + responseObject.getResponse());
			return new ResponseWs(responseObject.getResponse());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public ResponseWs editarUsuario(UserRequest userRequest) {
		try {
			ResponseObject responseObject = SocketFactory.getInstance().getEppExternalConnection().modificarUsuario(userRequest);
			return new ResponseWs(responseObject.getResponse());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public ResponseWs crearOrganizacion(OrgRequest orgRequest, String nombreOrg) {
		try {
			ResponseObject responseObject = SocketFactory.getInstance().getEppExternalConnection().crearOrganizacionLACNIC(orgRequest, nombreOrg);
			System.out.println("&&&&***El ResponseObject de CrearOrg es: " + responseObject.toString());
			createdOrg = responseObject.getResponse().getExtension().getOrgCreData().getBrOrgOrganization();
			System.out.println("&&&&***El @XStream de CrearOrg es: " + createdOrg);
			return new ResponseWs(responseObject.getResponse());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public ResponseWs editarOrganizacion(OrgRequest orgRequest, String nombreOrg) {
		try {
			ResponseObject responseObject = SocketFactory.getInstance().getEppExternalConnection().editarOrganizacion(orgRequest, nombreOrg);
			return new ResponseWs(responseObject.getResponse());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public List<Contact> modificarContactosEntity(String adminContact, String cobContact, String memContact, OrgRequest orgRequest) {
		List<Contact> contacts = orgRequest.getContacts();
		if (adminContact != null) {
			contacts.get(0).setHandle(adminContact);
		}
		if (cobContact != null) {
			contacts.get(1).setHandle(cobContact);
		}
		if (memContact != null) {
			contacts.get(2).setHandle(memContact);
		}
		return contacts;
	}

	public ResponseWs obtenerUsuario(UserRequest userRequest) {
		try {
			ResponseObject responseObject = SocketFactory.getInstance().getEppExternalConnection().infoUsuario(userRequest);
			return new ResponseWs(responseObject.getResponse());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public ResponseWs obtenerOrg(OrgRequest orgRequest) {
		try {
			System.out.println("Entró al obtenerOrg");
			ResponseObject responseObject = SocketFactory.getInstance().getEppExternalConnection().infoOrg(orgRequest);
			return new ResponseWs(responseObject.getResponse());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public ResponseWs obtenerOrgEppAdmin(OrgRequest orgRequest) {
		try {
			ResponseObject responseObject = SocketFactory.getInstance().getEppAdminConnection().infoOrg(orgRequest);
			return new ResponseWs(responseObject.getResponse());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public ResponseWs crearBloqueIp(IpRequest ipRequest, String nombreOrg) {
		try {
			ResponseObject responseObject = SocketFactory.getInstance().getEppExternalConnection().createIP(ipRequest, nombreOrg);
			return new ResponseWs(responseObject.getResponse());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public ResponseWs editarIPContactoYAsn(IpRequest ipRequest, String nombreOrg) {
		try {
			ResponseObject responseObject = SocketFactory.getInstance().getEppExternalConnection().editarIPContactoYAsn(ipRequest, nombreOrg);
			return new ResponseWs(responseObject.getResponse());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public void modificarContactosBloqueIp(String techContact, String abuseContact, IpRequest ipRequest) {
		List<Contact> contacts = ipRequest.getContacts();
		if (techContact != null) {
			contacts.get(0).setHandle(techContact);
		}
		if (abuseContact != null) {
			contacts.get(1).setHandle(abuseContact);
		}
		ipRequest.setContacts(contacts);
	}

	public ResponseWs eliminarBloqueIp(IpRequest ipRequest, String nombreOrg) {
		try {
			ResponseObject responseObject = SocketFactory.getInstance().getEppExternalConnection().deleteIP(ipRequest, nombreOrg);
			return new ResponseWs(responseObject.getResponse());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public ResponseWs editarDominio(IpRequest ipRequest, String nombreOrg) {
		try {
			ResponseObject responseObject = SocketFactory.getInstance().getEppExternalConnection().editarIP(ipRequest, nombreOrg);
			return new ResponseWs(responseObject.getResponse());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public ResponseWs eliminarDominio(IpRequest ipRequest, String nombreOrg) throws Exception {
		try {
			final ResponseObject responseObject = SocketFactory.getInstance().getEppExternalConnection().deleteDomain(ipRequest, nombreOrg);
			return new ResponseWs(responseObject.getResponse());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public ResponseWs obtenerBloqueIp(IpRequest ipRequest) {
		try {
			ResponseObject responseObject = SocketFactory.getInstance().getEppExternalConnection().infoIP(ipRequest);
			return new ResponseWs(responseObject.getResponse());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public String infoMetodoEPP() {
		try {
			String xml = SocketFactory.getInstance().getEppExternalConnection().getFrameEpp();
			XmlMapper xmlMapper = new XmlMapper();
			EPP responseObj = xmlMapper.readValue(xml, EPP.class);
			String[] cltrId = responseObj.getResponse().getTrID().getClTRID().split("-");
			return ("Request Id: " + cltrId[3] + "\nResponse Id: " + responseObj.getResponse().getTrID().getSvTRID());
		} catch (IOException ex) {
			Logger.getLogger(ApiAdminServices.class.getName()).log(Level.SEVERE, null, ex);
		}
		return null;
	}

	public OrganizationDTO convertirOrg(String xmlOrg) {
		try {
			String xml;
			String xmlCadena1;
			String xmlCadena2;
			if (xmlOrg.contains("<lacnicorg:infData")) {
				// Para obtener todo el contenido del XML antes del tag <lacnicorg:infData
				String[] array1 = xmlOrg.split("<lacnicorg:infData");
				xmlCadena1 = array1[0];

				// Para obtener todo el contenido del XML después del tag </lacnicorg:infData>
				String[] array2 = array1[1].split("</lacnicorg:infData>");
				xmlCadena2 = array2[1];

				// Unir el XML sin el contenido de <lacnicorg:infData></lacnicorg:infData>
				xml = xmlCadena1 + xmlCadena2;
			} else {
				xml = xmlOrg;
			}

			if (!xml.contains("<brorg:name>")) {
				xml = xml.replace("<brorg:contact type=\"admin\">", "<brorg:contact type=\"admin\"><brorg:name>");
				xml = xml.replace("<brorg:contact type=\"billing\">", "<brorg:contact type=\"billing\"><brorg:name>");
				xml = xml.replace("<brorg:contact type=\"member\">", "<brorg:contact type=\"member\"><brorg:name>");
				xml = xml.replace("</brorg:contact>", "</brorg:name></brorg:contact>");
			}

			if (xml.contains("<contact:voice></contact:voice>")) {
				xml = xml.replace("<contact:voice>", "<contact:voice><contact:phone></contact:phone>");
			} else if (xml.contains("<contact:voice")) {
				xml = xml.replace("+", "<contact:phone>+");
				xml = xml.replace("</contact:voice>", "</contact:phone></contact:voice>");
			}
			XmlMapper xmlMapper = new XmlMapper();
			EPP responseObj = xmlMapper.readValue(xml, EPP.class);

			OrganizationDTO org = new OrganizationDTO();
			if (responseObj != null && responseObj.getResponse() != null) {
				if (responseObj.getResponse().getExtension() != null && responseObj.getResponse().getExtension().getInfData() != null) {
					org.setOrgId(responseObj.getResponse().getExtension().getInfData().getOrganization());
					org.setResponsible(responseObj.getResponse().getExtension().getInfData().getResponsible());

					String adminContact = "";
					String cobContact = "";
					String memContact = "";
					for (int i = 0; i < responseObj.getResponse().getExtension().getInfData().getContact().size(); i++) {
						if (responseObj.getResponse().getExtension().getInfData().getContact().get(i).getType().equals("admin")) {
							adminContact = responseObj.getResponse().getExtension().getInfData().getContact().get(i).getName();
						}
						if (responseObj.getResponse().getExtension().getInfData().getContact().get(i).getType().equals("billing")) {
							cobContact = responseObj.getResponse().getExtension().getInfData().getContact().get(i).getName();
						}
						if (responseObj.getResponse().getExtension().getInfData().getContact().get(i).getType().equals("member")) {
							memContact = responseObj.getResponse().getExtension().getInfData().getContact().get(i).getName();
						}
					}
					org.setAdminContact(adminContact);
					org.setCobContact(cobContact);
					org.setMemContact(memContact);
				}

				if (responseObj.getResponse().getResData() != null && responseObj.getResponse().getResData().getInfData() != null) {
					if (responseObj.getResponse().getResData().getInfData().getPostalInfo() != null && responseObj.getResponse().getResData().getInfData().getPostalInfo().getAddr() != null) {
						org.setName(responseObj.getResponse().getResData().getInfData().getPostalInfo().getName());
						AddressDTO address = new AddressDTO();
						if (!responseObj.getResponse().getResData().getInfData().getPostalInfo().getAddr().getStreet().isEmpty()) {
							if (responseObj.getResponse().getResData().getInfData().getPostalInfo().getAddr().getStreet().size() > 0) {
								address.setStreetAddress(responseObj.getResponse().getResData().getInfData().getPostalInfo().getAddr().getStreet().get(0));
							}
							if (responseObj.getResponse().getResData().getInfData().getPostalInfo().getAddr().getStreet().size() > 1) {
								address.setNumberAddress(responseObj.getResponse().getResData().getInfData().getPostalInfo().getAddr().getStreet().get(1));
							}
							if (responseObj.getResponse().getResData().getInfData().getPostalInfo().getAddr().getStreet().size() > 2) {
								address.setComplementAddress(responseObj.getResponse().getResData().getInfData().getPostalInfo().getAddr().getStreet().get(2));
							}
						}

						address.setCity(responseObj.getResponse().getResData().getInfData().getPostalInfo().getAddr().getCity());
						address.setPc(responseObj.getResponse().getResData().getInfData().getPostalInfo().getAddr().getPc());
						address.setState(responseObj.getResponse().getResData().getInfData().getPostalInfo().getAddr().getSp());
						address.setCountry(responseObj.getResponse().getResData().getInfData().getPostalInfo().getAddr().getCc());
						org.setAddress(address);
					}

					PhoneDTO phone = new PhoneDTO();
					if (responseObj.getResponse().getResData().getInfData().getVoice().getPhone() != null) {
						String voice = responseObj.getResponse().getResData().getInfData().getVoice().getPhone();
						String[] phones = voice.split("\\.");
						if (phones.length != 0) {
							phone.setCountryCode(phones[0].substring(1, phones[0].length()));
							phone.setPhoneNumber(phones[1]);
						}
						phone.setPhoneExtension(responseObj.getResponse().getResData().getInfData().getVoice().getX());
					}
					org.setPhone(phone);
				}

			}
			System.out.println(org.toString());
			return org;
		} catch (NoClassDefFoundError e) {
			System.out.println(e.getMessage());
		} catch (IOException ex) {
			Logger.getLogger(ApiAdminServices.class.getName()).log(Level.SEVERE, null, ex);
		}
		return null;
	}

	public IpDTO convertirIP() {
		try {
			String xmlIP = SocketFactory.getInstance().getEppExternalConnection().getFrameIp();
			if (!xmlIP.contains("<ipnetwork:name>")) {
				xmlIP = xmlIP.replace("<ipnetwork:contact type='abuse'>", "<ipnetwork:contact type='abuse'><ipnetwork:name>");
				xmlIP = xmlIP.replace("<ipnetwork:contact type='tech'>", "<ipnetwork:contact type='tech'><ipnetwork:name>");
				xmlIP = xmlIP.replace("</ipnetwork:contact>", "</ipnetwork:name></ipnetwork:contact>");
			}

			XmlMapper xmlMapper = new XmlMapper();
			EPP responseObj = xmlMapper.readValue(xmlIP, EPP.class);

			System.out.println("\nCONSTRUYENDO EL OBJETO IP");

			IpDTO ipOtroDTO = new IpDTO();
			if (responseObj != null && responseObj.getResponse() != null && responseObj.getResponse().getResData() != null && responseObj.getResponse().getResData().getInfData() != null) {
				if (responseObj.getResponse().getResData().getInfData().getIpRangeInfo() != null) {
					ipOtroDTO.setOrgId(responseObj.getResponse().getResData().getInfData().getIpRangeInfo().getOrganization());
					ipOtroDTO.setRoid(responseObj.getResponse().getResData().getInfData().getIpRangeInfo().getRoid());
					ipOtroDTO.setAsn(responseObj.getResponse().getResData().getInfData().getIpRangeInfo().getAsn());

					String type = "";
					if (responseObj.getResponse().getResData().getInfData().getIpRangeInfo().getAllocType() != null) {
						if (responseObj.getResponse().getResData().getInfData().getIpRangeInfo().getAllocType().equalsIgnoreCase("allocation")) {
							type = TipoAlocacion.ALLOCATION.toString();
						}
						if (responseObj.getResponse().getResData().getInfData().getIpRangeInfo().getAllocType().equalsIgnoreCase("assignment")) {
							type = TipoAlocacion.ASSIGNMENT.toString();
						}
						if (responseObj.getResponse().getResData().getInfData().getIpRangeInfo().getAllocType().equalsIgnoreCase("noapply")) {
							type = TipoAlocacion.NOAPPLY.toString();
						}
						ipOtroDTO.setAllocationType(type);
					}

					String abuseContact = "";
					String techContact = "";
					for (ContactResponse contact : responseObj.getResponse().getResData().getInfData().getIpRangeInfo().getContact()) {
						if (contact.getType().equalsIgnoreCase("abuse")) {
							abuseContact = contact.getName();
						}
						if (contact.getType().equalsIgnoreCase("tech")) {
							techContact = contact.getName();
						}
					}
					ipOtroDTO.setAbuseContact(abuseContact);
					ipOtroDTO.setTechContact(techContact);

					List<ReverseDNSDTO> ipnetworkReversesDns = new ArrayList<>();
					for (IPNetworkReverseDNS ipNetworkReverseDNS : responseObj.getResponse().getResData().getInfData().getIpRangeInfo().getReverseDNS()) {
						ReverseDNSDTO reverseDNSDTO = new ReverseDNSDTO();
						reverseDNSDTO.setIpnetworkRange(ipNetworkReverseDNS.getIpRange().convertToDto(ipNetworkReverseDNS.getIpRange()));
						reverseDNSDTO.setHostnames(ipNetworkReverseDNS.getHostName());
						ipnetworkReversesDns.add(reverseDNSDTO);
					}
					ipOtroDTO.setIpnetworkReversesDns(ipnetworkReversesDns);

					List<IPNetworkChildDTO> ipnetworkChildNetwork = new ArrayList<>();
					for (IPNetworkChildNetwork ipNetworkChildNetwork : responseObj.getResponse().getResData().getInfData().getIpRangeInfo().getChildNetwork()) {
						IPNetworkChildDTO ipNetworkChildNetworkDto = new IPNetworkChildDTO();
						ipNetworkChildNetworkDto.setIpnetworkRange(ipNetworkChildNetwork.getIpRange().convertToDto(ipNetworkChildNetwork.getIpRange()));
						ipNetworkChildNetworkDto.setRoid(ipNetworkChildNetwork.getRoid());
						ipnetworkChildNetwork.add(ipNetworkChildNetworkDto);
					}
					ipOtroDTO.setIpnetworkChildNetwork(ipnetworkChildNetwork);

					List<IPNetworkParentDTO> ipnetworkParentNetwork = new ArrayList<>();
					for (IPNetworkParentNetwork ipNetworkParentNetwork : responseObj.getResponse().getResData().getInfData().getIpRangeInfo().getParentNetwork()) {
						IPNetworkParentDTO ipNetworkParentNetworkDto = new IPNetworkParentDTO();
						ipNetworkParentNetworkDto.setIpnetworkRange(ipNetworkParentNetwork.getIpRange().convertToDto(ipNetworkParentNetwork.getIpRange()));
						ipNetworkParentNetworkDto.setRoid(ipNetworkParentNetwork.getRoid());
						ipnetworkParentNetwork.add(ipNetworkParentNetworkDto);
					}
					ipOtroDTO.setIpnetworkParentNetwork(ipnetworkParentNetwork);
				}

				if (responseObj.getResponse().getResData().getInfData().getIpRange() != null) {
					IPNetworkRangeDTO ipnetworkRange = new IPNetworkRangeDTO();
					ipnetworkRange.setStartAddress(responseObj.getResponse().getResData().getInfData().getIpRange().getStartAddress());
					ipnetworkRange.setEndAddress(responseObj.getResponse().getResData().getInfData().getIpRange().getEndAddress());
					ipnetworkRange.setVersion(responseObj.getResponse().getResData().getInfData().getIpRange().getVersion());
					ipOtroDTO.setIpnetworkRange(ipnetworkRange);
				}
			}
			System.out.println("\nCONSTRUYO EL OBJETO IP");
			return ipOtroDTO;
		} catch (NoClassDefFoundError e) {
			System.out.println(e.getMessage());
		} catch (IOException ex) {
			Logger.getLogger(ApiAdminServices.class.getName()).log(Level.SEVERE, null, ex);
		}
		return null;
	}

	public UserDTO convertirUser() {
		try {
			String xmlContact = SocketFactory.getInstance().getEppExternalConnection().getFrameUser();
			System.out.println(xmlContact);

			if (xmlContact.contains("<contact:voice></contact:voice>")) {
				xmlContact = xmlContact.replace("<contact:voice>", "<contact:voice><contact:phone></contact:phone>");
			} else if (xmlContact.contains("<contact:voice")) {
				xmlContact = xmlContact.replace("+", "<contact:phone>+");
				xmlContact = xmlContact.replace("</contact:voice>", "</contact:phone></contact:voice>");
			}
			XmlMapper xmlMapper = new XmlMapper();
			EPP responseObj = xmlMapper.readValue(xmlContact, EPP.class);
			System.out.println(responseObj.toString());

			System.out.println("\nCONSTRUYENDO EL OBJETO USUARIO");
			UserDTO user = new UserDTO();
			if (responseObj != null && responseObj.getResponse() != null) {
				if (responseObj.getResponse().getResData() != null && responseObj.getResponse().getResData().getInfData() != null) {
					user.setEmail(responseObj.getResponse().getResData().getInfData().getEmail());

					if (responseObj.getResponse().getResData().getInfData().getPostalInfo() != null) {
						user.setName(responseObj.getResponse().getResData().getInfData().getPostalInfo().getName());

						if (responseObj.getResponse().getResData().getInfData().getPostalInfo().getAddr() != null) {
							AddressDTO address = new AddressDTO();
							if (responseObj.getResponse().getResData().getInfData().getPostalInfo().getAddr().getStreet().size() > 0) {
								address.setStreetAddress(responseObj.getResponse().getResData().getInfData().getPostalInfo().getAddr().getStreet().get(0));
							}
							if (responseObj.getResponse().getResData().getInfData().getPostalInfo().getAddr().getStreet().size() > 1) {
								address.setNumberAddress(responseObj.getResponse().getResData().getInfData().getPostalInfo().getAddr().getStreet().get(1));
							}
							if (responseObj.getResponse().getResData().getInfData().getPostalInfo().getAddr().getStreet().size() > 2) {
								address.setComplementAddress(responseObj.getResponse().getResData().getInfData().getPostalInfo().getAddr().getStreet().get(2));
							}

							address.setCity(responseObj.getResponse().getResData().getInfData().getPostalInfo().getAddr().getCity());
							address.setPc(responseObj.getResponse().getResData().getInfData().getPostalInfo().getAddr().getPc());
							address.setState(responseObj.getResponse().getResData().getInfData().getPostalInfo().getAddr().getCity());
							address.setCountry(responseObj.getResponse().getResData().getInfData().getPostalInfo().getAddr().getCc());
							user.setAddress(address);
						}
					}

					PhoneDTO phone = new PhoneDTO();
					if (responseObj.getResponse().getResData().getInfData().getVoice().getPhone() != null) {
						String voice = responseObj.getResponse().getResData().getInfData().getVoice().getPhone();
						String[] phones = voice.split("\\.");
						if (phones.length != 0) {
							phone.setCountryCode(phones[0].substring(1, phones[0].length()));
							phone.setPhoneNumber(phones[1]);
						}
						phone.setPhoneExtension(responseObj.getResponse().getResData().getInfData().getVoice().getX());
					}
					user.setPhone(phone);
				}

				if (responseObj.getResponse().getExtension() != null && responseObj.getResponse().getExtension().getInfData() != null) {
					user.setLanguage(responseObj.getResponse().getExtension().getInfData().getLanguage());
				}
			}
			System.out.println(user.toString());
			return user;
		} catch (NoClassDefFoundError e) {
			System.out.println(e.getMessage());
		} catch (IOException ex) {
			Logger.getLogger(ApiAdminServices.class.getName()).log(Level.SEVERE, null, ex);
		}
		return null;
	}

	public String getCreatedOrg() {
		return createdOrg;
	}

	public void setCreatedOrg(String createdOrg) {
		this.createdOrg = createdOrg;
	}

}