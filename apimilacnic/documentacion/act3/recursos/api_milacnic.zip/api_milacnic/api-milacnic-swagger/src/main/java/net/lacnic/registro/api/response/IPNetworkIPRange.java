package net.lacnic.registro.api.response;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

@XStreamAlias("ipnetwork:ipRange")
public class IPNetworkIPRange implements Serializable {
	@XStreamAsAttribute
	String version; // attribute

	@XStreamAlias("ipnetwork:startAddress")
	String startAddress;

	@XStreamAlias("ipnetwork:endAddress")
	String endAddress;

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getStartAddress() {
		return startAddress;
	}

	public void setStartAddress(String startAddress) {
		this.startAddress = startAddress;
	}

	public String getEndAddress() {
		return endAddress;
	}

	public void setEndAddress(String endAddress) {
		this.endAddress = endAddress;
	}
}
