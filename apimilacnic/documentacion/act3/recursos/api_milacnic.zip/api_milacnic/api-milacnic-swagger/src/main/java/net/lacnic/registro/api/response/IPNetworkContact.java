package net.lacnic.registro.api.response;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

@XStreamAlias("ipnetwork:contact")
public class IPNetworkContact implements Serializable {
	@XStreamAsAttribute
	String type; // attribute

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}
