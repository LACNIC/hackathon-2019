package net.lacnic.epp.exceptions;

public class EppSplitterException extends Exception {
	
	private static final long serialVersionUID = -7007381123690684786L;

	public EppSplitterException(String message){
		super(message);
	}

}
