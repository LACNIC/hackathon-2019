package net.lacnic.tb;

import java.util.HashMap;
import java.util.List;

import net.lacnic.domain.TokenBucketOrg;
import net.lacnic.ejb.service.impl.ApiAdminServices;
import net.lacnic.utils.RateLimit;

public class StorageTokenBucket {

	ApiAdminServices tbcService;

	private static TokenBucket defaultTokenBucket;
	// Mapa para almacenar idOrg y un mapa de operaciones, el id del mapa interno es
	// el tipo de operacion
	private static HashMap<String, HashMap<String, TokenBucket>> otrosTokenBucket = new HashMap<>();

	public StorageTokenBucket(ApiAdminServices tbcService) {
		this.tbcService = tbcService;
	}

	public TokenBucket getDefaultTokenBucket(String orgId) {
		System.out.println("Entro al getDefaultTokenBucket() del StorageTokenBucket");

		TokenBucketOrg dTBOrg = tbcService.obtenerDefaultTokenBucketByOrgId(orgId);
		System.out.println("dTBConf.getId()dddddddd " + dTBOrg.getTokenBucketConfig());

		defaultTokenBucket = new TokenBucket(dTBOrg.getBucketSize(), dTBOrg.getTokensToAdd(), dTBOrg.getPeriodMinToRerill());

		List<TokenBucketOrg> otrosTBConf = tbcService.obtenerOtrosTokenBucketByOrgId(orgId);
		System.out.println("otrosTBConf listaaaaaa " + otrosTBConf.size());
		if (otrosTokenBucket.get(orgId) != null) {
			for (TokenBucketOrg tbc : otrosTBConf) {
				if (!otrosTokenBucket.get(orgId).containsKey(tbc.getTokenBucketConfig())) {
					otrosTokenBucket.get(orgId).put(tbc.getTokenBucketConfig(), new TokenBucket(tbc.getTokenBucketConfig(), tbc.getBucketSize(), tbc.getTokensToAdd(), tbc.getPeriodMinToRerill()));
				}
			}
		} else {
			HashMap<String, TokenBucket> newMap = new HashMap<>();
			for (TokenBucketOrg tbc : otrosTBConf) {
				if (!newMap.containsKey(tbc.getTokenBucketConfig())) {
					newMap.put(tbc.getTokenBucketConfig(), new TokenBucket(tbc.getTokenBucketConfig(), tbc.getBucketSize(), tbc.getTokensToAdd(), tbc.getPeriodMinToRerill()));
				}
			}
			otrosTokenBucket.put(orgId, newMap);
		}
		return defaultTokenBucket;
	}

	public TokenBucket getDefaultTokenBucketByOrgId(String orgId) {
		System.out.println("Entro al getDefaultTokenBucket() del StorageTokenBucket");
		TokenBucketOrg dTBConf = tbcService.obtenerDefaultTokenBucketByOrgId(orgId);
		TokenBucket tokenBucket = new TokenBucket(dTBConf.getBucketSize(), dTBConf.getTokensToAdd(), dTBConf.getPeriodMinToRerill());
		return tokenBucket;
	}

	private TokenBucket getTokenBucket(String orgId, RateLimit action) {
		System.out.println("Entro al getTokenBucket() del StorageTokenBucket");
		return getOtrosTokenBucket().get(orgId).get(action.getNombre());
	}

	public boolean tryConsumeAction(String orgId, RateLimit action) {
		try {
			this.getDefaultTokenBucket(orgId); // Este habría que llamarlo en todas las operaciones, para que agregue al mapa
												// las organizaciones nuevas que quieran hacer consultas, con sus respectivos
												// tokens
			TokenBucket tokenBucket = this.getTokenBucket(orgId, action);
			System.out.println("getTokenBucket(accion)bbbbbbb " + tokenBucket.getId());
			return tokenBucket.tryConsume();
		} catch (Exception e) {
			System.out.println("Token **New** invalid: " + action.getNombre());
			return false;
		}
	}

	public HashMap<String, HashMap<String, TokenBucket>> getOtrosTokenBucket() {
		return otrosTokenBucket;
	}

}
